package helpers;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

@SuppressWarnings("unused")
public class Log {

	
	
	private static Logger Log = Logger.getLogger(Log.class.getName()); 
	


}