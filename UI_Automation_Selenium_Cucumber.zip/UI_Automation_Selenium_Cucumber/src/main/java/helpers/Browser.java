package helpers;



import static helpers.Browser.driver;

import java.io.File;
import java.io.IOException;
import org.apache.log4j.Logger;
//import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverService;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

//import step_definitions.Hooks;

import java.util.Properties;
import java.util.Set;

public class Browser  {
	public static Logger log = Logger.getLogger(Browser.class);
	public static WebDriver driver;
	public static WebElement element;
	
	
	public static String driverPath = "P:/Saurav/Java_Automation/drivers/ChromeDriver/";
//	public static String driverPath = "P:/Saurav/Java_Automation/drivers/IEDriver/";
//    public String driverPath = "P:/Saurav/Java_Automation/drivers
	static long timeout = 50;

	public static Browser br = new Browser();
	
	@SuppressWarnings("deprecation")
	public static WebDriver getBrowser(String browserType) throws IOException {
		
		System.setProperty("jacob.dll.path", "P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/jacob-1.14.3-x86.dll");
		
        if(browserType.trim().toUpperCase().contains("CHROME")){
//        	System.setProperty("webdriver.ie.driver", driverPath + "/IEDriverServer.exe");
        	
        	System.setProperty("webdriver.chrome.driver", driverPath + "/chromeDriver.exe");
        	ChromeOptions chromeOptions = new ChromeOptions();
        	chromeOptions.setExperimentalOption("useAutomationExtension", false);
	        return driver = new ChromeDriver(chromeOptions);
        }
	
        else if(browserType.trim().toUpperCase().contains("IE")){      	          
                  
            
        	System.setProperty("webdriver.ie.driver", driverPath + "IEDriverServer.exe");
        	
        	  
              DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
             // DesiredCapabilities caps = DesiredCapabilities.chrome();
              capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);


            return driver = new InternetExplorerDriver(capabilities);

       
        }
	

		return driver;
	}
	
	
    public void switchWindows(){
        pause(5000);
        String parentHandle = driver.getWindowHandle();
        System.out.println("This is the parent window handle: " +" " + parentHandle);
        Set<String> handles = driver.getWindowHandles();
        System.out.println(handles);
        for(String handle: handles){
            if(handle.equals(parentHandle)){
                continue;
            }
            driver.switchTo().window(handle);
            System.out.println("Switching to child window" + driver.getWindowHandle());
            break;
        }
    }

	
public String getReportConfigPath(){
 Properties properties = new Properties();
 String reportConfigPath = properties.getProperty("P:/Saurav/Java_Automation/workspace/UI_Automation_Selenium_Cucumber/src/main/resources/extent-config.xml");
 if(reportConfigPath!= null) return reportConfigPath;
 else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath"); 
}


    public void pause(int time){
        if (time<=0){
            return;
        }
        
        try {
            Thread.sleep(time);
            System.out.println("Pause for" + time + "ms" + "\n");
        }
        
        catch (InterruptedException e){
            e.printStackTrace();
        }
    }



	public static void killDriver(){
		log.info(">>> Killing WebDriver driver");
		driver.quit();		
	}


	public static void killProcess(String processName) throws IOException{
		log.info("Killing process: "+processName);
		Process process=Runtime.getRuntime().exec(processName.trim());
		process.destroy();
	}
	
	
	public static void TabPress(int numberOfPress) throws InterruptedException{
		Actions action = new Actions(driver);
		for(int i=1; i<=numberOfPress; i++){
			action.keyDown(Keys.TAB).build().perform();
			Thread.sleep(1000);
			action.keyUp(Keys.TAB).build().perform();
		}
	}

	public static void EnterPress(int numberOfPress) throws InterruptedException{
		Actions action = new Actions(driver);
		for(int i=1; i<=numberOfPress; i++){
			action.keyDown(Keys.ENTER).build().perform();
			Thread.sleep(1000);
			action.keyUp(Keys.TAB).build().perform();
		}
	}
	
	

		
	
}