package helpers;

import java.io.File;

import java.text.SimpleDateFormat;
import java.util.Date;
//import Reporter;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.aventstack.extentreports.ExtentReports;
import com.cucumber.listener.Reporter;
//import com.relevantcodes.extentreports.NetworkMode;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

//accessIT--soa space..3.7 release---sodsim-

@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(jsonReport = "test-output/Reports/${Date(dd-MM-yyyy)}/cucumber.json",
              overviewReport = true,
              retryCount = 0,
              toPDF = true,
              detailedReport = true,
              detailedAggregatedReport = true,              
              coverageReport = true,
        outputFolder = "test-output/Reports/${Date(dd-MM-yyyy)}")


@CucumberOptions(plugin = { "html:test-output/Reports/${Date(dd-MM-yyyy)}",
        "json:test-output/Reports/${Date(dd-MM-yyyy)}/cucumber.json", "pretty:test-output/Reports/${Date(dd-MM-yyyy)}/cucumber-pretty.txt",
       "usage:test-output/Reports/${Date(dd-MM-yyyy)}/cucumber-usage.json", "junit:test-output/Reports/${Date(dd-MM-yyyy)}/cucumber-results.xml", "rerun:test-output/Reports/${Date(dd-MM-yyyy)}/rerun.txt","com.cucumber.listener.ExtentCucumberFormatter:test-output/Reports/${Date(dd-MM-yyyy)}/RunReport.html"},
        features = { "P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/src/test/resources/features/AccessIT_POC_Automation_TestCases.feature"},
        glue = {"helpers","step_definitions"},
        tags = {"@Test"})
//SOD_RuleUpload_Download_TestCases.feature
public class TestRunner {

       public static String timeStamp=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

//       WHEN UNABLE TO CREATE DIRECTORY -> JUST DELETE THE test-output FOLDER AND DO A ECLIPSE RESTARTGHOS---goto sys explorer and den uncheck the readonly option of ${Date(dd-MM-yyyy) folder and all sub folders test output
       @AfterClass
    public static void teardown() {
        Reporter.loadXMLConfig(new File("P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/src/main/resources/Extent-Config.xml"));

        Reporter.setSystemInfo("os", "windows OSX");
        Reporter.setTestRunnerOutput("Test runner output message");

    }




       }
