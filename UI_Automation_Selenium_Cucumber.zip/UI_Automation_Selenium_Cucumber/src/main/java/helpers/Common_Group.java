package helpers;


import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Node;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPath;


import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.formula.Formula;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.soap.SOAPMessage;
import org.codehaus.plexus.util.StringUtils;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.formula.Formula;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.codehaus.plexus.util.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Node;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import edu.emory.mathcs.backport.java.util.Collections;

@SuppressWarnings({ "unused", "restriction" })
public class Common_Group {
	
	public static Logger log = Logger.getLogger(Common_Group.class);
	//public static String file_path=readProp("GlobalSettings","dataSheetPath");
	public static String file_path=Common_Group.readProp("GlobalSettings","download_resultant_uploaded_file_path");
	
	
	public static SoftAssert softAss = new SoftAssert();

    //Over loaded method to get return type as String
    @SuppressWarnings({ "resource", "deprecation" })
	public String getData(String file_name, String sheetName, String colName, int rowNum, String return_type) throws IOException{
    	//String file_path=readProp("GlobalSettings","dataSheetPath");
        XSSFWorkbook workbook = null;
        XSSFSheet sheet = null;
        XSSFRow row = null;
        XSSFCell cell = null;      
		//InputStream excelFile = this.getClass().getClassLoader().getResourceAsStream(file_name+".xlsx");
        FileInputStream excelFile = new FileInputStream(new File(file_path+file_name));
        workbook = new XSSFWorkbook(excelFile);

        try{
            int col_Num = -1;
            sheet = workbook.getSheet(sheetName.trim());
            row = sheet.getRow(0);
            for(int i = 0; i < row.getLastCellNum(); i++){
                if(row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
                	col_Num = i;
            }
 
            row = sheet.getRow(rowNum - 1);
            cell = row.getCell(col_Num);
 
            if(cell.getCellTypeEnum() == CellType.STRING)
                return cell.getStringCellValue();
            
            else if(cell.getCellTypeEnum()==CellType.NUMERIC || cell.getCellTypeEnum()==CellType.FORMULA){
                String cellValue = String.valueOf(cell.getNumericCellValue());
                
                if(HSSFDateUtil.isCellDateFormatted(cell)){
                    DateFormat df = new SimpleDateFormat("dd/MM/yy");
                    Date date = cell.getDateCellValue();
                    cellValue = df.format(date);
                }

                return cellValue.trim();
            }

            else if(cell.getCellTypeEnum() == CellType.BLANK)
                return "";

            else
                return String.valueOf(cell.getBooleanCellValue());
        }

        catch(Exception e){
            e.printStackTrace();
            return "row "+rowNum+" or column "+colName +" does not exist  in Excel";
        }
    }
    
    
    
    @SuppressWarnings({ "resource", "deprecation" })
    public String getData(String file_path,String file_name, String sheetName, String colName, int rowNum, String return_type) throws IOException{
    	//String file_path=readProp("GlobalSettings","dataSheetPath");
        XSSFWorkbook workbook = null;
        XSSFSheet sheet = null;
        XSSFRow row = null;
        XSSFCell cell = null;      
		//InputStream excelFile = this.getClass().getClassLoader().getResourceAsStream(file_name+".xlsx");
        FileInputStream excelFile = new FileInputStream(new File(file_path+file_name));
        workbook = new XSSFWorkbook(excelFile);

        try{
            int col_Num = -1;
            sheet = workbook.getSheet(sheetName.trim());
            row = sheet.getRow(0);
            for(int i = 0; i < row.getLastCellNum(); i++){
                if(row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
                	col_Num = i;
            }
 
            row = sheet.getRow(rowNum - 1);
            cell = row.getCell(col_Num);
 
            if(cell.getCellTypeEnum() == CellType.STRING)
                return cell.getStringCellValue();
            
            else if(cell.getCellTypeEnum()==CellType.NUMERIC || cell.getCellTypeEnum()==CellType.FORMULA){
                String cellValue = String.valueOf(cell.getNumericCellValue());
                
                if(HSSFDateUtil.isCellDateFormatted(cell)){
                    DateFormat df = new SimpleDateFormat("dd/MM/yy");
                    Date date = cell.getDateCellValue();
                    cellValue = df.format(date);
                }

                return cellValue.trim();
            }

            else if(cell.getCellTypeEnum() == CellType.BLANK)
                return "";

            else
                return String.valueOf(cell.getBooleanCellValue());
        }

        catch(Exception e){
            e.printStackTrace();
            return "row "+rowNum+" or column "+colName +" does not exist  in Excel";
        }
    }



    //Over loaded method to get return type as Excel Formula string
    @SuppressWarnings({ "resource", "deprecation" })
	public XSSFRichTextString getData(String file_name, String sheetName, String colName, int rowNum) throws IOException{
    	//String file_path=readProp("GlobalSettings","dataSheetPath");
        XSSFWorkbook workbook = null;
        XSSFSheet sheet = null;
        XSSFRow row = null;
        XSSFCell cell = null;      
		//InputStream excelFile = this.getClass().getClassLoader().getResourceAsStream(file_name+".xlsx");
        FileInputStream excelFile = new FileInputStream(new File(file_path+file_name+".xlsx"));
        workbook = new XSSFWorkbook(excelFile);

        try{
            int col_Num = -1;
            sheet = workbook.getSheet(sheetName.trim());
            row = sheet.getRow(0);
            for(int i = 0; i < row.getLastCellNum(); i++){
                if(row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
                	col_Num = i;
            }
 
            row = sheet.getRow(rowNum - 1);
            cell = row.getCell(col_Num);
 
            if(cell.getCellTypeEnum()==CellType.FORMULA){
            	//int cellValue=cell.getCachedFormulaResultType();        
            	XSSFRichTextString cellValue=cell.getRichStringCellValue();
                return cellValue;
            }
            
            else if(cell.getCellTypeEnum() == CellType.BLANK)
                return null;

/*            else
                return cell.getBooleanCellValue();*/
        }
        
        catch(Exception e){
            e.printStackTrace();
            //return "row "+rowNum+" or column "+colName +" does not exist  in Excel";
            return null;
        }
		return null;
    }

    public int getDataCount(String file_name, String sheetName, String colName, int rowNum) throws IOException{
		//String file_path=readProp("GlobalSettings","dataSheetPath");
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;      
		//InputStream excelFile = this.getClass().getClassLoader().getResourceAsStream(file_name+".xlsx");
		FileInputStream excelFile = new FileInputStream(new File(file_path+file_name+".xlsx"));
		workbook = new XSSFWorkbook(excelFile);
        int dataCount=0;
		try{
			int col_Num = -1;
			sheet = workbook.getSheet(sheetName.trim());
			row = sheet.getRow(0);
			for(int i = 0; i < row.getLastCellNum(); i++){
//				if(row.getCell(i).getStringCellValue().trim().contains(colName.trim())&&((!row.getCell(i+1).getStringCellValue().equals(""))||(!row.getCell(i+1).getStringCellValue().equals("null"))))  if (!approverGuid.equals("") && approverGuid!=null)
				if(row.getCell(i).getStringCellValue().trim().contains(colName.trim()))
				dataCount++;
			}
		}
		catch(Exception e){
			e.printStackTrace();
			log.info("row "+rowNum+" or column "+colName +" does not exist  in Excel");
		}
		return dataCount;

	}

    public String toPrettyFormat(String jsonString) 
	{
		JsonParser parser = new JsonParser();
		JsonObject json = parser.parse(jsonString).getAsJsonObject();

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String prettyJson = gson.toJson(json);

		return prettyJson;
	}

    
    public static String toPrettyFormatXml(String xml, Boolean ommitXmlDeclaration) throws IOException, SAXException, ParserConfigurationException {

		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document doc = db.parse(new InputSource(new StringReader(xml)));

		OutputFormat format = new OutputFormat(doc);
		format.setIndenting(true);
		format.setIndent(2);
		format.setOmitXMLDeclaration(ommitXmlDeclaration);
		format.setLineWidth(Integer.MAX_VALUE);
		Writer outxml = new StringWriter();
		XMLSerializer serializer = new XMLSerializer(outxml, format);
		serializer.serialize(doc);

		return outxml.toString();

	}
    //Over loaded method to get return type as Integer
	@SuppressWarnings({ "resource", "deprecation", "null" })
	public int getData(String file_name, String sheetName, String colName, int rowNum, int return_type) throws IOException{
		//String file_path=readProp("GlobalSettings","dataSheetPath");
        XSSFWorkbook workbook = null;
        XSSFSheet sheet = null;
        XSSFRow row = null;
        XSSFCell cell = null;      
		//InputStream excelFile = this.getClass().getClassLoader().getResourceAsStream(file_name+".xlsx");
        FileInputStream excelFile = new FileInputStream(new File(file_path+file_name+".xlsx"));
        workbook = new XSSFWorkbook(excelFile);

        try{
            int col_Num = -1;
            sheet = workbook.getSheet(sheetName.trim());
            row = sheet.getRow(0);
            for(int i = 0; i < row.getLastCellNum(); i++){
                if(row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
                	col_Num = i;
            }
 
            row = sheet.getRow(rowNum - 1);
            cell = row.getCell(col_Num);
 
            
            if(cell.getCellTypeEnum()==CellType.NUMERIC || cell.getCellTypeEnum()==CellType.FORMULA){
                int cellValue = (int) cell.getNumericCellValue();
                return cellValue;
            }

            else if(cell.getCellTypeEnum() == CellType.BLANK)
                return (Integer) null;
        }
        
        catch(Exception e){
            e.printStackTrace();

            //return "row "+rowNum+" or column "+colName +" does not exist  in Excel";
        }
        return (Integer) null;
    }

	public static String jdbcToXml(ResultSet rs) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.newDocument();
		Element results = doc.createElement("Results");
		doc.appendChild(results);

		ResultSetMetaData rsmd = rs.getMetaData();
		int colCount = rsmd.getColumnCount();

		while (rs.next()) {
			Element row = doc.createElement("Row");
			results.appendChild(row);
			for (int i = 1; i <= colCount; i++) {
				String columnName = rsmd.getColumnName(i);
				Object value = rs.getObject(i);
				Element node = doc.createElement(columnName);
				//node.appendChild(doc.createTextNode(value.toString()));
				node.appendChild(doc.createTextNode(value == null ? "" : value.toString()));
				row.appendChild(node);
			}
		}
		DOMSource domSource = new DOMSource(doc);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
		StringWriter sw = new StringWriter();
		StreamResult sr = new StreamResult(sw);
		transformer.transform(domSource, sr);
		return(sw.toString());
		//System.out.println(sw.toString());
	}

    public void putData(String file_name,String sheet_name, String colName, int rowNum, String value) throws IOException, EncryptedDocumentException, InvalidFormatException, InterruptedException {
    	String file_path= readProp("GlobalSettings", "dataSheetPath");
//    	file_name=readProp("GlobalSettings", "dataFileName");
    	FileInputStream inputStream = new FileInputStream(new File(file_path+"\\"+file_name+".xlsx"));
        Workbook workbook = WorkbookFactory.create(inputStream);
        Sheet sheet = workbook.getSheet(sheet_name);
        FileOutputStream fos = new FileOutputStream(file_path+"\\"+file_name+".xlsx");
        
        try{
	        int col_Num = -1;
	        Row row = sheet.getRow(0);
	        Cell cell = null;
	        for (int i = 0; i < row.getLastCellNum(); i++) {
	            if (row.getCell(i).getStringCellValue().trim().contains(colName))
	            {
	            	col_Num = i;
	            }
	        }

	        sheet.autoSizeColumn(col_Num);
	        row = sheet.getRow(rowNum - 1);
	        if(row==null){
	            row = sheet.createRow(rowNum - 1);
	        	cell = row.getCell(col_Num);        	
	        }
	        
	        if(cell == null){
	            cell = row.createCell(col_Num);
	            if(value!=null){
			            if(value.length()>32700){
				            //log.info("The length of the input string is: "+value.length());
			            	cell.setCellValue(StringUtils.substring(value, 0, 32710));
			            }
		
			            else{
			            	cell.setCellValue(value);
			            }
	            }
	            
	            else{
	            	cell.setCellValue("null");
	            }
	            
	        	workbook.write(fos);
	        	fos.close();
	        }
        }

        catch(FileNotFoundException e){
        	log.info(e);
        }

        finally{
            fos.close();
            workbook.close();
         	inputStream.close();
        }
    }
    
    public void putData(String sheet_name, String colName, int rowNum, String value) throws IOException, EncryptedDocumentException, InvalidFormatException, InterruptedException {
        String file_path= readProp("GlobalSettings", "dataSheetPath");
        String file_name=readProp("GlobalSettings", "dataFileName");
        try {
             Runtime.getRuntime().exec("taskkill /f /im EXCEL.exe");
        } catch (IOException e) {
             e.printStackTrace();
        }
        Thread.sleep(10000);
        FileInputStream inputStream = new FileInputStream(new File(file_path+"\\"+file_name+".xlsx"));
        Workbook workbook = WorkbookFactory.create(inputStream);
        Sheet sheet = workbook.getSheet(sheet_name);
        FileOutputStream fos = new FileOutputStream(file_path+"\\"+file_name+".xlsx");

        try{
             int col_Num = -1;
             Row row = sheet.getRow(0);
             Cell cell = null;
             for (int i = 0; i < row.getLastCellNum(); i++) {
                  if (row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
                  {
                        col_Num = i;
                  }

             }
             if(col_Num!= -1)
             {
                  //sheet.autoSizeColumn(col_Num);
                  sheet.setColumnWidth(col_Num, 5000);
                  row = sheet.getRow(rowNum - 1);
                  if(row==null){
                        row = sheet.createRow(rowNum - 1);
                        cell = row.getCell(col_Num);        
                  }

                  if(cell == null){
                        cell = row.createCell(col_Num);
                        if(value!=null){
                             if(value.length()>32700){
                                  //log.info("The length of the input string is: "+value.length());
                                  cell.setCellValue(StringUtils.substring(value, 0, 32710));
                             }

                             else{
                                  cell.setCellValue(value);
                             }
                        }

                        else{
                             cell.setCellValue("null");
                        }

                  }
                  workbook.write(fos);
                  fos.close();
                  inputStream.close();
             }
             else
             {
                  log.info("Column "+ colName +"does not exist  in Excel for write operation");
             }
        }

        catch(FileNotFoundException e){
             log.info(e);
        }

        finally{
             fos.close();
             workbook.close();
             inputStream.close();
        }
  }



   




	public static String readProp(String fileName, String property_name){
		InputStream input = null;
		String prop_val = null;
		Properties prop = new Properties();

		try{
			//String fileName = "GlobalSettings.properties";
			input = CommonGroup.class.getClassLoader().getResourceAsStream(fileName+".properties");
			if(input==null){
				System.out.println("Unable to find GlobalSettings.properties file");
				return null;
			}
			prop.load(input);
			prop_val = prop.getProperty(property_name).trim(); 
		}
		
		catch(IOException e){
			e.printStackTrace();
		}
		
		finally{
			if(input!=null){
				try{
					input.close();
				}
				
				catch(IOException ex){
					ex.printStackTrace();
				}
			}
		}

		return prop_val.trim();
	}


	public ResultSet  select_query1(String hostName, String protocol, String sid_service_name, String userId, String password, String sql_query) throws ClassNotFoundException, SQLException{
		log.info("Running select SQL: "+sql_query);
		//CommonGroup test = new CommonGroup();
		String driver = readProp("GlobalSettings", "driver");
		Connection conn=null;
		ResultSet rs = null;
		int port_num = 1521;
		Class.forName(driver);
		
		if(protocol.toUpperCase().contains("SID")){
			//Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@dbjgo601d-scan.bjg.swissbank.com:1521:DFTREA5B","CBSFT","UBS_Ft17");		
			conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+":"+sid_service_name+"",userId,password);
		}
		
		else if(protocol.toUpperCase().contains("SERVICE_NAME")){
			// jdbc:oracle:thin:@//HOSTNAME:PORT/SERVICENAME
			conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+"/"+sid_service_name+"",userId,password);
		}
		else
		{
			System.setProperty("oracle.net.tns_admin", "C:/Programs/Oracle/Ora11g/NETWORK/ADMIN/SAMPLE");
			String dbURL = "jdbc:oracle:thin:@"+sid_service_name;
			conn = DriverManager.getConnection(dbURL,userId,password);
		} 
		log.info(" inside query ");
		
		try{
			if(!conn.isClosed()){
				Statement st = conn.createStatement();
				String sqlStr = sql_query;
				rs = st.executeQuery(sqlStr);
	      		log.info("result set");
				System.out.println(rs.toString());
				return rs;
			}
			
			else{
				System.out.println("Method: CommonGroup.runQuery. Err: db connection was unsuccessful ***");
				return null;
			}
				
		}
		
		catch(SQLException sql_ex){
			System.out.println(sql_ex);
			return null;
		}

	//	return null;
	}

	
	public ResultSet select_query_new(String hostName, String protocol, String sid_service_name, String userId, String password, String sql_query,String port_num) throws ClassNotFoundException, SQLException{
        log.info("Running select SQL: "+sql_query);
        //CommonGroup test = new CommonGroup();
        String driver = readProp("GlobalSettings", "driver");
        Connection conn=null;
//        int port_num = 1521;
        Class.forName(driver);
        if(protocol.toUpperCase().contains("SID")){
               //Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@dbjgo601d-scan.bjg.swissbank.com:1521:DFTREA5B","CBSFT","UBS_Ft17");           
               conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+":"+sid_service_name+"",userId,password);
        }
        
        else if(protocol.toUpperCase().contains("SERVICE_NAME")){
               // jdbc:oracle:thin:@//HOSTNAME:PORT/SERVICENAME
               conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+"/"+sid_service_name+"",userId,password);
        }
        
        try{
               if(!conn.isClosed()){
                     Statement st = conn.createStatement();
                     String sqlStr = sql_query;
                     ResultSet rs = st.executeQuery(sqlStr);
                     String val = null;
                     
                     if(rs!=null) {
                            return rs;
                            
                     }
                     else{
                            System.out.println("SQL returned null value");
                            conn.close();
                            return null;
                     }
               }
               
               else{
                     System.out.println("Method: CommonGroup.runQuery. Err: db connection was unsuccessful ***");
                     return null;
               }
               
        }
        
        catch(SQLException sql_ex){
               System.out.println(sql_ex);
        }
        conn.close();
        return null;
 }
	
	public ResultSet select_query_new(String hostName, String protocol, String sid_service_name, String userId, String password, String sql_query) throws ClassNotFoundException, SQLException{
        log.info("Running select SQL: "+sql_query);
        //CommonGroup test = new CommonGroup();
        String driver = readProp("GlobalSettings", "driver");
        Connection conn=null;
        int port_num = 1521;
        Class.forName(driver);
        if(protocol.toUpperCase().contains("SID")){
               //Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@dbjgo601d-scan.bjg.swissbank.com:1521:DFTREA5B","CBSFT","UBS_Ft17");           
               conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+":"+sid_service_name+"",userId,password);
        }
        
        else if(protocol.toUpperCase().contains("SERVICE_NAME")){
               // jdbc:oracle:thin:@//HOSTNAME:PORT/SERVICENAME
               conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+"/"+sid_service_name+"",userId,password);
        }
        
        try{
               if(!conn.isClosed()){
                     Statement st = conn.createStatement();
                     String sqlStr = sql_query;
                     ResultSet rs = st.executeQuery(sqlStr);
                     String val = null;
                     
                     if(rs!=null) {
                            return rs;
                            
                     }
                     else{
                            System.out.println("SQL returned null value");
                            conn.close();
                            return null;
                     }
               }
               
               else{
                     System.out.println("Method: CommonGroup.runQuery. Err: db connection was unsuccessful ***");
                     return null;
               }
               
        }
        
        catch(SQLException sql_ex){
               System.out.println(sql_ex);
        }
        conn.close();
        return null;
 }


	public String  select_query(String hostName, String protocol, String sid_service_name, String userId, String password, String sql_query , String column_name ) throws ClassNotFoundException, SQLException{
		log.info("Running select SQL: "+sql_query);
		//CommonGroup test = new CommonGroup();
		String driver = readProp("GlobalSettings", "driver");
		Connection conn=null;
		int port_num = 1521;
		Class.forName(driver);
		if(protocol.toUpperCase().contains("SID")){
			//Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@dbjgo601d-scan.bjg.swissbank.com:1521:DFTREA5B","CBSFT","UBS_Ft17");		
			conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+":"+sid_service_name+"",userId,password);
		}
		
		else if(protocol.toUpperCase().contains("SERVICE_NAME")){
			// jdbc:oracle:thin:@//HOSTNAME:PORT/SERVICENAME
			conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+"/"+sid_service_name+"",userId,password);
		}
		
		try{
			if(!conn.isClosed()){
				Statement st = conn.createStatement();
				String sqlStr = sql_query;
				ResultSet rs = st.executeQuery(sqlStr);
				String val = null;
				while (rs.next()) {
					val = rs.getString(column_name);
					
					//val=rs;
				}

				conn.close();
				
				if(val==null){
					System.out.println("Query has returned null");
					return null;
				}
				
				else if(val.trim()!=null){
					return val;
				}
				
				else{
					System.out.println("SQL returned null value");
					return null;
				}
				
			}
			
			else{
				System.out.println("Method: CommonGroup.runQuery. Err: db connection was unsuccessful ***");
				return null;
			}
				
		}
		
		catch(SQLException sql_ex){
			System.out.println(sql_ex);
		}

		return null;
	}

	public boolean update_query(String hostName, String protocol, String sid_service_name, String userId, String password, String sql_query,String port_num) throws ClassNotFoundException, SQLException{
		log.info("Running update SQL: "+sql_query);
		//CommonGroup test = new CommonGroup();
		String driver = readProp("GlobalSettings", "driver");
		Connection conn=null;
//		int port_num = 1521;
		Class.forName(driver);
		if(protocol.toUpperCase().contains("SID")){
			//Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@dbjgo601d-scan.bjg.swissbank.com:1521:DFTREA5B","CBSFT","UBS_Ft17");		
			conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+":"+sid_service_name+"",userId,password);
		}
		
		else if(protocol.toUpperCase().contains("SERVICE_NAME")){
			// jdbc:oracle:thin:@//HOSTNAME:PORT/SERVICENAME
			conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+"/"+sid_service_name+"",userId,password);
		}
		
		try{
			if(!conn.isClosed()){
				Statement st = conn.createStatement();
				String sqlStr = sql_query;
				st.executeUpdate(sqlStr);
				conn.commit();
				conn.close();
				return true;
			}
		}

		catch(SQLException sql_ex){
			System.out.println(sql_ex);
			return false;
		}
		return false;
	}


	public boolean insert_query(String hostName, String protocol, String sid_service_name, String userId, String password, String sql_query) throws ClassNotFoundException, SQLException{
		log.info("Running insert SQL: "+sql_query);
		//CommonGroup test = new CommonGroup();
		String driver = readProp("GlobalSettings.properties", "driver");
		Connection conn=null;
		int port_num = 1521;
		Class.forName(driver);
		if(protocol.toUpperCase().contains("SID")){
			//Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@dbjgo601d-scan.bjg.swissbank.com:1521:DFTREA5B","CBSFT","UBS_Ft17");		
			conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+":"+sid_service_name+"",userId,password);
		}
		
		else if(protocol.toUpperCase().contains("SERVICE_NAME")){
			// jdbc:oracle:thin:@//HOSTNAME:PORT/SERVICENAME
			conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+"/"+sid_service_name+"",userId,password);
		}
		
		try{
			if(!conn.isClosed()){
				Statement st = conn.createStatement();
				String sqlStr = sql_query;
				st.executeQuery(sqlStr);
				conn.commit();
				conn.close();
				return true;
			}
		}

		catch(SQLException sql_ex){
			System.out.println(sql_ex);
			return false;
		}
		return false;
	}	


	@SuppressWarnings({"null","resource"})
	public int getLastRow(String file_name, String sheetName) throws FileNotFoundException{
			//String file_path=readProp("GlobalSettings","dataSheetPath");
	        XSSFWorkbook workbook = null;
	        XSSFSheet sheet = null;     
			//InputStream excelFile = this.getClass().getClassLoader().getResourceAsStream(file_name+".xlsx");
	        
			FileInputStream excelFile = new FileInputStream(new File(file_path+file_name));

			try {
				workbook = new XSSFWorkbook(excelFile);
	            sheet = workbook.getSheet(sheetName);
	            int lastRow=sheet.getPhysicalNumberOfRows();
	            return lastRow;
			}
	        
	        catch (IOException e1){
				e1.printStackTrace();
			}

	    try {
			workbook.close();
		} catch (IOException e){

			e.printStackTrace();
		}
		return (Integer) null;
	}
	
	@SuppressWarnings({"null","resource"})
	public int getLastRow(String file_path,String file_name, String sheetName) throws FileNotFoundException{
		//String file_path=readProp("GlobalSettings","dataSheetPath");
        XSSFWorkbook workbook = null;
        XSSFSheet sheet = null;     
		//InputStream excelFile = this.getClass().getClassLoader().getResourceAsStream(file_name+".xlsx");
        
		FileInputStream excelFile = new FileInputStream(new File(file_path+file_name));

		try {
			workbook = new XSSFWorkbook(excelFile);
            sheet = workbook.getSheet(sheetName);
            int lastRow=sheet.getPhysicalNumberOfRows();
            return lastRow;
		}
        
        catch (IOException e1){
			e1.printStackTrace();
		}

    try {
		workbook.close();
	} catch (IOException e){

		e.printStackTrace();
	}
	return (Integer) null;
}


//soap requiremntmappin automa
	public void executeQuery(String insert_sql) throws ClassNotFoundException, SQLException{
		//CommonGroup test = new CommonGroup();
		String hostName = readProp("GlobalSettings.properties", "host");
		String port_num = readProp("GlobalSettings.properties", "port");
		String sid = readProp("GlobalSettings.properties", "sid");
		String userId = readProp("GlobalSettings.properties", "userId");
		String password = readProp("GlobalSettings.properties", "password");
		String driver = readProp("GlobalSettings.properties", "driver");

		Class.forName(driver);		
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@"+hostName+":"+port_num+":"+sid+"",userId,password);
		Statement statement = conn.createStatement();
		
		if(conn!=null){
			
			statement.execute(insert_sql);
			System.out.println("");
		}
		
		else{
			System.out.println("Method: CommonGroup.executeQuery. Err: db connection was unsuccessful ***");
		}

		conn.close();
	}


	public String getDate(){
		DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		Calendar cal = Calendar.getInstance();
        //System.out.println(sdf.format(cal.getTime()));
		return sdf.format(cal.getTime());
	}


	public void email() throws MessagingException{
		final String username="gaurav.misra@ubs.com";
		final String password="Kabalida13";
		//String host="mailhost.ldn.swissbank.com";
		//String port="25";
		//String from= "gaurav.misra@ubs.com";
		//String to= "dilip-srinivas.s@ubs.com";
		//String subject= "java-smtp-protocol-test";
		//String mail_body= "java-smtp-protocol-test";
		//String file_name="C:/Users/Public/Selenium/neon_workspace2/Maven_Arti_01/target/surefire-reports/testng-junit-results/emailable-report.html";

		String host=readProp("GlobalSettings", "host_name");
		String port=readProp("GlobalSettings", "srv_port");
		String from =readProp("GlobalSettings", "from_id");
		String to = readProp("GlobalSettings", "to_id");
		String subject = readProp("GlobalSettings", "email_subject");
		String mail_body = readProp("GlobalSettings", "email_body");
		String report_attachment_path= readProp("GlobalSettings", "attachment_path");

		Properties prop = new Properties();
			prop.put("mail.smtp.auth", "true");
			prop.put("mail.smtp.auth", "true");
		    prop.put("mail.smtp.starttls.enable", "true");
		    prop.put("mail.smtp.host", host);
		    prop.put("mail.smtp.port", port);

	    Session session = Session.getInstance(prop,
	        new javax.mail.Authenticator() {
	           protected PasswordAuthentication getPasswordAuthentication() {
	              return new PasswordAuthentication(username, password);
	           }
	        });

	    Message msg = new MimeMessage(session);
	    msg.setFrom(new InternetAddress(from));
	    msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
	    msg.setSubject(subject);
	    
	    BodyPart msgBody = new MimeBodyPart();
	    msgBody.setText(mail_body);

	    Multipart multipart = new MimeMultipart();
	    multipart.addBodyPart(msgBody);
	    msgBody = new MimeBodyPart();
	    DataSource src=new FileDataSource(report_attachment_path);
	    msgBody.setDataHandler(new DataHandler(src));
	    msgBody.setFileName(report_attachment_path);
	    multipart.addBodyPart(msgBody);
	    msg.setContent(multipart);

	    Transport.send(msg);
	    prop.clear();
	    System.out.println("Email is triggered");
	}
	
	
/*	public static void addAttachment(Multipart multipart,BodyPart msgBody, String report_attachment_path) throws MessagingException{		
	    DataSource src=new FileDataSource(report_attachment_path);
	    msgBody.setDataHandler(new DataHandler(src));
	    msgBody.setFileName(report_attachment_path);
	    multipart.addBodyPart(msgBody);
	}*/
		

	@SuppressWarnings("resource")
	public String readCSV(String filePath,String delimiter, String trnx_num, String search_value) throws IOException, NullPointerException{
		
		try{
			FileInputStream fstream = new FileInputStream(filePath);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine=null;
			
			while((strLine = br.readLine()) != null){	
/*				String[] split = strLine.split(",");
				System.out.println(Arrays.toString(split));*/
				if(strLine.contains(trnx_num)){
					StringTokenizer token = new StringTokenizer(strLine,delimiter);
					while(token.hasMoreTokens()){
						String value=token.nextToken().trim();
						if(value.contains(search_value)){
							//return value+" - Pass";
							return value;
						}
					}
				}
			}

			br.close();
			in.close();
			fstream.close();
		}

		catch (Exception e){
			System.err.println("Error: " + e.getMessage());
		  }

		return null;
	}
	
	
	public void killExcel() throws IOException, InterruptedException{
		Process process = Runtime.getRuntime().exec("EXCEL.EXE");
		process.destroy();
		Thread.sleep(3000);
		log.info("Killing Excel windows process");
	}
	
	
	public void popUpMsg(String message, String title){
		JOptionPane.showMessageDialog(null, message, "InfoBox: " + title, JOptionPane.INFORMATION_MESSAGE);
		log.info(message);
	}
	
// 											*****  End Of Class  *****
}