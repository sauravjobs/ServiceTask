package helpers;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

import com.cucumber.listener.Reporter;

public class ScreenshotHelper extends Browser{
	public static void screenShot_Failed() throws IOException
	{
		try
		{
	String dateName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
	 
	File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	
	String filepath_name="P:/Saurav/Java_Automation/workspace/UI_Automation_Selenium_Cucumber/test-output/Reports/screenshot_Failed"+dateName+".jpeg";
	
	File screenshot_destinationPath = new File(filepath_name); 
	FileUtils.copyFile(screenshot, screenshot_destinationPath);
	Reporter.addScreenCaptureFromPath(filepath_name);
		}
		
		catch (WebDriverException somePlatformsDontSupportScreenshots) {
			System.err.println(somePlatformsDontSupportScreenshots.getMessage());
		} 
}
	
	
	
	public static void screenShot_all() throws IOException
	{
		try
		{
	String dateName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
	 
	File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	
	String filepath_name="P:/Saurav/Java_Automation/workspace/UI_Automation_Selenium_Cucumber/test-output/Reports/screenshot_All"+dateName+".jpeg";
	
	File screenshot_destinationPath = new File(filepath_name); 
	FileUtils.copyFile(screenshot, screenshot_destinationPath);
	Reporter.addScreenCaptureFromPath(filepath_name);
		}
		
		catch (WebDriverException somePlatformsDontSupportScreenshots) {
			System.err.println(somePlatformsDontSupportScreenshots.getMessage());
		} 
}
}