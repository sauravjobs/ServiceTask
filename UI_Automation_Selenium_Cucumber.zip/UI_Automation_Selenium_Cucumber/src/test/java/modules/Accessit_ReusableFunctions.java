package modules;

import helpers.Browser;

import java.util.Calendar;
import java.util.Date;
import java.io.File;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import helpers.Common_Group;
import pageobjects.AccessITPageObjects;
import pageobjects.Data;
import pageobjects.TestDatas;

public class Accessit_ReusableFunctions extends Browser {
	public static Common_Group ui = new Common_Group();
	public static String MES_Query = null;
	public static String READONLY_Query = null;
	public static String MES_Query_TO_GET_NEW_UBS_CC_FUNC = null;
	public static String MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC = null;
	public static String MES_EmployeeJMLQuery = null;
	public static String MES_EMPLOYEEJMLHISTORY_TBLQuery = null;
	public static String MES_EmployeeJML_Tbl_statusQuery = null;
	public static String SPT_Certification_ROQuery = null;
	public static String readonly_host = null;
	public static String readonly_sid = null;
	public static String readonly_user = null;
	public static String readonly_pw = null;
	public static String readonly_PortNO = null;
	public static String ptr_host = null;
	public static String ptr_sid = null;
	public static String ptr_user = null;
	public static String ptr_pw = null;
	public static String ptr_PortNO = null;
	public static String mes_host = null;
	public static String mes_sid = null;
	public static String mes_user = null;
	public static String mes_pw = null;
	public static String mes_PortNO = null;	
	public static String ast_host = null;
	public static String ast_sid = null;
	public static String ast_user = null;
	public static String ast_pw = null;
	public static String ast_PortNO = null;	
	public static String db_READONLY_userguid = null;
	public static String db_MES_UBSCOSTCENTRE_OLD = null;
	public static String db_MES_UBSFunction_OLD = null;
	public static String db_MES_UBSBUSINESSNAME = null;
	public static String db_MES_UBSCOSTCENTRE_NEW = null;
	public static String db_MES_UBSFunction_NEW = null;
	public static String db_MES_UBSCOSTCENTRE_UPDATED = null;
	public static String db_MES_UBSFunction_UPDATED = null;
	public static String db_MES_EmployeeJML_Tbl_STATUS = null;
	public static String db_MES_EmployeeJML_Tbl_UBSCOSTCENTRENEW = null;
	public static String db_MES_EmployeeJML_Tbl_UBSFUNCTIONNEW = null;
	public static String db_MES_EmployeeJMLHISTORY_Tbl_EVENTTYPE = null;
	public static String db_MES_EmployeeJMLHISTORY_Tbl_STATUS = null;
	public static String searchTextMover = null;
	public static String SPT_WORK_ITEM_ROQuery = null;
	public static String db_owner_oftheCertifcate = null;
	public static String db_certificateName = null;
	public static String db_extended4 = null;	
	public static String db_owner_oftheCertifcate_newAccessMover = null;
	public static String searchTextcertificateName = null;
	public static String SPT_identity_entitlement_Query = null;
	public static String PTR_MEMBER_AUU_Query = null;
	public static String Revoked_Entitlement_Query = null;
	public static String db_exception_attribute_value = null;
	public static String db_entitlementstatus = null;
	public static String db_modifieddate = null;
	public static String snow_request_tbl_Query = null;
	public static String db_READONLY_Entitlementguid = null;
	
	

	public static void prepare_data(WebDriver driver, String Data, String JMLTYpe) throws Exception {

		// ----------------JMLTYpe= MOVER AND
		// Data=MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION-----------------
		if (JMLTYpe.equals("MOVER")) {
			if (Data.equals("MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION")) {

				ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

				String path_yaml = "P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/src/test/resources/testData/";
				TestDatas obj = mapper.readValue(new File(path_yaml + "Testdata.yaml"), TestDatas.class);

				Iterator<Data> iterator = obj.getTestdatas().iterator();

				while (iterator.hasNext()) {

					Map<String, String> data = iterator.next().getData();

					if (Data.equals("MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION")&& data.get("DataType").equals("MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION")) {
						READONLY_Query = data.get("READONLY_Query");
						MES_Query = data.get("MES_Query");
						MES_Query_TO_GET_NEW_UBS_CC_FUNC = data.get("MES_Query_TO_GET_NEW_UBS_CC_FUNC");
						MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC = data.get("MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC");
						readonly_host = data.get("readonly_host");
						readonly_sid = data.get("readonly_sid");
						readonly_user = data.get("readonly_user");
						readonly_pw = data.get("readonly_pw");
						readonly_PortNO = data.get("readonly_PortNO");
						mes_host = data.get("mes_host");
						mes_sid = data.get("mes_sid");
						mes_user = data.get("mes_user");
						mes_pw = data.get("mes_pw");
						mes_PortNO = data.get("mes_PortNO");
						ptr_host = data.get("ptr_host");
						ptr_sid = data.get("ptr_sid");
						ptr_user = data.get("ptr_user");
						ptr_pw = data.get("ptr_pw");
						ptr_PortNO = data.get("ptr_PortNO");
						
						ast_host = data.get("ast_host");
						ast_sid = data.get("ast_sid");
						ast_user = data.get("ast_user");
						ast_pw = data.get("ast_pw");
						ast_PortNO = data.get("ast_PortNO");
						
						System.out.println("Query FOR MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION:  " + READONLY_Query);
						log.info("Query FOR MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION:  " + READONLY_Query);
						log.info("MES_Query:  " + MES_Query);
						log.info("MES_Query_TO_GET_NEW_UBS_CC_FUNC:  " + MES_Query_TO_GET_NEW_UBS_CC_FUNC);

						log.info("READONLY Host:" + readonly_host);
						log.info("READONLY SID:" + readonly_sid);
						log.info("READONLY USER:" + readonly_user);
						log.info("READONLY PASWD:" + readonly_pw);

						log.info("MES Host:" + mes_host);
						log.info("MES SID:" + mes_sid);
						log.info("MES USER:" + mes_user);
						log.info("MES PASWD:" + mes_pw);
						
						log.info("PTR Host:" + ptr_host);
						log.info("PTR SID:" + ptr_sid);
						log.info("PTR USER:" + ptr_user);
						log.info("PTR PASWD:" + ptr_pw);
						
						log.info("AST Host:" + ast_host);
						log.info("AST SID:" + ast_sid);
						log.info("AST USER:" + ast_user);
						log.info("AST PASWD:" + ast_pw);

					}
				}

				/*----------------------------------------------------------------------READONLY SCHEMA----------------------------------------------------*/
				ResultSet data_From_ReadonlySchema = ui.select_query_new(readonly_host, "SERVICE_NAME", readonly_sid,readonly_user, readonly_pw, READONLY_Query, readonly_PortNO);

				while (data_From_ReadonlySchema.next()) {
					log.info("USERGUID data_From_ReadonlySchema while..............");
					db_READONLY_userguid = data_From_ReadonlySchema.getString("USERGUID");
					db_READONLY_Entitlementguid = data_From_ReadonlySchema.getString("ENTITLEMENTGUID");

				}

				log.info("USERGUID data_From_ReadonlySchema: " + db_READONLY_userguid);
				log.info("USERGUID data_From_ReadonlySchema: " + db_READONLY_Entitlementguid);

				/*-------------------------------------------------------------------MES SCHEMA TO GET OLD UBSCOSTCENTRE and UBSFunction----------------------------------------------------*/
				MES_Query = MES_Query.replaceAll("userguidFROM_READONLY", db_READONLY_userguid);
				ResultSet data_FromMESSchema = ui.select_query_new(mes_host, "SERVICE_NAME", mes_sid, mes_user, mes_pw,MES_Query, mes_PortNO);

				while (data_FromMESSchema.next()) {

					log.info("ORIGINAL OLD UBSCOSTCENTRE and UBSFunction data_From_MESSchema while..............");
					db_MES_UBSCOSTCENTRE_OLD = data_FromMESSchema.getString("UBSCOSTCENTRE");
					db_MES_UBSFunction_OLD = data_FromMESSchema.getString("UBSFunction");
					db_MES_UBSBUSINESSNAME = data_FromMESSchema.getString("UBSBUSINESSNAME");

				}
				log.info("OLD UBSCOSTCENTRE data_From_MESSchema: " + db_MES_UBSCOSTCENTRE_OLD);
				log.info("OLD UBSFunction data_From_MESSchema: " + db_MES_UBSFunction_OLD);
				log.info("db_MES_UBSBUSINESSNAME data_From_MESSchema: " + db_MES_UBSBUSINESSNAME);

				/*-------------------------------------------------------------------MES SCHEMA TO GET NEW UBSCOSTCENTRE and UBSFunction----------------------------------------------------*/
				MES_Query_TO_GET_NEW_UBS_CC_FUNC = MES_Query_TO_GET_NEW_UBS_CC_FUNC.replaceAll("userguidFROM_READONLY",db_READONLY_userguid);
				ResultSet data_FromMESSchema_NEWValues = ui.select_query_new(mes_host, "SERVICE_NAME", mes_sid,mes_user, mes_pw, MES_Query_TO_GET_NEW_UBS_CC_FUNC, mes_PortNO);

				while (data_FromMESSchema_NEWValues.next()) {

					log.info("NEW UBSCOSTCENTRE and UBSFunction data_From_MESSchema while..............");
					db_MES_UBSCOSTCENTRE_NEW = data_FromMESSchema_NEWValues.getString("UBSCOSTCENTRE");
					db_MES_UBSFunction_NEW = data_FromMESSchema_NEWValues.getString("UBSFunction");

				}
				log.info("NEW UBSCOSTCENTRE data_From_MESSchema: " + db_MES_UBSCOSTCENTRE_NEW);
				log.info("NEW UBSFunction data_From_MESSchema: " + db_MES_UBSFunction_NEW);

				/*-------------------------------------------------------------------MES SCHEMA TO UPDATE NEW UBSCOSTCENTRE and UBSFunction----------------------------------------------------*/

				MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC = MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC.replaceAll("userguidFROM_READONLY", db_READONLY_userguid);
				MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC = MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC.replaceAll("UBSFunction_NEW", db_MES_UBSFunction_NEW);
				MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC = MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC.replaceAll("UBSCOSTCENTRE_NEW", db_MES_UBSCOSTCENTRE_NEW);
				boolean data_FromMESSchema_Update = ui.update_query(mes_host, "SERVICE_NAME", mes_sid, mes_user, mes_pw,MES_Query_TO_UPDATE_WITH_NEW_UBS_CC_FUNC, mes_PortNO);
				// -----------------------------------------VERIFY IF THE NEW VALUES HAVE BEEN UPDATED OR NOT-----------------------------------------
				MES_Query = MES_Query.replaceAll("userguidFROM_READONLY", db_READONLY_userguid);
				ResultSet data_FromMESSchema_Updated = ui.select_query_new(mes_host, "SERVICE_NAME", mes_sid, mes_user,mes_pw, MES_Query, mes_PortNO);

				while (data_FromMESSchema_Updated.next()) {
					
					log.info("UPDATED UBSCOSTCENTRE and UBSFunction data_From_MESSchema while..............");
					db_MES_UBSCOSTCENTRE_UPDATED = data_FromMESSchema_Updated.getString("UBSCOSTCENTRE");
					db_MES_UBSFunction_UPDATED = data_FromMESSchema_Updated.getString("UBSFunction");

				}
				log.info("UPDATED UBSCOSTCENTRE data_From_MESSchema: " + db_MES_UBSCOSTCENTRE_UPDATED);
				log.info("UPDATED UBSFunction data_From_MESSchema: " + db_MES_UBSFunction_UPDATED);
				
//				------------------------------Assertion if New Costcentre and Functions are updated----------------------------
				assert (db_MES_UBSCOSTCENTRE_NEW).equals(db_MES_UBSCOSTCENTRE_UPDATED);
				assert (db_MES_UBSFunction_NEW).equals(db_MES_UBSFunction_UPDATED);			
				log.info("Test Data created for db_MES_UBSCOSTCENTRE_UPDATED and db_MES_UBSFunction_UPDATED");
				

			}

		}

		/*
		 * if(Data.equals("MOVER_DATA_BY_CHANGING_SOMETHING_ELSE")) {}
		 */

		/*
		 * if(JMLTYpe.equals("JOINER")) {
		 * if(Data.equals("MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION")) {
		 * 
		 * } }
		 * 
		 * if(JMLTYpe.equals("LEAVER")) {
		 * if(Data.equals("MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION")) {
		 * 
		 * } }
		 * 
		 * if(JMLTYpe.equals("REJOINER")) {
		 * if(Data.equals("MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION")) {
		 * 
		 * } }
		 * 
		 * 
		 * if(JMLTYpe.equals("FOBO")) {
		 * if(Data.equals("MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION")) {
		 * 
		 * } }
		 */

	}

	public static void verify_data_in_tableview(WebDriver driver, String ExpectedResult,String Databasetable_view, String Query)
			throws Exception {
//		-------------------------------------------------------------------------------------------------------------------------------
		if (Query.equals("VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS")) {

			ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			String path_yaml = "P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/src/test/resources/testData/";
			TestDatas obj = mapper.readValue(new File(path_yaml + "Testdata.yaml"), TestDatas.class);

			Iterator<Data> iterator = obj.getTestdatas().iterator();

			while (iterator.hasNext()) {

				Map<String, String> data = iterator.next().getData();

				if (data.get("DataType").equals("VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS")) {
					
//					-------------------------------------------------------------------------------------------------------------------
					if (Databasetable_view.equals("MES_EMPLOYEEJML_view")) {

						MES_EmployeeJMLQuery = data.get("MES_EmployeeJMLQuery");
						MES_EmployeeJMLQuery = MES_EmployeeJMLQuery.replaceAll("userguidFROM_READONLY",
								db_READONLY_userguid);
						ResultSet data_From_MES_EmployeeJML_Tbl = ui.select_query_new(mes_host, "SERVICE_NAME", mes_sid,mes_user, mes_pw, MES_EmployeeJMLQuery, mes_PortNO);

						while (data_From_MES_EmployeeJML_Tbl.next()) {
							log.info("MES SCHEMA- MES_EmployeeJML_Tbl while..............");
							db_MES_EmployeeJML_Tbl_STATUS = data_From_MES_EmployeeJML_Tbl.getString("STATUS");
							db_MES_EmployeeJML_Tbl_UBSCOSTCENTRENEW = data_From_MES_EmployeeJML_Tbl.getString("UBSCOSTCENTRENEW");
							db_MES_EmployeeJML_Tbl_UBSFUNCTIONNEW = data_From_MES_EmployeeJML_Tbl.getString("UBSFUNCTIONNEW");
					
						}

						log.info("db_MES_EmployeeJML_Tbl_STATUS : " + db_MES_EmployeeJML_Tbl_STATUS);
						log.info("db_MES_EmployeeJML_Tbl_UBSCOSTCENTRENEW : " + db_MES_EmployeeJML_Tbl_UBSCOSTCENTRENEW);
						log.info("db_MES_EmployeeJML_Tbl_UBSFUNCTIONNEW : " + db_MES_EmployeeJML_Tbl_UBSFUNCTIONNEW);

						assert ("NotProcessed").equals(db_MES_EmployeeJML_Tbl_STATUS) : "db_MES_EmployeeJML_Tbl_STATUS";
						assert (db_MES_UBSCOSTCENTRE_NEW).equals(db_MES_EmployeeJML_Tbl_UBSCOSTCENTRENEW) : "db_MES_EmployeeJML_Tbl_UBSCOSTCENTRENEW";
						assert (db_MES_UBSFunction_NEW).equals(db_MES_EmployeeJML_Tbl_UBSFUNCTIONNEW) : "db_MES_EmployeeJML_Tbl_UBSFUNCTIONNEW";
						
						log.info("An entry is inserted in the MES_EMPLOYEEJML view with the newly identified mover where STATUS = Not Processed"+ExpectedResult);

					} else if (Databasetable_view.equals("MES_EMPLOYEEJMLHISTORY_TBL")) {

						MES_EMPLOYEEJMLHISTORY_TBLQuery = data.get("MES_EMPLOYEEJMLHISTORY_TBLQuery");
						MES_EMPLOYEEJMLHISTORY_TBLQuery = MES_EMPLOYEEJMLHISTORY_TBLQuery.replaceAll("userguidFROM_READONLY", db_READONLY_userguid);
						ResultSet data_From_MES_EMPLOYEEJMLHISTORY_Tbl = ui.select_query_new(mes_host, "SERVICE_NAME",mes_sid, mes_user, mes_pw, MES_EMPLOYEEJMLHISTORY_TBLQuery, mes_PortNO);

						while (data_From_MES_EMPLOYEEJMLHISTORY_Tbl.next()) {
							log.info("MES SCHEMA- MES_EMPLOYEEJMLHISTORY_Tbl while..............");
							db_MES_EmployeeJMLHISTORY_Tbl_EVENTTYPE = data_From_MES_EMPLOYEEJMLHISTORY_Tbl.getString("EVENTTYPE");

						}

						assert ("Mover - CC & Function change").equals(db_MES_EmployeeJMLHISTORY_Tbl_EVENTTYPE) : "db_MES_EmployeeJMLHISTORY_Tbl_EVENTTYPE";
						log.info("db_MES_EmployeeJMLHISTORY_Tbl_EVENTTYPE is correctly Updated to Mover - CC & Function change : "+ExpectedResult);

					} else if (Databasetable_view.equals("MES_EmployeeJML_Tbl_status")) {

						MES_EmployeeJML_Tbl_statusQuery = data.get("MES_EmployeeJML_Tbl_statusQuery");
						MES_EmployeeJML_Tbl_statusQuery = MES_EmployeeJML_Tbl_statusQuery.replaceAll("userguidFROM_READONLY", db_READONLY_userguid);
						ResultSet data_From_MES_EMPLOYEEJMLStatus_Tbl = ui.select_query_new(mes_host, "SERVICE_NAME",mes_sid, mes_user, mes_pw, MES_EmployeeJML_Tbl_statusQuery, mes_PortNO);

						while (data_From_MES_EMPLOYEEJMLStatus_Tbl.next()) {
							log.info("MES SCHEMA- Status MES_EMPLOYEEJMLHISTORY_Tbl while..............");
							db_MES_EmployeeJMLHISTORY_Tbl_STATUS = data_From_MES_EMPLOYEEJMLStatus_Tbl.getString("STATUS");

						}

						log.info("db_MES_EmployeeJMLHISTORY_Tbl_STATUS : " + db_MES_EmployeeJMLHISTORY_Tbl_STATUS);

						assert ("Deleted").equals(db_MES_EmployeeJMLHISTORY_Tbl_STATUS) : "db_MES_EmployeeJMLHISTORY_Tbl_STATUS";
						log.info("db_MES_EmployeeJMLHISTORY_Tbl_STATUS is now Deleted : "+ExpectedResult);

					} else if (Databasetable_view.equals("SPT_WORK_ITEM_RO")) {

						SPT_WORK_ITEM_ROQuery = data.get("SPT_WORK_ITEM_ROQuery");

						// -------------------------------------------------------Reusing same query--------------------------------------------------------------
						
						if (db_certificateName != null) {
							SPT_WORK_ITEM_ROQuery = SPT_WORK_ITEM_ROQuery.replaceAll("JMLDescription",db_certificateName);

							ResultSet data_From_SPT_WORK_ITEM_RO_Tbl_newAccessMover = ui.select_query_new(readonly_host,"SERVICE_NAME", readonly_sid, readonly_user, readonly_pw, SPT_WORK_ITEM_ROQuery,readonly_PortNO);
							log.info("sUCCESS TILL HERE--------------------------");
							while (data_From_SPT_WORK_ITEM_RO_Tbl_newAccessMover.next()) {
								log.info("data_From_SPT_WORK_ITEM_RO_Tbl  READONLY while..............");
								db_owner_oftheCertifcate_newAccessMover = data_From_SPT_WORK_ITEM_RO_Tbl_newAccessMover.getString("EXTENDED4");

							}

							log.info("db_owner_oftheCertifcate_newAccessMover : "+ db_owner_oftheCertifcate_newAccessMover);
							Assert.assertNotNull(db_owner_oftheCertifcate_newAccessMover);
							log.info("db_owner_oftheCertifcate_newAccessMover is populated and not Null: "+ExpectedResult);
							
						} else {
							SPT_WORK_ITEM_ROQuery = SPT_WORK_ITEM_ROQuery.replaceAll("JMLDescription", searchTextMover);
							ResultSet data_From_SPT_WORK_ITEM_RO_Tbl = ui.select_query_new(readonly_host,"SERVICE_NAME", readonly_sid, readonly_user, readonly_pw, SPT_WORK_ITEM_ROQuery,readonly_PortNO);

							while (data_From_SPT_WORK_ITEM_RO_Tbl.next()) {
								log.info("data_From_SPT_WORK_ITEM_RO_Tbl  READONLY while..............");
								db_owner_oftheCertifcate = data_From_SPT_WORK_ITEM_RO_Tbl.getString("EXTENDED4");
								log.info(db_owner_oftheCertifcate);
							}
							
							Assert.assertNotNull(db_owner_oftheCertifcate);
							log.info("db_owner_oftheCertifcate is populated and not Null"+db_owner_oftheCertifcate);
							log.info("db_owner_oftheCertifcate is populated and not Null"+ExpectedResult);
						}

					} else if (Databasetable_view.equals("SPT_Certification_RO")) {

						SPT_Certification_ROQuery = data.get("SPT_Certification_ROQuery");
						SPT_Certification_ROQuery = SPT_Certification_ROQuery.replaceAll("userguidFROM_READONLY",db_READONLY_userguid);
						SPT_Certification_ROQuery = SPT_Certification_ROQuery.replaceAll("db_READONLY_Entitlementguid",db_READONLY_Entitlementguid);
						
						ResultSet data_From_SPT_Certification_RO = ui.select_query_new(readonly_host, "SERVICE_NAME",readonly_sid, readonly_user, readonly_pw, SPT_Certification_ROQuery, readonly_PortNO);
						log.info("HERE WHILE..............");
						while (data_From_SPT_Certification_RO.next()) {
							log.info("data_From_SPT_Certification_RO  READONLY while..............");
							db_certificateName = data_From_SPT_Certification_RO.getString("NAME");

						}
						Assert.assertNotNull(db_certificateName);
						log.info("db_certificateName is populated and not Null: " + db_certificateName +" : " +ExpectedResult);

					}else if (Databasetable_view.equals("spt_identity_entitlement")) {

						SPT_identity_entitlement_Query = data.get("SPT_identity_entitlement_Query");
						SPT_identity_entitlement_Query = SPT_identity_entitlement_Query.replaceAll("userguidFROM_READONLY",db_READONLY_userguid);
						SPT_identity_entitlement_Query = SPT_identity_entitlement_Query.replaceAll("db_certificateName",db_certificateName);
						log.info("SPT_identity_entitlement_Query"+SPT_identity_entitlement_Query);
						ResultSet data_From_SPT_identity_entitlement = ui.select_query_new(readonly_host, "SERVICE_NAME",readonly_sid, readonly_user, readonly_pw, SPT_identity_entitlement_Query, readonly_PortNO);
						log.info("HERE WHILE..............");
						while (data_From_SPT_identity_entitlement.next()) {
							log.info("data_From_SPT_identity_entitlement  READONLY while..............");
							db_extended4 = data_From_SPT_identity_entitlement.getString("EXTENDED4");

						}

						log.info("db_extended4 : " + db_extended4);
						Assert.assertNull(db_extended4);
						log.info("Entitlement has been Removed and Revoked Successfully : "+ExpectedResult);

					}else if (Databasetable_view.equals("PTR_MEMBER_AUU")) {

						PTR_MEMBER_AUU_Query = data.get("PTR_MEMBER_AUU_Query");
						
						Revoked_Entitlement_Query= data.get("Revoked_Entitlement_Query");
						Revoked_Entitlement_Query= Revoked_Entitlement_Query.replaceAll("userguidFROM_READONLY",db_READONLY_userguid);
						Revoked_Entitlement_Query= Revoked_Entitlement_Query.replaceAll("db_certificateName",db_certificateName);
						
						ResultSet data_From_Revoked_Entitlement_Query = ui.select_query_new(readonly_host, "SERVICE_NAME",readonly_sid, readonly_user, readonly_pw, Revoked_Entitlement_Query, readonly_PortNO);
						log.info("HERE WHILE..............");
						while (data_From_Revoked_Entitlement_Query.next()) {
							log.info("data_From_Revoked_Entitlement_Query  READONLY while..............");
							db_exception_attribute_value = data_From_Revoked_Entitlement_Query.getString("EXCEPTION_ATTRIBUTE_VALUE");						

						}
						
						PTR_MEMBER_AUU_Query = PTR_MEMBER_AUU_Query.replaceAll("userguidFROM_READONLY",db_READONLY_userguid);
						PTR_MEMBER_AUU_Query = PTR_MEMBER_AUU_Query.replaceAll("Revoked_Entitlements",db_exception_attribute_value);
												
						ResultSet data_From_PTR_MEMBER_AUU_Query = ui.select_query_new(ptr_host, "SERVICE_NAME",ptr_sid, ptr_user, ptr_pw, PTR_MEMBER_AUU_Query, ptr_PortNO);
						log.info("HERE WHILE..............");
						while (data_From_PTR_MEMBER_AUU_Query.next()) {
							log.info("PTR_MEMBER_AUU_Query  READONLY while..............");
							db_entitlementstatus = data_From_PTR_MEMBER_AUU_Query.getString("ENTITLEMENTSTATUS");
							db_modifieddate = data_From_PTR_MEMBER_AUU_Query.getString("MODIFIEDDATE");

						}
						DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
						Date date = new Date();
						String currentDate = dateFormat.format(date);
						
						
						log.info("db_entitlementstatus : " + db_entitlementstatus);
						log.info("db_modifieddate : " + db_modifieddate);
						assert ("Pending-Removal").equals(db_entitlementstatus);
						assert (currentDate).contains(db_modifieddate);
						
						log.info("Correct status & Modifieddate is displayed : "+ExpectedResult);

					}else if (Databasetable_view.equals("snow_request_tbl")) {

						snow_request_tbl_Query = data.get("snow_request_tbl_Query");
						snow_request_tbl_Query = snow_request_tbl_Query.replaceAll("userguidFROM_READONLY",db_READONLY_userguid);
						
						ResultSet data_From_snow_request_tbl_Query = ui.select_query_new(ast_host, "SERVICE_NAME",ast_sid, ast_user, ast_pw, snow_request_tbl_Query, ast_PortNO);
						log.info("HERE WHILE..............");
						while (data_From_snow_request_tbl_Query.next()) {
							log.info("data_From_snow_request_tbl_Query  while..............");
//							Need Details here---SINCE THE CUBE REFRESH WASNT RUN AND DB WAS REFRESHED I DINT HAVE DATA TO SCRIPT
//							MONICA TO SCRIPT AS PER HER NEEDS AND REQUIREMENTS

						}

//						Assertions required only after getting details

					}else if (Databasetable_view.equals("LAAP_ACCESSRIGHT_TBL")) {
//						Need Details here---SINCE THE CUBE REFRESH WASNT RUN AND DB WAS REFRESHED I DINT HAVE DATA TO SCRIPT
//						MONICA TO SCRIPT AS PER HER NEEDS AND REQUIREMENTS
//						Assertions required only after getting details  

					}else if (Databasetable_view.equals("LAAP_MAIL_MAPPING_TBL")) {

//						MONICA TO SCRIPT AS PER HER NEEDS AND REQUIREMENTS
//						Assertions required only after getting details  

					}else if (Databasetable_view.equals("email_request_tbl")) {

//						MONICA TO SCRIPT AS PER HER NEEDS AND REQUIREMENTS
//						Assertions required only after getting details  

					}

					break;
				}

			}

		}
	}

	public static void login_to_IIQ(WebDriver driver, String User) throws Exception {

		if (User.equals("Admin")) {
			try {
				AccessITPageObjects.username.sendKeys("spadmin");
				AccessITPageObjects.password.sendKeys("admin");
				AccessITPageObjects.login.click();
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				log.info(" Elements are NOT Displayed and NOT enabled");
			}
		}

		if (User.equals("LM")) {
			try {
				AccessITPageObjects.username.sendKeys(db_owner_oftheCertifcate);
				// AccessITPageObjects.username.sendKeys("PSI43221605");
				AccessITPageObjects.password.sendKeys("Pa55word");
				AccessITPageObjects.login.click();
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				log.info(" Elements are NOT Displayed and NOT enabled");
			}
		}

		if (User.equals("Certificate_Owner")) {
			try {
				AccessITPageObjects.username.sendKeys(db_owner_oftheCertifcate_newAccessMover);
				AccessITPageObjects.password.sendKeys("Pa55word");
				AccessITPageObjects.login.click();
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				log.info(" Elements are NOT Displayed and NOT enabled");
			}
		}

	}

	public static void changePassword(WebDriver driver, String User) throws Exception {

		try {
			if (User.equals("LM")) {
				AccessITPageObjects.identities_menu.click();
				AccessITPageObjects.identitywarehouse_item.click();
				AccessITPageObjects.searchbox_identity.click();
				AccessITPageObjects.searchbox_identity.sendKeys(db_owner_oftheCertifcate);
				// AccessITPageObjects.searchbox_identity.sendKeys("PSI43221605");

				AccessITPageObjects.searchglass_identity.click();
				driver.findElement(By.xpath("//*[@class='x-grid-cell-inner ' and text()='" + db_owner_oftheCertifcate + "']")).click();
				// driver.findElement(By.xpath("//*[@class='x-grid-cell-inner '
				// and text()='PSI43221605']")).click();

				AccessITPageObjects.changepassowrdLink.click();
				AccessITPageObjects.passwordChange.click();

				Actions actions = new Actions(driver);
				actions.keyDown(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).perform();
				AccessITPageObjects.passwordChange.click();
				actions.keyDown(Keys.CONTROL).sendKeys(Keys.INSERT).perform();
				AccessITPageObjects.passwordChange.sendKeys("Pa55word");

				AccessITPageObjects.confirmpasswordChange.click();
				actions.keyDown(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).perform();
				AccessITPageObjects.confirmpasswordChange.click();
				actions.keyDown(Keys.CONTROL).sendKeys(Keys.INSERT).perform();
				AccessITPageObjects.confirmpasswordChange.sendKeys("Pa55word");

				AccessITPageObjects.saveChangedPaswd.click();

			}

			if (User.equals("Certificate_Owner")) {
				AccessITPageObjects.identities_menu.click();
				AccessITPageObjects.identitywarehouse_item.click();
				AccessITPageObjects.searchbox_identity.click();
				AccessITPageObjects.searchbox_identity.sendKeys(db_owner_oftheCertifcate_newAccessMover);
				// AccessITPageObjects.searchbox_identity.sendKeys("PSI43221605");

				AccessITPageObjects.searchglass_identity.click();
				driver.findElement(By.xpath("//*[@class='x-grid-cell-inner ' and text()='"+ db_owner_oftheCertifcate_newAccessMover + "']")).click();
				// driver.findElement(By.xpath("//*[@class='x-grid-cell-inner '
				// and text()='PSI43221605']")).click();

				AccessITPageObjects.changepassowrdLink.click();
				AccessITPageObjects.passwordChange.click();

				Actions actions = new Actions(driver);
				actions.keyDown(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).perform();
				AccessITPageObjects.passwordChange.click();
				actions.keyDown(Keys.CONTROL).sendKeys(Keys.INSERT).perform();
				AccessITPageObjects.passwordChange.sendKeys("Pa55word");

				AccessITPageObjects.confirmpasswordChange.click();
				actions.keyDown(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).perform();
				AccessITPageObjects.confirmpasswordChange.click();
				actions.keyDown(Keys.CONTROL).sendKeys(Keys.INSERT).perform();
				AccessITPageObjects.confirmpasswordChange.sendKeys("Pa55word");

				AccessITPageObjects.saveChangedPaswd.click();

			}

		}

		catch (Exception e) {
			e.printStackTrace();
			log.info(" Elements are NOT Displayed and NOT enabled");
		}
	}

	public static void approveRevokeReviews(WebDriver driver, String JMLTYpe, String Action, String User) throws Exception {
		try {
			if (User.equals("LM") && Action.equals("Approved")) {
				AccessITPageObjects.myWork.click();
				AccessITPageObjects.workitems_item.click();
				// AccessITPageObjects.workitems_item.sendKeys(searchTextMover);

				AccessITPageObjects.textBox_workItem.sendKeys(searchTextMover);
				AccessITPageObjects.workItem_searchglass.click();
				Thread.sleep(5000);
				WebElement elementreview = (new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='x-grid-cell-inner ' and text()='Mover review for "+ db_MES_UBSBUSINESSNAME + "']"))));

				Assert.assertTrue(elementreview.isDisplayed());
				log.info("The review is present in LM dashboard");

				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
				Date date = new Date();
				String currentDate = dateFormat.format(date);
				System.out.println(currentDate);
				List<WebElement> review_CreatedToday = driver.findElements(By.xpath("//*[@class='x-grid-cell-inner ' and text()='" + currentDate + "']"));

				for (int i = 0; i < review_CreatedToday.size(); i++) {
					if (elementreview.getText().equals("Mover review for " + db_MES_UBSBUSINESSNAME)&& review_CreatedToday.get(i).getText().equals(currentDate)) {
						elementreview.click();
						break;
					}
					}


	
				AccessITPageObjects.checkAll_checkbox.click();
				AccessITPageObjects.select_everything.click();
				AccessITPageObjects.bulk_decisions.click();
				AccessITPageObjects.bulk_decisions_approve.click();
				AccessITPageObjects.save_all_decisions.click();
				AccessITPageObjects.sign_offAll_decsions.click();
				AccessITPageObjects.finish_signOff.click();
				Thread.sleep(5000);

				AccessITPageObjects.myWork.click();
				AccessITPageObjects.workitems_item.click();
				AccessITPageObjects.textBox_workItem.sendKeys(searchTextMover);
				AccessITPageObjects.workItem_searchglass.click();

				if (!driver.getPageSource().equals(searchTextMover)) {
					boolean result = driver.getPageSource().equals(searchTextMover);
					Assert.assertFalse(result);
					log.info("The review has been approved by the LM ");
				} else {
					
					Thread.sleep(2000);
					approveRevokeReviews(driver, JMLTYpe, Action, User);
				}
			}

			if (User.equals("Certificate_Owner") && Action.equals("Revoked")) {

				AccessITPageObjects.myWork.click();
				AccessITPageObjects.workitems_item.click();

				AccessITPageObjects.textBox_workItem.sendKeys(db_certificateName);
				AccessITPageObjects.workItem_searchglass.click();
				Thread.sleep(5000);
				WebElement elementreview = (new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='x-grid-cell-inner ' and text()='"+db_certificateName+"']"))));

				Assert.assertTrue(elementreview.isDisplayed());
				log.info("The review is present in LM dashboard: "+db_certificateName);

				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
				Date date = new Date();
				String currentDate = dateFormat.format(date);
				System.out.println(currentDate);

				List<WebElement> review_CreatedToday = driver.findElements(By.xpath("//*[@class='x-grid-cell-inner ' and text()='" + currentDate + "']"));

				for (int i = 0; i < review_CreatedToday.size(); i++) {
					if (elementreview.getText().equals(db_certificateName)&& review_CreatedToday.get(i).getText().equals(currentDate)) {
						elementreview.click();
						break;
					}
				}


				AccessITPageObjects.checkAll_checkbox.click();
				AccessITPageObjects.select_everything.click();
				AccessITPageObjects.bulk_decisions.click();
				AccessITPageObjects.bulk_decisions_revoke.click();
				AccessITPageObjects.save_all_decisions.click();
				AccessITPageObjects.sign_offAll_decsions.click();
				AccessITPageObjects.finish_signOff.click();
				Thread.sleep(5000);

				AccessITPageObjects.myWork.click();
				AccessITPageObjects.workitems_item.click();
				AccessITPageObjects.textBox_workItem.sendKeys(db_certificateName);
				AccessITPageObjects.workItem_searchglass.click();

				if (!driver.getPageSource().equals(db_certificateName)) {
					boolean result = driver.getPageSource().equals(db_certificateName);
					Assert.assertFalse(result);
					log.info("The review has been approved by the CertificateOwner "+db_certificateName);
				} else {
					// driver.navigate().refresh();
					Thread.sleep(2000);
					approveRevokeReviews(driver, JMLTYpe, Action, User);
				}
				
			}

		}

		catch (Exception e) {
			e.printStackTrace();
			log.info(" Elements are NOT Displayed and NOT enabled");
		}
	}

	public static void isSchedulerSuccess(String schedulerTaskname) throws Exception {
		if (AccessITPageObjects.success_message_forScheudler.getText().equals("Success")) {
			assert ("Success").equals(AccessITPageObjects.success_message_forScheudler.getText()) : "Success: Scheduler has run";
			log.info(schedulerTaskname + " has run successfully and completed its task");
		} else {

			Actions actions = new Actions(driver);
			actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
			isSchedulerSuccess(schedulerTaskname);
		}
	}

	public static void runScheduler(WebDriver driver, String schedulerTaskname, String JMLTYpe) throws Exception {

		try {
			AccessITPageObjects.Setup_menu.click();
			AccessITPageObjects.task_item.click();

			if (schedulerTaskname.equals("ubsMES013_UBS_JML_Delta_Aggregator")) {
				AccessITPageObjects.tasksSearchField.sendKeys("ubsMES013 UBS JML Delta Aggregator");
				AccessITPageObjects.searchglass.click();

				Thread.sleep(2000);
				AccessITPageObjects.searchList_scheduler.click();
				Thread.sleep(2000);
				AccessITPageObjects.savenExecute_scheduler.click();
				AccessITPageObjects.ok_button_forScheduler.click();
				Thread.sleep(2000);
				AccessITPageObjects.task_result_tab.click();
				AccessITPageObjects.tasksSearchField_taskresults.click();
				Thread.sleep(10000);
				AccessITPageObjects.tasksSearchField_taskresults.sendKeys("ubsMES013 UBS JML Delta Aggregator");
				Thread.sleep(2000);
				AccessITPageObjects.taskresult_firstrecord_ubsMES013_UBS_JML_Delta_Aggregator.click();
				Thread.sleep(2000);

				// Fluent Work is not working---So we use the recursive function
				if (AccessITPageObjects.success_message_forScheudler.getText().equals("Success")) {
					assert ("Success").equals(AccessITPageObjects.success_message_forScheudler.getText()) : "Success: ubsMES013_UBS_JML_Delta_Aggregator";
					log.info("ubsMES013_UBS_JML_Delta_Aggregator has run successfully and completed its task");

				} else {
					// driver.navigate().refresh();
					Thread.sleep(2000);
					Actions actions = new Actions(driver);
					actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
					isSchedulerSuccess(schedulerTaskname);
				}

			}

			// ubsENAML001 Certification creation
			if (schedulerTaskname.equals("ubsENAML001_Certification_creation")) {
				AccessITPageObjects.tasksSearchField.sendKeys("ubsENAML001 Certification creation");
				AccessITPageObjects.searchglass.click();

				Thread.sleep(2000);
				AccessITPageObjects.searchList_scheduler.click();
				Thread.sleep(2000);
				AccessITPageObjects.savenExecute_scheduler.click();
				AccessITPageObjects.ok_button_forScheduler.click();
				Thread.sleep(2000);
				AccessITPageObjects.task_result_tab.click();
				AccessITPageObjects.tasksSearchField_taskresults.click();
				Thread.sleep(10000);
				AccessITPageObjects.tasksSearchField_taskresults.sendKeys("ubsENAML001 Certification creation");
				Thread.sleep(2000);
				AccessITPageObjects.taskresult_firstrecord_ubsENAML001_Certification_creation.click();
				Thread.sleep(2000);

				// Fluent Work is not working---So we use the recursive function
				if (AccessITPageObjects.success_message_forScheudler.getText().equals("Success")) {
					assert ("Success").equals(AccessITPageObjects.success_message_forScheudler.getText()) : "Success: ubsENAML001_Certification_creation";
					log.info("ubsENAML001 Certification creation has run successfully and completed its task");

				} else {
					// driver.navigate().refresh();
					Thread.sleep(1000);
					Actions actions = new Actions(driver);
					actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
					isSchedulerSuccess(schedulerTaskname);
				}

			}
			
			
			if (schedulerTaskname.equals("Perform_Maintenance")) {
				AccessITPageObjects.tasksSearchField.sendKeys("Perform Maintenance");
				AccessITPageObjects.searchglass.click();

				Thread.sleep(2000);
				AccessITPageObjects.searchList_scheduler_Perform_Maintenance.click();
				Thread.sleep(2000);
				AccessITPageObjects.savenExecute_scheduler.click();
				AccessITPageObjects.ok_button_forScheduler.click();
				Thread.sleep(2000);
				AccessITPageObjects.task_result_tab.click();
				AccessITPageObjects.tasksSearchField_taskresults.click();
				Thread.sleep(10000);
				AccessITPageObjects.tasksSearchField_taskresults.sendKeys("Perform Maintenance");
				Thread.sleep(2000);
//				THIS WILL HAVE TO BE CHANGED PERFORM MAINT 1ST RECORD XPATH-50/51 ETC...
				AccessITPageObjects.taskresult_firstrecord.click();				
				Thread.sleep(2000);

				// Fluent Work is not working---So we use the recursive function
				if (AccessITPageObjects.success_message_forScheudler.getText().equals("Success")) {
					assert ("Success").equals(AccessITPageObjects.success_message_forScheudler.getText()) : "Success: Perform Maintenance";
					log.info("Perform Maintenance has run successfully and completed its task");

				} else {
					// driver.navigate().refresh();
					Thread.sleep(1000);
					Actions actions = new Actions(driver);
					actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
					isSchedulerSuccess(schedulerTaskname);
				}

			}
			
			if (schedulerTaskname.equals("ubssnow011")) {
				AccessITPageObjects.tasksSearchField.sendKeys("ubssnow011");
				AccessITPageObjects.searchglass.click();

				Thread.sleep(2000);
				AccessITPageObjects.searchList_scheduler_ubsSNOW011.click();
				Thread.sleep(2000);
				AccessITPageObjects.savenExecute_scheduler.click();
				AccessITPageObjects.ok_button_forScheduler.click();
				Thread.sleep(2000);
				AccessITPageObjects.task_result_tab.click();
				AccessITPageObjects.tasksSearchField_taskresults.click();
				Thread.sleep(10000);
				AccessITPageObjects.tasksSearchField_taskresults.sendKeys("ubssnow011");
				Thread.sleep(2000);
//				THIS WILL HAVE TO BE CHANGED PERFORM MAINT 1ST RECORD XPATH-50/51 ETC...
				AccessITPageObjects.taskresult_firstrecord.click();				
				Thread.sleep(2000);

				// Fluent Work is not working---So we use the recursive function
				if (AccessITPageObjects.success_message_forScheudler.getText().equals("Success")) {
					assert ("Success").equals(AccessITPageObjects.success_message_forScheudler.getText()) : "Success: ubssnow011";
					log.info("ubssnow011 has run successfully and completed its task");

				} else {
					// driver.navigate().refresh();
					Thread.sleep(1000);
					Actions actions = new Actions(driver);
					actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
					isSchedulerSuccess(schedulerTaskname);
				}

			}
			
			
			if (schedulerTaskname.equals("ubsmail103")) {
				AccessITPageObjects.tasksSearchField.sendKeys("ubsmail103");
				AccessITPageObjects.searchglass.click();

				Thread.sleep(2000);
				AccessITPageObjects.searchList_scheduler_ubsmail103.click();
				Thread.sleep(2000);
				AccessITPageObjects.savenExecute_scheduler.click();
				AccessITPageObjects.ok_button_forScheduler.click();
				Thread.sleep(2000);
				AccessITPageObjects.task_result_tab.click();
				AccessITPageObjects.tasksSearchField_taskresults.click();
				Thread.sleep(10000);
				AccessITPageObjects.tasksSearchField_taskresults.sendKeys("ubsmail103");
				Thread.sleep(2000);
//				THIS WILL HAVE TO BE CHANGED PERFORM MAINT 1ST RECORD XPATH-50/51 ETC...
				AccessITPageObjects.taskresult_firstrecord.click();				
				Thread.sleep(2000);

				// Fluent Work is not working---So we use the recursive function
				if (AccessITPageObjects.success_message_forScheudler.getText().equals("Success")) {
					assert ("Success").equals(AccessITPageObjects.success_message_forScheudler.getText()) : "Success: ubsmail103";
					log.info("ubsmail103 has run successfully and completed its task");

				} else {
					// driver.navigate().refresh();
					Thread.sleep(1000);
					Actions actions = new Actions(driver);
					actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
					isSchedulerSuccess(schedulerTaskname);
				}

			}
			
			
			if (schedulerTaskname.equals("ubsid000_Refresh_Identity_Cube")) {
				AccessITPageObjects.tasksSearchField.sendKeys("ubsid000 Refresh Identity Cube");
				AccessITPageObjects.searchglass.click();

				Thread.sleep(2000);
				AccessITPageObjects.searchList_scheduler_Refresh_Identity_Cube.click();
				Thread.sleep(2000);
				
				AccessITPageObjects.scheduler_input.click();
				Actions action = new Actions(driver);
				action.keyDown(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).perform();
				AccessITPageObjects.scheduler_input.click();
				action.keyDown(Keys.CONTROL).sendKeys(Keys.INSERT).perform();
				AccessITPageObjects.scheduler_input.sendKeys("name=="+db_READONLY_userguid);
				
				AccessITPageObjects.savenExecute_scheduler.click();
				AccessITPageObjects.ok_button_forScheduler.click();
				Thread.sleep(2000);
				AccessITPageObjects.task_result_tab.click();
				AccessITPageObjects.tasksSearchField_taskresults.click();
				Thread.sleep(10000);
				AccessITPageObjects.tasksSearchField_taskresults.sendKeys("ubsid000 Refresh Identity Cube");
				Thread.sleep(2000);
//				THIS WILL HAVE TO BE CHANGED PERFORM MAINT 1ST RECORD XPATH-50/51 ETC...
				AccessITPageObjects.taskresult_firstrecord.click();				
				Thread.sleep(2000);

				// Fluent Work is not working---So we use the recursive function
				if (AccessITPageObjects.success_message_forScheudler.getText().equals("Success")) {
					assert ("Success").equals(AccessITPageObjects.success_message_forScheudler.getText()) : "Success: ubsid000_Refresh_Identity_Cube";
					log.info("ubsid000_Refresh_Identity_Cube has run successfully and completed its task");

				} else {
					// driver.navigate().refresh();
					Thread.sleep(1000);
					Actions actions = new Actions(driver);
					actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();
					isSchedulerSuccess(schedulerTaskname);
				}

			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void verifyCertificate(WebDriver driver, String JMLTYpe, String User) throws Exception {
		try {

			if (JMLTYpe.equals("MOVER") && User.equals("Admin")) {
				AccessITPageObjects.Setup_menu.click();
				AccessITPageObjects.certificate_item.click();
				if (db_certificateName != null) 
				{
					AccessITPageObjects.search_certificate.click();
					AccessITPageObjects.search_certificate.sendKeys(db_certificateName);
					AccessITPageObjects.search_certificate_glass.click();
					Thread.sleep(10000);
					
					DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
					Date date = new Date();
					String currentDate = dateFormat.format(date);
					System.out.println(currentDate);
	
					WebElement mytable = AccessITPageObjects.data_table_Certifications;
					// To locate rows of table.
					List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
					// To calculate no of rows In table.
					int rows_count = rows_table.size();
					log.info("Number of cells In Row " + rows_count);

					for (int row = 1; row < rows_count; row++) {
						// To locate columns(cells) of that specific row.
						List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
						// To calculate no of columns (cells). In that specific row.

						int columns_count = Columns_row.size();
						log.info("Number of cells In Row " + row + " are " + columns_count);

						String name = Columns_row.get(0).getText();
						String Status = Columns_row.get(1).getText();
						String c_Date = Columns_row.get(3).getText();
						

						log.info(("Columns_row.get(0).getText()" + Columns_row.get(0).getText()));
						log.info(("Columns_row.get(1).getText()" + Columns_row.get(1).getText()));
						log.info(("Columns_row.get(3).getText()" + Columns_row.get(3).getText()));

						if (name.equals(db_certificateName) && c_Date.contains(currentDate)) {
							assert (db_certificateName).equals(name);
							assert ("Completed").equals(Status);
						}

						

					}
					
					
					
				}
				else{
				searchTextMover = "Mover review for " + db_MES_UBSBUSINESSNAME;
				AccessITPageObjects.search_certificate.click();
				AccessITPageObjects.search_certificate.sendKeys(searchTextMover);
				AccessITPageObjects.search_certificate_glass.click();
				Thread.sleep(10000);

				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				Date date = new Date();
				String currentDate = dateFormat.format(date);
				System.out.println(currentDate);

				String actualText = driver.findElement(By.xpath("//*[@class='x-grid-cell-inner ' and text()='Mover review for "+ db_MES_UBSBUSINESSNAME + "']")).getText();

				WebElement mytable = AccessITPageObjects.data_table_Certifications;
				// To locate rows of table.
				List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
				// To calculate no of rows In table.
				int rows_count = rows_table.size();
				log.info("Number of cells In Row " + rows_count);

				for (int row = 1; row < rows_count; row++) {
					// To locate columns(cells) of that specific row.
					List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
					// To calculate no of columns (cells). In that specific row.

					int columns_count = Columns_row.size();
					log.info("Number of cells In Row " + row + " are " + columns_count);

					String name = Columns_row.get(0).getText();
					String Status = Columns_row.get(1).getText();
					String c_Date = Columns_row.get(3).getText();

					log.info(("Columns_row.get(0).getText()" + Columns_row.get(0).getText()));
					log.info(("Columns_row.get(1).getText()" + Columns_row.get(1).getText()));
					log.info(("Columns_row.get(3).getText()" + Columns_row.get(3).getText()));

					if (Status.equals("Active") && name.equals(searchTextMover) && c_Date.contains(currentDate)) {
						log.info("actualText" + actualText);
						log.info("searchTextMover" + searchTextMover);
						assert (searchTextMover).equals(actualText) : searchTextMover;
						log.info("The Review is present in the certifications : " + searchTextMover);

					}

				}
			}
			}

			if (JMLTYpe.equals("MOVER") && User.equals("Certificate_Owner")) {
				AccessITPageObjects.myWork.click();
				AccessITPageObjects.workitems_item.click();
				AccessITPageObjects.textBox_workItem.click();
				AccessITPageObjects.textBox_workItem.sendKeys(db_certificateName);
				AccessITPageObjects.workItem_searchglass.click();
				Thread.sleep(10000);
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
				Date date = new Date();
				String currentDate_CERT = dateFormat.format(date);
				System.out.println(currentDate_CERT);

				WebElement table = AccessITPageObjects.data_table_Certifications;
				
				// To locate rows of table.
				List<WebElement> rows_table = table.findElements(By.tagName("tr"));
				// To calculate no of rows In table.
				int rows_count = rows_table.size();
				log.info("Number of cells In Row " + rows_count);

				for (int row = 1; row < rows_count; row++) {
					// To locate columns(cells) of that specific row.
					List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
					// To calculate no of columns (cells). In that specific row.

					int columns_count = Columns_row.size();
					log.info("Number of cells In Row " + row + " are " + columns_count);

					String name = Columns_row.get(1).getText();
					String c_Date = Columns_row.get(6).getText();

					log.info(("Columns_row.get(1).getText()" + Columns_row.get(1).getText()));
					log.info(("Columns_row.get(6).getText()" + Columns_row.get(6).getText()));

					if (name.equals(db_certificateName) && c_Date.contains(currentDate_CERT)&& driver.getPageSource().equals(db_certificateName)) {

						boolean result = driver.getPageSource().equals(db_certificateName);
						Assert.assertTrue(result);

						log.info("The Review is present in the certifications : " + searchTextMover);
						WebElement elementreview_CERT = (new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='x-grid-cell-inner ' and text()='" + db_certificateName + "']"))));
						elementreview_CERT.click();
					}

				}

			}
			/*
			 * if(JMLTYpe.equals("JOINER")) {}
			 */

		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
