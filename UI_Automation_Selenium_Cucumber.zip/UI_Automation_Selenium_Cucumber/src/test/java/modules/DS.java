package modules;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;

public class DS {
//	static DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
//
    public static void main(String arg[]) throws ParseException{
//    System.out.println(dateFormat.toString());
    	
    	//Reverse a number
    	/*int n=12718;
    	int r=0;
    	while(n!=0)
    	{
    		r=r*10;
    		r=r+n%10;
    		n=n/10;
    	}
    	System.out.println(r);
    	
    	
    	int x=241;
    	int y=149;
    	x=x+y;
    	y=x-y;
    	x=x-y;
    	System.out.println("x"+x);
    	System.out.println("y"+y);
    	
    	
    	int k=241;
    	int l=149;
    	int t=0;
    	t=k;
    	k=l;
    	l=t;
    	
    	System.out.println("k"+k);
    	System.out.println("l"+l);
    	*/
    	
    	/*int n8=53;
    	int rem=0;
    	boolean isprime;
    	for(int i=2;i<=n8/2;i++)
    	{
    	rem=n8%i;
    	if(rem==0)
    		isprime=false;
    	
    	}*/
    	String randoms="abc,defgh,ij,k";
    	char[] stringToCharArray=randoms.toCharArray();
    	
    	int l=stringToCharArray.length;   	
    	 List<Integer> commaArray = new ArrayList<Integer>();
    	 
    	for(int i=0;i<=l-1;i++)
    	{
    		System.out.println(stringToCharArray[i]);    	
    		if(stringToCharArray[i]==',')
    		{
    			commaArray.add(i);
    			
    		}
    		
    	}
    	
    	 List<String> reveresed_array = new ArrayList<String>();
    	
    	for(int k=l-1;k>=0;k--)
    	{
    		if(stringToCharArray[k] !=','){
    		reveresed_array.add(String.valueOf(stringToCharArray[k]));
    		}
    	}
    	
    	System.out.println("common Array:"+commaArray);
    	System.out.println("reversed String:"+reveresed_array);
    	
    	List<String> reveresed_full_array = new ArrayList<String>();
    	
    	for(int i=0;i>randoms.length();i++){
    		
    		if(commaArray.contains(i)){
    			reveresed_full_array.add(",");
    		}
    		else{
    		reveresed_full_array.add(reveresed_array.get(i));
    		}
    		
    		System.out.println(reveresed_full_array);
    	}
/*    
    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
	Date date = new Date();
	String currentDate=dateFormat.format(date);
	String expirationdate=currentDate+30;
	System.out.println(currentDate);
	System.out.println(expirationdate);*/
	
    	/*DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
    	Date date = new Date();
    	String currentDate=dateFormat.format(date);
    	Date dateAfterOneMonth = new DateTime(currentDate).plusMonths(01).toDate();
    	System.out.println(dateAfterOneMonth);*/
    	
    	
//		Date date = new Date();
//		String currentDate = dateFormat.format(date);
//		System.out.println(currentDate);
    	
    	/*DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
    	Date date = new Date();
    	String currentDate = dateFormat.format(date);
    	System.out.println(currentDate);
        
        Calendar c = Calendar.getInstance();
//        c.setTime(currentDate);
        c.add(Calendar.DATE, 30);
        
        Date currentDatePlusOne = c.getTime();
        String expiryDate=dateFormat.format(currentDatePlusOne);
        System.out.println(expiryDate);*/
        
        
        
/*        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
    	Date currentDate = new Date();
        System.out.println(dateFormat.format(currentDate));		        
        Calendar c = Calendar.getInstance();		        
        c.add(Calendar.DATE, 30);		        
        Date expiryDate = c.getTime();

        System.out.println(dateFormat.format(expiryDate));*/

    }
}
