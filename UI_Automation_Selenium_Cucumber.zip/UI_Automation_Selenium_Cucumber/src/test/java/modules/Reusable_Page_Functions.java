package modules;

import helpers.Browser;
//import helpers.Log;

//import static SOA_Automation_Group_2018.SOA_Automation.Browser.driver;
import static org.testng.AssertJUnit.assertEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;

//import com.relevantcodes.extentreports.ExtentReports;
//import com.relevantcodes.extentreports.ExtentTest;
//import com.relevantcodes.extentreports.LogStatus;

import helpers.Common_Group;
import pageobjects.SegregationofDutiesHomePageObjects;

public class Reusable_Page_Functions extends Browser {
	
//	static ExtentReports extent;
//	static ExtentTest logger;
	
	public static Common_Group ui = new Common_Group();

	public static String download_resultant_uploaded_file_path=Common_Group.readProp("GlobalSettings","download_resultant_uploaded_file_path");
	public static String dutyfileuploadPath_excel=Common_Group.readProp("GlobalSettings","dutyfileuploadPath_excel");
	public static String dutyMappingfileuploadPath_excel=Common_Group.readProp("GlobalSettings","dutyMappingfileuploadPath_excel");
	public static String PDMfileuploadPath_excel=Common_Group.readProp("GlobalSettings","PDMfileuploadPath_excel");
	
	public static String invalidFormat_dutyfileuploadPath_excel=Common_Group.readProp("GlobalSettings","invalidFormat_dutyfileuploadPath_excel");
	public static String invalidFormat_dutyMappingfileuploadPath_excel=Common_Group.readProp("GlobalSettings","invalidFormat_dutyMappingfileuploadPath_excel");
	public static String invalidFormat_PDMfileuploadPath_excel=Common_Group.readProp("GlobalSettings","invalidFormat_PDMfileuploadPath_excel");
			
			
	
	public static String sodParameteruploadPath=Common_Group.readProp("GlobalSettings","sodParameteruploadPath");

	public static String query_Duty=Common_Group.readProp("GlobalSettings","query_Duty");
	public static String query_Duty_active=Common_Group.readProp("GlobalSettings","query_Duty_active");
	public static String query_DutyMapping=Common_Group.readProp("GlobalSettings","query_DutyMapping");
	public static String query_DutyMapping_active=Common_Group.readProp("GlobalSettings","query_DutyMapping_active");
	
	public static String query_ProfiletoDutyMapping=Common_Group.readProp("GlobalSettings","query_ProfiletoDutyMapping");
	public static String query_ACR_Asset=Common_Group.readProp("GlobalSettings","query_ACR_Asset");

	public static String sodsim_host=Common_Group.readProp("GlobalSettings","sodsim_host");
	public static String sodsim_sid=Common_Group.readProp("GlobalSettings","sodsim_sid");
	public static String sodsim_user=Common_Group.readProp("GlobalSettings","sodsim_user");
	public static String sodsim_pw=Common_Group.readProp("GlobalSettings","sodsim_pw");

	 

	final static Logger log = Logger.getLogger(Reusable_Page_Functions.class);
	
	@BeforeTest
	public static void startReport() {
		try {
			
			Runtime.getRuntime().exec("taskkill /f /im EXCEL.exe");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//        extent = new ExtentReports(System.getProperty("user.dir") + "/test-output/Reports/SOD_Manage_Param_TestCases"+timestamp.getTime()+".html", true);
//        extent.loadConfig(new File(System.getProperty("user.dir") + "\\extent-config.xml"));

	}

	public static void verify_page_text(WebDriver driver, String expectedText) throws Exception {
		startReport();
//		logger = extent.startTest("Text Verifications");
		
		if (expectedText.contains("Records")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.successfull_message.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.successfull_message.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.successfull_message.getText());

		}
		
		if (expectedText.contains("Only excel format")) {
			String actual_text="Error encountered while processing the request. Validation Failed {"+'"'+"file to upload"+'"'+":"+'"'+"Only excel format is supported for upload. Both .xls and .xlsx are allowed"+'"'+"}. Please report this to support, see Help and Guides.";
			log.info("actual_text"+actual_text);
			assertEquals(expectedText, actual_text);
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + actual_text);
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + actual_text);
		}

		if (expectedText.contains("Segregation")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Segregation_of_Duties_text1.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Segregation_of_Duties_text1.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Segregation_of_Duties_text1.getText());

		}

		if (expectedText.contains("uploaded")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Segregation_of_Duties_text2.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Segregation_of_Duties_text2.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Segregation_of_Duties_text2.getText());
		}

		if (expectedText.contains("Ensure")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Segregation_of_Duties_text3.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Segregation_of_Duties_text3.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Segregation_of_Duties_text3.getText());
		}

		if (expectedText.contains("Parameter")) {
			Thread.sleep(8000);
			SegregationofDutiesHomePageObjects.dropdown.click();
			Thread.sleep(8000);
			
			SegregationofDutiesHomePageObjects.dropdown_Duty_Mapping.click();
			Thread.sleep(4000);
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Segregation_of_Duties_text4.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Segregation_of_Duties_text4.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Segregation_of_Duties_text4.getText());

		}
		
		if (expectedText.contains("input file")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Total_records_in_input_file.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Total_records_in_input_file.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Total_records_in_input_file.getText());
		}
		
		if (expectedText.contains("successfully uploaded")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Total_records_successfully_uploaded.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Total_records_successfully_uploaded.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Total_records_successfully_uploaded.getText());
		}
		
		
		if (expectedText.contains("records processed")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Total_records_processed.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Total_records_processed.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Total_records_processed.getText());
		}
		
		
		if (expectedText.contains("failed upload")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Total_records_failed_upload.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Total_records_failed_upload.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Total_records_failed_upload.getText());
		}
		
		if (expectedText.contains("Save the result file")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Save_the_result_file.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Save_the_result_file.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Save_the_result_file.getText());
		}
	
		if (expectedText.contains("Download the result file")) {
			assertEquals(expectedText, SegregationofDutiesHomePageObjects.Download_the_result_file.getText());
			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.Download_the_result_file.getText());
//			logger.log(LogStatus.PASS, "|Expected statusMessage:|"+expectedText + "|Actual statusMessage:|" + SegregationofDutiesHomePageObjects.Download_the_result_file.getText());
		}


	}

	public static void verify_page_multitext(WebDriver driver, String expectedText) throws Exception {
		if (expectedText.contains("before")) {

			log.info("Expected Text: " + expectedText);
			log.info("Actual Text: " + SegregationofDutiesHomePageObjects.pdm_selection_text1.getText());
			log.info(SegregationofDutiesHomePageObjects.pdm_selection_text1.getText());
			Assert.assertTrue(expectedText.contains(SegregationofDutiesHomePageObjects.pdm_selection_text1.getText()));
//			LazyAssert.assertTrue(expectedText.contains(SegregationofDutiesHomePageObjects.pdm_selection_text1.getText()));

		}
	}

	public static void verify_page_elements(WebDriver driver, String ExpectedWebElement) throws Exception {

		if (ExpectedWebElement.equals("UploadButton")) {
			try {
				Assert.assertTrue(SegregationofDutiesHomePageObjects.upload_button.isDisplayed());
				Assert.assertTrue(SegregationofDutiesHomePageObjects.upload_button.isEnabled());
				log.info(ExpectedWebElement + "is Displayed and enabled");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				log.info(ExpectedWebElement + "is NOT Displayed and NOT enabled");
			}
		}

		if (ExpectedWebElement.equals("DownloadButton")) {
			try {

				Thread.sleep(4000);
				Assert.assertTrue(SegregationofDutiesHomePageObjects.download_button.isDisplayed());
				Assert.assertTrue(SegregationofDutiesHomePageObjects.download_button.isEnabled());
				log.info(ExpectedWebElement + "is Displayed and enabled");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
			}
		}

		if (ExpectedWebElement.equals("DropDown_with_Elements")) {
			try {
				Assert.assertTrue(SegregationofDutiesHomePageObjects.dropDown_with_Elements.isDisplayed());
				Assert.assertTrue(SegregationofDutiesHomePageObjects.dropDown_with_Elements.isEnabled());
				log.info(ExpectedWebElement + "is Displayed and enabled");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
			}
		}
		
			

		if (ExpectedWebElement.equals("FilterButtons")) {
			try {

				SegregationofDutiesHomePageObjects.dropdown.click();
				Thread.sleep(4000);
				SegregationofDutiesHomePageObjects.dropdown_selection_pdm.click();
				Thread.sleep(4000);

				Assert.assertTrue(SegregationofDutiesHomePageObjects.filterAssetButtons.isDisplayed());
				Assert.assertTrue(SegregationofDutiesHomePageObjects.filterAssetButtons.isEnabled());
				Assert.assertTrue(SegregationofDutiesHomePageObjects.filterRoleButtons.isDisplayed());
				Assert.assertTrue(SegregationofDutiesHomePageObjects.filterRoleButtons.isEnabled());

				log.info(ExpectedWebElement + "is Displayed and enabled");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
			}
		}

		if (ExpectedWebElement.equals("CheckBoxes")) {
			try {
				Assert.assertTrue(SegregationofDutiesHomePageObjects.assetCheckbox.isDisplayed());
				Assert.assertTrue(SegregationofDutiesHomePageObjects.assetCheckbox.isEnabled());
				Assert.assertTrue(SegregationofDutiesHomePageObjects.roleCheckbox.isDisplayed());
				Assert.assertTrue(SegregationofDutiesHomePageObjects.roleCheckbox.isEnabled());
				log.info(ExpectedWebElement + "is Displayed and enabled");
			} catch (NoSuchElementException e) {
				e.printStackTrace();
			}
		}

	}


	public static void verify_header_links(WebDriver driver, String ExpectedWebLink) throws Exception {

		if (ExpectedWebLink.contains("Help and Guides")) {
			try {

				String link = SegregationofDutiesHomePageObjects.Help_and_Guides.getAttribute("href");
				log.info("link extracted from attribute: " + link);
				assertEquals("https://bw.assist.ubs.com/node/150124", link);
				
				
				   List<WebElement> checkBoxes = driver.findElements(By.xpath("//input[@type='checkbox']"));
				   System.out.println("checkBoxes.size()-->"+checkBoxes.size());
			       for(int i=0; i<checkBoxes.size(); i++) 	
			       {		        
			        checkBoxes.get(i).click();
			        }
				


				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		

		if (ExpectedWebLink.contains("Access IT")) 
		{
			try {
		
				String link = SegregationofDutiesHomePageObjects.accessIT_link.getAttribute("href");
				log.info("link extracted from attribute: " + link); 
				assertEquals("http://goto/accessit", link);
			} catch (Exception e) {
				e.printStackTrace();
//				log.error(e.getMessage());
			}
		}

		
		if (ExpectedWebLink.contains("ARP")) 
		{
			try {
//				SegregationofDutiesHomePageObjects.external_links.click();
				String link = SegregationofDutiesHomePageObjects.arp_link.getAttribute("href");
				log.info("link extracted from attribute: " + link); 
				assertEquals("http://goto/arp", link);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		if (ExpectedWebLink.contains("BBS")) 
		{
			try {
//				SegregationofDutiesHomePageObjects.external_links.click();
				String link = SegregationofDutiesHomePageObjects.bbs_link.getAttribute("href");
				log.info("link extracted from attribute: " + link); 
				assertEquals("http://goto/bbs", link);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		if (ExpectedWebLink.contains("MAC")) 
		{
			try {
//				SegregationofDutiesHomePageObjects.external_links.click();
				String link = SegregationofDutiesHomePageObjects.mac_link.getAttribute("href");
				log.info("link extracted from attribute: " + link); 
				assertEquals("http://macportal.prd.pwj.com:90/EntitlementTool/", link);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		

		if (ExpectedWebLink.contains("here")) {
			try {

				String link = SegregationofDutiesHomePageObjects.here.getAttribute("href");
				log.info("link extracted from attribute: " + link);
				assertEquals("http://goto/docweb-id/57670104", link);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	
	

	public static void click_both_checkbox(WebDriver driver) {
		SegregationofDutiesHomePageObjects.assetCheckbox.click();
		SegregationofDutiesHomePageObjects.roleCheckbox.click();
		

	}
	

	public static void select_sod_parameter(WebDriver driver, String SodParameter) throws InterruptedException {
		if (SodParameter.equals("PDM")) {
			try {
				SegregationofDutiesHomePageObjects.dropdown.click();
			Thread.sleep(4000);
			SegregationofDutiesHomePageObjects.dropdown_selection_pdm.click();
			Thread.sleep(4000);
			} catch (NoSuchElementException e) {
				e.printStackTrace();
			}
		}

		if (SodParameter.equals("Duty Mapping")) {
			try {Thread.sleep(4000);
			SegregationofDutiesHomePageObjects.dropdown.click();
			Thread.sleep(4000);
//				SegregationofDutiesHomePageObjects.dropdown_selection_pdm.click();
//				Thread.sleep(8000);
				
				SegregationofDutiesHomePageObjects.dropdown_Duty_Mapping.click();
				Thread.sleep(4000);
			} catch (NoSuchElementException e) {
				e.printStackTrace();
			}
		}

		if (SodParameter.equals("Duty")) {
			try {
				Thread.sleep(4000);
				SegregationofDutiesHomePageObjects.dropdown.click();
				Thread.sleep(4000);
//				SegregationofDutiesHomePageObjects.dropdown_selection_pdm.click();
//				Thread.sleep(8000);
				
				
				
//				WebDriverWait wait = new WebDriverWait(driver, 15);
//				wait.until(ExpectedConditions.elementToBeClickable(SegregationofDutiesHomePageObjects.dropdown_Duty)).click();
				
				SegregationofDutiesHomePageObjects.dropdown_Duty.click();
				Thread.sleep(4000);

				// WebElement selectDutyElement =
				// SegregationofDutiesHomePageObjects.dropdown_Duty;
				// Select select= new Select(selectDutyElement);
				// select.selectByIndex(1);
			} catch (NoSuchElementException e) {
				e.printStackTrace();
			}
		}

	}

	public static void upload_file(WebDriver driver, String SodParamter,String Success_Failure) throws Exception {
//		String systemUser = System.getProperty("user.name").trim();

		SegregationofDutiesHomePageObjects.file_upload.click();
		
		if(Success_Failure.equals("success"))
		{
		Robot robot = new Robot();
		robot.setAutoDelay(5000);

		if (SodParamter.equals("Duty")) {
			StringSelection dutyfileuploadPath_string = new StringSelection(dutyfileuploadPath_excel);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(dutyfileuploadPath_string, null);
		}

		if (SodParamter.equals("Duty Mapping")) {
			StringSelection dutyMappingfileuploadPath_string = new StringSelection(dutyMappingfileuploadPath_excel);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(dutyMappingfileuploadPath_string, null);
		}

		if (SodParamter.equals("PDM")) {
			StringSelection PDMfileuploadPath_string = new StringSelection(PDMfileuploadPath_excel);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(PDMfileuploadPath_string, null);
		}

		robot.setAutoDelay(5000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		robot.setAutoDelay(5000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		SegregationofDutiesHomePageObjects.upload_button.click();

		WebDriverWait wait = new WebDriverWait(driver, 100);// Will wait for 15
															// secs before
															// element to appear
		wait.until(ExpectedConditions.visibilityOf(SegregationofDutiesHomePageObjects.successfull_message));

		Thread.sleep(15000);// hold the page
		verify_page_text(driver, "Records successfully processed");
		
		}
		
		
		
		 
		
		if(Success_Failure.equals("failure"))
		{
			Robot robot = new Robot();
			robot.setAutoDelay(5000);
			
			if (SodParamter.equals("Duty")) {
				StringSelection dutyfileuploadPath_string = new StringSelection(invalidFormat_dutyfileuploadPath_excel);
				Toolkit.getDefaultToolkit().getSystemClipboard().setContents(dutyfileuploadPath_string, null);
			}

			if (SodParamter.equals("Duty Mapping")) {
				StringSelection dutyMappingfileuploadPath_string = new StringSelection(invalidFormat_dutyMappingfileuploadPath_excel);
				Toolkit.getDefaultToolkit().getSystemClipboard().setContents(dutyMappingfileuploadPath_string, null);
			}

			if (SodParamter.equals("PDM")) {
				StringSelection PDMfileuploadPath_string = new StringSelection(invalidFormat_PDMfileuploadPath_excel);
				Toolkit.getDefaultToolkit().getSystemClipboard().setContents(PDMfileuploadPath_string, null);
			}

			robot.setAutoDelay(5000);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_V);
			robot.setAutoDelay(5000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			SegregationofDutiesHomePageObjects.upload_button.click();
			
			WebDriverWait wait = new WebDriverWait(driver, 100);
			wait.until(ExpectedConditions.visibilityOf(SegregationofDutiesHomePageObjects.error_message_invalidFileFormat));

			Thread.sleep(15000);// hold the page

			
			log.info("Error Message on Page "+SegregationofDutiesHomePageObjects.error_message_invalidFileFormat.getText());}
		    String error_Message= SegregationofDutiesHomePageObjects.error_message_invalidFileFormat.getText();

			verify_page_text(driver, error_Message);

	}
	
//	logger.log(LogStatus.PASS, rest_statusMessage + "|statusMessage|" + ExpectedMessage);

	public static void download_the_resultant_uploaded_file() throws InterruptedException {
		
		File dir = new File("C:\\Users\\t610284\\Downloads");
		  File[] dirContents = dir.listFiles();
		  
		  System.out.print("dirContents"+ dirContents);
		  System.out.print("dirContents length"+ dirContents.length);
		  if(dirContents.length > 0)
		  { for (int i = 0; i < dirContents.length; i++) 					  	 
	    	 dirContents[i].delete();
		  } 
		  
		  
		  Thread.sleep(15000);
		  SegregationofDutiesHomePageObjects.download_the_resultant_uploaded_file_link.click();
//		  We wait for sometime to download the file into the folder
		  Thread.sleep(15000);
		  

		  File[] dirContents1 = dir.listFiles();
		  
		  System.out.print("dirContents1 Length"+ dirContents1.length);
		  for (int i = 0; i < dirContents1.length; i++) {	
			  log.info("File Name Downloaded :"+dirContents1[i].getName());
		    	  Assert.assertTrue(dirContents1[i].getName().contains("ParameterUploadResult"));
		    	  log.info(" Resultant File has been downloaded successfully ");		    	     	  
		    	  Thread.sleep(5000);     
		          
		      }
		       		      
		  }

	
	public static void download_file(WebDriver driver, String SodParameter)  throws InterruptedException {
		
		if (SodParameter.contains("PDM")) {
			try {
				
				
				SegregationofDutiesHomePageObjects.assetCheckbox.click();
				  SegregationofDutiesHomePageObjects.assetFilter.click();
				  
//				  selectFirstItem- This is an Item based Element which we had to hardcode as we are not aware of data changes
				  WebDriverWait wait = new WebDriverWait(driver, 100);
				  wait.until(ExpectedConditions.elementToBeClickable(SegregationofDutiesHomePageObjects.selectFirstItem)).click();
				  
				  SegregationofDutiesHomePageObjects.applySelection.click();
				
				
				File dir = new File("C:\\Users\\t610284\\Downloads");
				  File[] dirContents = dir.listFiles();
				  
				  System.out.print("dirContents"+ dirContents);
				  System.out.print("dirContents length"+ dirContents.length);
				  if(dirContents.length > 0)
				  { for (int i = 0; i < dirContents.length; i++) 					  	 
			    	 dirContents[i].delete();
				  } 
				  
				  Thread.sleep(10000);
				  SegregationofDutiesHomePageObjects.download_button.click();	
				  Thread.sleep(5000);
				  SegregationofDutiesHomePageObjects.download_the_SODfile_here.click();	
//				  We wait for sometime to download the file into the folder
				  Thread.sleep(15000);
				  

				  File[] dirContents1 = dir.listFiles();
				  
				  System.out.print("dirContents1 Length"+ dirContents1.length);
				  for (int i = 0; i < dirContents1.length; i++) {	
					  System.out.print("File Name Downloaded :"+dirContents1[i].getName());
				    	  Assert.assertTrue(dirContents1[i].getName().contains("ParameterDownload"));
				    	  log.info(" Resultant File has been downloaded successfully ");		    	     	  
				    	  Thread.sleep(5000);     
				          
				      }				
				  
				  
			} catch (NoSuchElementException e) {
			}
		}

		if (SodParameter.contains("Duty Mapping")) {
			try {
				Thread.sleep(4000);
				
				File dir = new File("C:\\Users\\t610284\\Downloads");
				  File[] dirContents = dir.listFiles();
				  
				  System.out.print("dirContents"+ dirContents);
				  System.out.print("dirContents length"+ dirContents.length);
				  if(dirContents.length > 0)
				  { for (int i = 0; i < dirContents.length; i++) 					  	 
			    	 dirContents[i].delete();
				  } 
				  
				  Thread.sleep(10000);
				  SegregationofDutiesHomePageObjects.download_button.click();
				  Thread.sleep(5000);
				  SegregationofDutiesHomePageObjects.download_the_SODfile_here.click();	
//				  We wait for sometime to download the file into the folder
				  Thread.sleep(15000);
				  

				  File[] dirContents1 = dir.listFiles();
				  
				  System.out.print("dirContents1 Length"+ dirContents1.length);
				  for (int i = 0; i < dirContents1.length; i++) {	
					  System.out.print("File Name Downloaded :"+dirContents1[i].getName());
				    	  Assert.assertTrue(dirContents1[i].getName().contains("ParameterDownload"));
				    	  log.info(" Resultant File has been downloaded successfully ");		    	     	  
				    	  Thread.sleep(5000);     
				          
				      }				  
			} catch (NoSuchElementException e) {
			}
		}

		if (SodParameter.contains("Duty")) {
			try {			
				
				Thread.sleep(4000);								
				
				File dir = new File("C:\\Users\\t610284\\Downloads");
				  File[] dirContents = dir.listFiles();
				  
				  System.out.print("dirContents"+ dirContents);
				  System.out.print("dirContents length"+ dirContents.length);
				  if(dirContents.length > 0)
				  { for (int i = 0; i < dirContents.length; i++) 					  	 
			    	 dirContents[i].delete();
				  } 
				  
				  Thread.sleep(10000);
				  SegregationofDutiesHomePageObjects.download_button.click();	
				  Thread.sleep(5000);
				  SegregationofDutiesHomePageObjects.download_the_SODfile_here.click();	
//				  We wait for sometime to download the file into the folder
				  Thread.sleep(15000);
				  

				  File[] dirContents1 = dir.listFiles();
				  
				  System.out.print("dirContents1 Length"+ dirContents1.length);
				  for (int i = 0; i < dirContents1.length; i++) {	
					  System.out.print("File Name Downloaded :"+dirContents1[i].getName());
				    	  Assert.assertTrue(dirContents1[i].getName().contains("ParameterDownload"));
				    	  log.info(" Resultant File has been downloaded successfully ");		    	     	  
				    	  Thread.sleep(5000);     
				          
				      }						  
				  

			} catch (NoSuchElementException e) {
			}
		}
	}
	
	
	public static void verify_downloadedexceldata(WebDriver driver,String SodParamter) throws Exception {
		
		File dir = new File(download_resultant_uploaded_file_path);
		File[] dirContents = dir.listFiles();
		
		int rowCnt_download_resultant=0;
		 
		  String db_Duty_GUID = null;
		  String db_DutyName = null;
		  String db_Duty_GUID_left = null;
		  String db_DutyName_left = null;	
		  String db_Duty_GUID_right = null;
		  String db_DutyName_right = null;
		  String db_DutyDisplay_Name = null;
		  String db_DutyDescription = null;
		  String db_DutyMapping_SODGUID = null;
		  String db_DutyMapping_LHSDUTYGUID = null;
		  String db_DutyMapping_LHSDUTYTYPE = null;
		  String db_DutyMapping_RHSDUTYGUID = null;
		  String db_DutyMapping_RHSDUTYTYPE = null;						
		  String db_DutyMapping_VIOLATIONPRIORITY = null;
		  String db_ProfiletoDutyMapping_ASSIGNABLEGUID = null;
		  String db_ProfiletoDutyMapping_DUTYGUID = null;
		  String db_ProfiletoDutyMapping_DUTYTYPE = null;																						
		  String db_assetguid=null;
		  String db_acrname=null;
		  log.info("dirContents Length"+ dirContents.length);
		  
		  for (int i = 0; i < dirContents.length; i++) 
		  {
		  rowCnt_download_resultant = ui.getLastRow(download_resultant_uploaded_file_path,dirContents[i].getName(), "Sheet0");
		  log.info("rowCnt_download_resultant:"+rowCnt_download_resultant);
		  
		  for (int j = 2; j <= rowCnt_download_resultant; j++) {// compare data with respect to the downloaded file
			  
			  if(SodParamter.equals("Duty"))
					  {
				  	 String Duty_Description_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty Description", j, "String");
					 String Duty_Name_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty Name", j, "String");
					 String Duty_GUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty GUID", j, "String");
					 String Duty_Display_Name_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty Display Name", j, "String");
					 
//					 query_Duty_active=select * from  PME_SOD_DUTY_TBL where status='ACTIVE' and dutyguid
					 String db_queryDuty=query_Duty_active+ "='"+ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty GUID", j, "String")+"'";


					  ResultSet duty_Table_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryDuty);
					  
					  while (duty_Table_Result.next())
						{
							log.info("SODSIM Duty Table while..............");
							
							db_Duty_GUID = duty_Table_Result.getString("DUTYGUID");
							db_DutyName = duty_Table_Result.getString("DUTYNAME");		
							db_DutyDisplay_Name = duty_Table_Result.getString("DUTYDISPLAYNAME");													
							db_DutyDescription = duty_Table_Result.getString("DUTYDESCRIPTION");		
						
						}

					     log.info("db_Duty_GUID"+ db_Duty_GUID);
					     log.info("db_DutyName"+ db_DutyName);
					     log.info("db_DutyDisplay_Name"+ db_DutyDisplay_Name);
					     log.info("db_DutyDescription"+ db_DutyDescription);
					     
					     assert (Duty_GUID_Excel_DownloadedFile).equals(db_Duty_GUID) : "db_Duty_GUID";
					     assert (Duty_Name_Excel_DownloadedFile).equals(db_DutyName) : "db_DutyName";
						 assert (Duty_Display_Name_Excel_DownloadedFile).equals(db_DutyDisplay_Name) : "db_DutyDisplay_Name";
						 assert (Duty_Description_Excel_DownloadedFile).equals(db_DutyDescription) : "db_DutyDescription";

				  
					  }
			  
			  
			  if(SodParamter.equals("Duty Mapping"))
			  {
				  	 String dutyMapping_sodGuid_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","SOD GUID", j, "String");
					 String dutyMapping_LeftDutyGUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Left Duty GUID", j, "String");
					 String dutyMapping_LeftDutyName_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Left Duty Name", j, "String");
					 String dutyMapping_LeftPermissionType_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Left Permission Type", j, "String");
					 String dutyMapping_RightDutyGUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Right Duty GUID", j, "String");
					 String dutyMapping_RightDutyName_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Right Duty Name", j, "String");
					 String dutyMapping_RightPermissionType_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Right Permission Type", j, "String");
					 String dutyMapping_violationPriority_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Violation Priority", j, "String");
			 
//					 query_DutyMapping_active=select * from PME_SOD_DUTYMATRIX_TBL where status='ACTIVE' and sodguid
			 String db_queryDutyMapping=query_DutyMapping_active+ "='"+ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","SOD GUID", j, "String")+"'";


			  ResultSet dutyMapping_Table_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryDutyMapping);
			  
			  while (dutyMapping_Table_Result.next())
				{
					log.info("SODSIM DutyMapping Table while..............");
					
					db_DutyMapping_SODGUID = dutyMapping_Table_Result.getString("SODGUID");
					db_DutyMapping_LHSDUTYGUID = dutyMapping_Table_Result.getString("LHSDUTYGUID");
					db_DutyMapping_LHSDUTYTYPE = dutyMapping_Table_Result.getString("LHSDUTYTYPE");
					db_DutyMapping_RHSDUTYGUID = dutyMapping_Table_Result.getString("RHSDUTYGUID");
					db_DutyMapping_RHSDUTYTYPE= dutyMapping_Table_Result.getString("RHSDUTYTYPE");						
					db_DutyMapping_VIOLATIONPRIORITY = dutyMapping_Table_Result.getString("VIOLATIONPRIORITY");		
				
				}

			     
			  String db_queryDuty_left=query_Duty_active+ "='"+ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Left Duty GUID", j, "String")+"'";

			  ResultSet duty_Table_Result_left = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryDuty_left);
			  
			  String db_queryDuty_right=query_Duty_active+ "='"+ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Right Duty GUID", j, "String")+"'";

			  ResultSet duty_Table_Result_right = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryDuty_right);
			  
			  while (duty_Table_Result_left.next())
				{
					log.info("SODSIM Duty Table while..............");
					
					db_Duty_GUID_left = duty_Table_Result_left.getString("DUTYGUID");
					db_DutyName_left = duty_Table_Result_left.getString("DUTYNAME");				
				
				}
			  
			  while (duty_Table_Result_right.next())
				{
					log.info("SODSIM Duty Table while..............");
					
					db_Duty_GUID_right = duty_Table_Result_right.getString("DUTYGUID");
					db_DutyName_right = duty_Table_Result_right.getString("DUTYNAME");				
				
				}
			     
			     log.info("db_DutyMapping_SODGUID"+ db_DutyMapping_SODGUID);
			     log.info("db_DutyMapping_LHSDUTYGUID"+ db_DutyMapping_LHSDUTYGUID);
			     log.info("db_DutyMapping_LHSDUTYTYPE"+ db_DutyMapping_LHSDUTYTYPE);
			     log.info("db_DutyMapping_RHSDUTYGUID"+ db_DutyMapping_RHSDUTYGUID);
			     log.info("db_DutyMapping_RHSDUTYTYPE"+ db_DutyMapping_RHSDUTYTYPE);
			     log.info("db_DutyMapping_VIOLATIONPRIORITY"+ db_DutyMapping_VIOLATIONPRIORITY);	
			     log.info("db_Duty_GUID_left"+ db_Duty_GUID_left);
			     log.info("db_DutyName_left"+ db_DutyName_left);
			     log.info("db_Duty_GUID_right"+ db_Duty_GUID_right);
			     log.info("db_DutyName_right"+ db_DutyName_right);
		  		 
			     log.info("dutyMapping_sodGuid_Excel_DownloadedFile"+ dutyMapping_sodGuid_Excel_DownloadedFile);
		  		 log.info("dutyMapping_LeftDutyGUID_Excel_DownloadedFile"+ dutyMapping_LeftDutyGUID_Excel_DownloadedFile);
		  		 log.info("dutyMapping_LeftDutyName_Excel_DownloadedFile"+ dutyMapping_LeftDutyName_Excel_DownloadedFile);
		  		log.info("dutyMapping_LeftPermissionType_Excel_DownloadedFile"+ dutyMapping_LeftPermissionType_Excel_DownloadedFile);
		  		log.info("dutyMapping_RightDutyGUID_Excel_DownloadedFile"+ dutyMapping_RightDutyGUID_Excel_DownloadedFile);
		  		log.info("dutyMapping_RightDutyName_Excel_DownloadedFile"+ dutyMapping_RightDutyName_Excel_DownloadedFile);
		  		log.info("dutyMapping_RightPermissionType_Excel_DownloadedFile"+ dutyMapping_RightPermissionType_Excel_DownloadedFile);
		  		log.info("dutyMapping_violationPriority_Excel_DownloadedFile"+ dutyMapping_violationPriority_Excel_DownloadedFile);
		  		
			  
			  			  		
			  Assert.assertTrue(dutyMapping_sodGuid_Excel_DownloadedFile.equals(db_DutyMapping_SODGUID));
			  Assert.assertTrue(dutyMapping_LeftDutyGUID_Excel_DownloadedFile.equals(db_DutyMapping_LHSDUTYGUID));
			  Assert.assertTrue(dutyMapping_LeftPermissionType_Excel_DownloadedFile.equals(db_DutyMapping_LHSDUTYTYPE));
			  Assert.assertTrue(dutyMapping_RightDutyGUID_Excel_DownloadedFile.equals(db_DutyMapping_RHSDUTYGUID));
			  Assert.assertTrue(dutyMapping_RightPermissionType_Excel_DownloadedFile.equals(db_DutyMapping_RHSDUTYTYPE));
			  Assert.assertTrue(dutyMapping_violationPriority_Excel_DownloadedFile.equals(db_DutyMapping_VIOLATIONPRIORITY));
			  
			  if(db_DutyMapping_LHSDUTYGUID.equals(db_Duty_GUID_left))
			  {Assert.assertTrue(db_DutyName_left.equals(dutyMapping_LeftDutyName_Excel_DownloadedFile));}
			  
			  
			  if(db_DutyMapping_RHSDUTYGUID.equals(db_Duty_GUID_right))
			  {Assert.assertTrue(db_DutyName_right.equals(dutyMapping_RightDutyName_Excel_DownloadedFile));}
			  
			  

		  
			  }
			  
			  
			  if(SodParamter.equals("PDM"))
			  {
				     String PDM_assetGuid_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Asset GUID", j, "String");
					 String PDM_Permission_GUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Permission GUID", j, "String");
					 String PDM_Permission_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Permission", j, "String");
					 String PDM_PermissionType_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Permission Type", j, "String");
					 String PDM_DutyGUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty GUID", j, "String");
					 String PDM_DutyName_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty Name", j, "String");
					
			    	 
		  		 log.info("PDM_assetGuid_Excel_DownloadedFile"+ PDM_assetGuid_Excel_DownloadedFile);
		  		 log.info("PDM_Permission_GUID_Excel_DownloadedFile"+ PDM_Permission_GUID_Excel_DownloadedFile);
		  		 log.info("PDM_Permission_Excel_DownloadedFile"+ PDM_Permission_Excel_DownloadedFile);
		  		log.info("PDM_PermissionType_Excel_DownloadedFile"+ PDM_PermissionType_Excel_DownloadedFile);
		  		log.info("PDM_DutyGUID_Excel_DownloadedFile"+ PDM_DutyGUID_Excel_DownloadedFile);
		  		log.info("PDM_DutyName_Excel_DownloadedFile"+ PDM_DutyName_Excel_DownloadedFile);
		  		
		  		  String db_queryProfiletoDutyMapping=query_ProfiletoDutyMapping;
				  db_queryProfiletoDutyMapping=db_queryProfiletoDutyMapping.replaceAll("AssignableGuidValue", PDM_Permission_GUID_Excel_DownloadedFile);
				  db_queryProfiletoDutyMapping=db_queryProfiletoDutyMapping.replaceAll("DutyGuidValue", PDM_DutyGUID_Excel_DownloadedFile);
				  db_queryProfiletoDutyMapping=db_queryProfiletoDutyMapping.replaceAll("DutyTypeValue", PDM_PermissionType_Excel_DownloadedFile);
				  
	
				  
				  ResultSet profileTodutyMapping_Table_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryProfiletoDutyMapping);
				  
				  while (profileTodutyMapping_Table_Result.next())
					{
						log.info("SODSIM Profile to Duty MappingTable while..............");
						
						db_ProfiletoDutyMapping_ASSIGNABLEGUID = profileTodutyMapping_Table_Result.getString("ASSIGNABLEGUID");
						db_ProfiletoDutyMapping_DUTYGUID = profileTodutyMapping_Table_Result.getString("DUTYGUID");
						db_ProfiletoDutyMapping_DUTYTYPE = profileTodutyMapping_Table_Result.getString("DUTYTYPE");													
					
					}
				  
				  
				  
				  
				  String db_queryDuty=query_Duty_active+ "='"+ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty GUID", j, "String")+"'";


				  ResultSet duty_Table_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryDuty);
				  
				  while (duty_Table_Result.next())
					{
						log.info("SODSIM Duty Table while..............");
						
						db_DutyName = duty_Table_Result.getString("DUTYNAME");		
						
					}

				     log.info("db_DutyName"+ db_DutyName);
				     
				     String db_query_ACR_Asset=query_ACR_Asset;
					  db_query_ACR_Asset=query_ACR_Asset.replaceAll("AccessRightGuidValue", PDM_Permission_GUID_Excel_DownloadedFile);
					  ResultSet query_ACR_Asset_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_query_ACR_Asset);
					  
					  while (query_ACR_Asset_Result.next())
						{
							log.info("SODSIM ACR and Asset Table while..............");
							
							db_assetguid= query_ACR_Asset_Result.getString("ASSETGUID");
							db_acrname= query_ACR_Asset_Result.getString("ACRNAME");	
						
						}
					  
					  log.info("db_assetguid"+ db_assetguid);
				     
				     
					  Assert.assertTrue(PDM_Permission_GUID_Excel_DownloadedFile.equals(db_ProfiletoDutyMapping_ASSIGNABLEGUID));
					  Assert.assertTrue(PDM_DutyGUID_Excel_DownloadedFile.equals(db_ProfiletoDutyMapping_DUTYGUID));
					  Assert.assertTrue(PDM_PermissionType_Excel_DownloadedFile.equals(db_ProfiletoDutyMapping_DUTYTYPE));
					  Assert.assertTrue(PDM_DutyName_Excel_DownloadedFile.equals(db_DutyName));
					  Assert.assertTrue(PDM_assetGuid_Excel_DownloadedFile.equals(db_assetguid));
					  Assert.assertTrue(PDM_Permission_Excel_DownloadedFile.equals(db_acrname));
				     

		  
			  }
		  }
		  }
		  
	}
	
	
	public static void verify_resultantUploadedexceldata(WebDriver driver, String Action,String Status,String Status_comments, String SodParamter) throws Exception {
		
		  String db_Duty_GUID = null;
		  String db_Duty_Status=null;
		  String db_DutyName = null;		
		  String db_DutyDisplay_Name = null;
		  String db_DutyDescription = null;
		  String db_DutyMapping_SODGUID = null;
		  String db_DutyMapping_LHSDUTYGUID = null;
		  String db_DutyMapping_LHSDUTYTYPE = null;
		  String db_DutyMapping_RHSDUTYGUID = null;
		  String db_DutyMapping_RHSDUTYTYPE = null;				
		  String db_DutyMapping_VIOLATIONPRIORITY = null;													
		  String db_DutyMapping_STATUS = null;
		  String db_ProfiletoDutyMapping_ASSIGNABLEGUID = null;
		  String db_ProfiletoDutyMapping_DUTYGUID = null;
		  String db_ProfiletoDutyMapping_DUTYTYPE = null;																						
		  String db_ProfiletoDutyMapping_STATUS = null;	
		  String db_assetguid = null;
		  String db_acrname = null;
		  
		
		  File dir = new File(download_resultant_uploaded_file_path);
		  File dir_sodParameteruploadPath = new File(sodParameteruploadPath);
		
		
		
		  File[] dirContents = dir.listFiles();
		  File[] dirContents_sodParameterupload = dir_sodParameteruploadPath.listFiles();
		  
		  
		  
		  int rowCnt_download_resultant=0;
		  int rowCnt_upload_duty=0;
		  int rowCnt_upload_DM=0;
		  int rowCnt_upload_PDM=0;

		  
		  log.info("dirContents Length"+ dirContents.length);
		  log.info("dirContents_sodParameterupload Length"+ dirContents_sodParameterupload.length);
		  
		  
		  for (int k = 0; k <dirContents_sodParameterupload.length; k++)//upload directory loop(3 Files)--k
		  {
			  log.info("SodParamter : "+SodParamter);
			  log.info("dirContents_sodParameterupload : "+dirContents_sodParameterupload[k].getName());
//			  -----------------------------------------------------------------------------------------Duty Add- Update- Delete Verifications------------------------------------------------------------------------------
				  if(SodParamter.equals("Duty") && dirContents_sodParameterupload[k].getName().equals("Duty.xlsx"))
					  {  for (int i = 0; i < dirContents.length; i++) {//Download directory loop(1 File)	--i
						  log.info("File Name Downloaded :"+dirContents[i].getName());
		    	  
						  rowCnt_download_resultant = ui.getLastRow(download_resultant_uploaded_file_path,dirContents[i].getName(), "Sheet0");
						  log.info("rowCnt_download_resultant:"+rowCnt_download_resultant);
						  
						  rowCnt_upload_duty = ui.getLastRow(sodParameteruploadPath,dirContents_sodParameterupload[k].getName(), "Sheet1"); 
						  log.info("rowCnt_upload_duty:"+rowCnt_upload_duty);
			  

						  for (int j = 2; j <= rowCnt_download_resultant; j++) {// compare data with respect to the downloaded file: numeric j Value will remain same for both Uploaded and downloaded so rowCnt_upload_duty=rowCnt_download_resultant

							 String action_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Action", j, "String");
							 String action_UploadedFile=ui.getData(sodParameteruploadPath,dirContents_sodParameterupload[k].getName(),"Sheet1","Action", j, "String");
							 String status_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Status", j, "String");
							 String statusComments_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Status comments", j, "String");
							 String Duty_Description_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty Description", j, "String");
							 String Duty_Name_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty Name", j, "String");
							 String Duty_GUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty GUID", j, "String");
							 String Duty_Display_Name_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty Display Name", j, "String");
				  
					     log.info("Action from Downloaded File "+ action_DownloadedFile);
					     log.info("Action from Uploaded File - "+ action_UploadedFile);
					     log.info("Status From Downloaded File : - "+status_DownloadedFile);
				  		 log.info("Status comments From Downloaded File : - "+ statusComments_DownloadedFile);				  		 
				  		 log.info("Duty_Description_Excel_DownloadedFile :"+ Duty_Description_Excel_DownloadedFile);
					     log.info("Duty Display Name Excel"+ Duty_Display_Name_Excel_DownloadedFile);
				  		 log.info("Duty Name Excel"+ Duty_Name_Excel_DownloadedFile);
				  		 log.info("Duty GUID Excel"+ Duty_GUID_Excel_DownloadedFile);
				  		 
				  		 
				  		 
				  		 
//					 ---------------------------------------------------------------------------- DB Verification	- For DUTY VALID Scenarios----------------------------------------------------------------------------
				 if (status_DownloadedFile.equals("VALID"))
					  
				   { String db_queryDuty=query_Duty+ "='"+ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty GUID", j, "String")+"'";


					  ResultSet duty_Table_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryDuty);
					  
					  while (duty_Table_Result.next())
						{
							log.info("SODSIM Duty Table while..............");
							db_Duty_Status = duty_Table_Result.getString("STATUS");
							db_Duty_GUID = duty_Table_Result.getString("DUTYGUID");
							db_DutyName = duty_Table_Result.getString("DUTYNAME");		
							db_DutyDisplay_Name = duty_Table_Result.getString("DUTYDISPLAYNAME");													
							db_DutyDescription = duty_Table_Result.getString("DUTYDESCRIPTION");		
						
						}

					     log.info("db_Duty_GUID"+ db_Duty_GUID);
					     log.info("db_DutyName"+ db_DutyName);
					     log.info("db_DutyDisplay_Name"+ db_DutyDisplay_Name);
					     log.info("db_DutyDescription"+ db_DutyDescription);
				  		
				  		 
				      Assert.assertTrue((action_DownloadedFile).equalsIgnoreCase(action_UploadedFile));				  		
					  Assert.assertTrue(status_DownloadedFile.equals("VALID"));
					  Assert.assertTrue(statusComments_DownloadedFile.equals(""));
					  assert (Duty_GUID_Excel_DownloadedFile).equals(db_Duty_GUID) : "db_Duty_GUID";
					  
					  if(!(action_DownloadedFile).equalsIgnoreCase("DELETE"))
					  {
					  assert (db_Duty_Status.equals("ACTIVE")) : "db_DutyStatus";
					  assert (Duty_Name_Excel_DownloadedFile).equals(db_DutyName) : "db_DutyName";
					  assert (Duty_Display_Name_Excel_DownloadedFile).equals(db_DutyDisplay_Name) : "db_DutyDisplay_Name";
					  assert (Duty_Description_Excel_DownloadedFile).equals(db_DutyDescription) : "db_DutyDescription";
					  }
					  
					  if((action_DownloadedFile.equalsIgnoreCase("DELETE")))
					  {
						  assert (db_Duty_Status.equals("DELETED")) : "db_DutyStatus";
					  }
					}
				  		 
				  		 
//				  		---------------------------------------------------------------------------- Verification	- For DUTY INVALID Scenarios----------------------------------------------------------------------------
				  		 
				  		 if (status_DownloadedFile.equals("INVALID"))// What we are getting from parameters passed in feature file
				  		 {
//				  			 The DB query is going to return nothing - Hence there will be a null pointer exception - So we will verify the excel data for invalid scenarios
				  			assert (status_DownloadedFile.equals("INVALID")) : "Status";//Verifying from the sheet
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("DELETE")) && Duty_GUID_Excel_DownloadedFile.equals(""))
				  			{assert (statusComments_DownloadedFile.equals("Field Duty GUID is mandatory during update/delete")) : "Status comments";//Verifying from the sheet
				  			}
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("ADD")&& Duty_Name_Excel_DownloadedFile.equals("")))
				  			{assert (statusComments_DownloadedFile).equals("Field Duty Name is mandatory during create") : "Status comments";//Verifying from the sheet
				  			}
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("ADD")&& Duty_Display_Name_Excel_DownloadedFile.equals("")))
				  			{assert (statusComments_DownloadedFile).equals("Field Duty Display Name is mandatory during create") : "Status comments";//Verifying from the sheet
				  			}
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("ADD")&& Duty_Description_Excel_DownloadedFile.equals("")))
				  			{assert (statusComments_DownloadedFile).equals("Field Duty Description is mandatory during create") : "Status comments";//Verifying from the sheet
				  			}
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("DELETE")) && statusComments_DownloadedFile.contains("not found during update/delete"))
				  			{assert (statusComments_DownloadedFile.equals("Duty GUID "+Duty_GUID_Excel_DownloadedFile+" not found during update/delete")) : "Status comments";//Verifying from the sheet
				  			}
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("ADD")&& Duty_GUID_Excel_DownloadedFile.equals("")))
				  			{assert (statusComments_DownloadedFile.equals("Duty GUID must be empty for add")) : "Status comments";//Verifying from the sheet
				  			}
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("ADD")&& statusComments_DownloadedFile.contains("already exists")))
				  			{assert (statusComments_DownloadedFile.equals("Duty Name already exists")) : "Status comments";//Verifying from the sheet
				  		    }
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("ADD")&& statusComments_DownloadedFile.contains("referenced")))
				  			{assert (statusComments_DownloadedFile.equals("Duty "+Duty_Name_Excel_DownloadedFile+" cannot be deleted while referenced in Duty Matrix and Profile to Duty Mapping")) : "Status comments";//Verifying from the sheet
				  			}
				  			
				  		 }
				  		 
				  		 
	        }
		      
		      }	
		  }
				  
				  
				  
				  
				  
//				  -----------------------------------------------------------------------------------------Duty Mapping Add- Update- Delete Verifications------------------------------------------------------------------------------
					  if(SodParamter.equals("Duty Mapping") && dirContents_sodParameterupload[k].getName().equals("Duty Mapping.xlsx"))
						  {  for (int i = 0; i < dirContents.length; i++) {//Download directory loop(1 File)	--i
							  log.info("File Name Downloaded :"+dirContents[i].getName());
			    	  
							  rowCnt_download_resultant = ui.getLastRow(download_resultant_uploaded_file_path,dirContents[i].getName(), "Sheet0");
							  log.info("rowCnt_download_resultant:"+rowCnt_download_resultant);
							  
							  rowCnt_upload_DM = ui.getLastRow(sodParameteruploadPath,dirContents_sodParameterupload[k].getName(), "Sheet1"); 
							  log.info("rowCnt_upload_DM:"+rowCnt_upload_DM);
				  

							  for (int j = 2; j <= rowCnt_download_resultant; j++) {// compare data with respect to the downloaded file: numeric j Value will remain same for both Uploaded and downloaded so rowCnt_upload_duty=rowCnt_download_resultant


					  
						    				  		 
					  		 
					  		 String action_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Action", j, "String");
							 String action_UploadedFile=ui.getData(sodParameteruploadPath,dirContents_sodParameterupload[k].getName(),"Sheet1","Action", j, "String");
							 String status_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Status", j, "String");
							 String statusComments_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Status comments", j, "String");
							 String dutyMapping_sodGuid_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","SOD GUID", j, "String");
							 String dutyMapping_LeftDutyGUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Left Duty GUID", j, "String");
							 String dutyMapping_LeftDutyName_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Left Duty Name", j, "String");
							 String dutyMapping_LeftPermissionType_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Left Permission Type", j, "String");
							 String dutyMapping_RightDutyGUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Right Duty GUID", j, "String");
							 String dutyMapping_RightDutyName_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Right Duty Name", j, "String");
							 String dutyMapping_RightPermissionType_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Right Permission Type", j, "String");
							 String dutyMapping_violationPriority_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Violation Priority", j, "String");
							 
							 
				  
					     log.info("Action from Downloaded File "+ action_DownloadedFile);
					     log.info("Action from Uploaded File - "+ action_UploadedFile);
					     log.info("Status From Downloaded File : - "+status_DownloadedFile);
				  		 log.info("Status comments From Downloaded File : - "+ statusComments_DownloadedFile);	 
				  		 log.info("dutyMapping_sodGuid_Excel_DownloadedFile"+ dutyMapping_sodGuid_Excel_DownloadedFile);
				  		 log.info("dutyMapping_LeftDutyGUID_Excel_DownloadedFile"+ dutyMapping_LeftDutyGUID_Excel_DownloadedFile);
				  		 log.info("dutyMapping_LeftDutyName_Excel_DownloadedFile"+ dutyMapping_LeftDutyName_Excel_DownloadedFile);
				  		log.info("dutyMapping_LeftPermissionType_Excel_DownloadedFile"+ dutyMapping_LeftPermissionType_Excel_DownloadedFile);
				  		log.info("dutyMapping_RightDutyGUID_Excel_DownloadedFile"+ dutyMapping_RightDutyGUID_Excel_DownloadedFile);
				  		log.info("dutyMapping_RightDutyName_Excel_DownloadedFile"+ dutyMapping_RightDutyName_Excel_DownloadedFile);
				  		log.info("dutyMapping_RightPermissionType_Excel_DownloadedFile"+ dutyMapping_RightPermissionType_Excel_DownloadedFile);
				  		log.info("dutyMapping_violationPriority_Excel_DownloadedFile"+ dutyMapping_violationPriority_Excel_DownloadedFile);
					  		 
					  		 
//						 ---------------------------------------------------------------------------- DB Verification	- For DUTYMapping VALID Scenarios----------------------------------------------------------------------------	
				  		 if (status_DownloadedFile.equals("VALID"))
				  		 { 
						  String db_queryDutyMapping=query_DutyMapping+ "='"+ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","SOD GUID", j, "String")+"'";


						  ResultSet dutyMapping_Table_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryDutyMapping);
						  
						  while (dutyMapping_Table_Result.next())
							{
								log.info("SODSIM Duty MappingTable while..............");
								
								db_DutyMapping_SODGUID = dutyMapping_Table_Result.getString("SODGUID");
								db_DutyMapping_LHSDUTYGUID = dutyMapping_Table_Result.getString("LHSDUTYGUID");
								db_DutyMapping_LHSDUTYTYPE = dutyMapping_Table_Result.getString("LHSDUTYTYPE");
								db_DutyMapping_RHSDUTYGUID = dutyMapping_Table_Result.getString("RHSDUTYGUID");
								db_DutyMapping_RHSDUTYTYPE= dutyMapping_Table_Result.getString("RHSDUTYTYPE");	
								
								db_DutyMapping_VIOLATIONPRIORITY = dutyMapping_Table_Result.getString("VIOLATIONPRIORITY");													
								db_DutyMapping_STATUS = dutyMapping_Table_Result.getString("STATUS");		
							
							}
						  
						  
						  

						     log.info("db_DutyMapping_SODGUID"+ db_DutyMapping_SODGUID);
						     log.info("db_DutyMapping_LHSDUTYGUID"+ db_DutyMapping_LHSDUTYGUID);
						     log.info("db_DutyMapping_LHSDUTYTYPE"+ db_DutyMapping_LHSDUTYTYPE);
						     log.info("db_DutyMapping_RHSDUTYGUID"+ db_DutyMapping_RHSDUTYGUID);
						     log.info("db_DutyMapping_RHSDUTYTYPE"+ db_DutyMapping_RHSDUTYTYPE);
						     log.info("db_DutyMapping_VIOLATIONPRIORITY"+ db_DutyMapping_VIOLATIONPRIORITY);
						     log.info("db_DutyMapping_STATUS"+ db_DutyMapping_STATUS);
					  		 
						     log.info("dutyMapping_sodGuid_Excel_DownloadedFile"+ dutyMapping_sodGuid_Excel_DownloadedFile);
					  		 log.info("dutyMapping_LeftDutyGUID_Excel_DownloadedFile"+ dutyMapping_LeftDutyGUID_Excel_DownloadedFile);
					  		 log.info("dutyMapping_LeftDutyName_Excel_DownloadedFile"+ dutyMapping_LeftDutyName_Excel_DownloadedFile);
					  		log.info("dutyMapping_LeftPermissionType_Excel_DownloadedFile"+ dutyMapping_LeftPermissionType_Excel_DownloadedFile);
					  		log.info("dutyMapping_RightDutyGUID_Excel_DownloadedFile"+ dutyMapping_RightDutyGUID_Excel_DownloadedFile);
					  		log.info("dutyMapping_RightDutyName_Excel_DownloadedFile"+ dutyMapping_RightDutyName_Excel_DownloadedFile);
					  		log.info("dutyMapping_RightPermissionType_Excel_DownloadedFile"+ dutyMapping_RightPermissionType_Excel_DownloadedFile);
					  		log.info("dutyMapping_violationPriority_Excel_DownloadedFile"+ dutyMapping_violationPriority_Excel_DownloadedFile);
					  		
						  if(!(action_DownloadedFile).equalsIgnoreCase("DELETE"))
						  { assert (db_DutyMapping_STATUS.equals("ACTIVE")) : "db_DutyMappingStatus";	
						  Assert.assertTrue(action_DownloadedFile.equalsIgnoreCase(action_UploadedFile));				  		
						  Assert.assertTrue(dutyMapping_sodGuid_Excel_DownloadedFile.equals(db_DutyMapping_SODGUID));
						  Assert.assertTrue(dutyMapping_LeftDutyGUID_Excel_DownloadedFile.equals(db_DutyMapping_LHSDUTYGUID));
						  Assert.assertTrue(dutyMapping_LeftPermissionType_Excel_DownloadedFile.equals(db_DutyMapping_LHSDUTYTYPE));
						  Assert.assertTrue(dutyMapping_RightDutyGUID_Excel_DownloadedFile.equals(db_DutyMapping_RHSDUTYGUID));
						  Assert.assertTrue(dutyMapping_RightPermissionType_Excel_DownloadedFile.equals(db_DutyMapping_RHSDUTYTYPE));
						  Assert.assertTrue(dutyMapping_violationPriority_Excel_DownloadedFile.equals(db_DutyMapping_VIOLATIONPRIORITY));
						  Assert.assertTrue(status_DownloadedFile.equals("VALID"));
						  Assert.assertTrue(statusComments_DownloadedFile.equals(""));
						  }
						  
						  
						  if(action_DownloadedFile.equalsIgnoreCase("DELETE"))
						  {
							  Assert.assertTrue(action_DownloadedFile.equalsIgnoreCase(action_UploadedFile));				  		
							  Assert.assertTrue(dutyMapping_sodGuid_Excel_DownloadedFile.equals(db_DutyMapping_SODGUID));
							  assert (db_DutyMapping_STATUS.equals("DELETED")) : "db_DutyMappingStatus";
							  Assert.assertTrue(status_DownloadedFile.equals("VALID"));
							  Assert.assertTrue(statusComments_DownloadedFile.equals(""));
						  }
						  
							  }
				  		 
				  		 
//						 ---------------------------------------------------------------------------- Verification	- For DUTYMapping INVALID Scenarios----------------------------------------------------------------------------
				  		 
				  		if (status_DownloadedFile.equals("INVALID"))
				  		{
				  			assert (status_DownloadedFile.equals("INVALID")) : "Status";//Verifying from the sheet
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("DELETE")) && dutyMapping_sodGuid_Excel_DownloadedFile.equals(""))
				  			{assert (statusComments_DownloadedFile.equals("Field SOD GUID is mandatory during update/delete")) : "Status comments";}
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && dutyMapping_LeftDutyGUID_Excel_DownloadedFile.equals(""))
				  			{assert (statusComments_DownloadedFile.equals("Field Left Duty GUID is mandatory during create/update")) : "Status comments";}
				  			
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && dutyMapping_LeftPermissionType_Excel_DownloadedFile.equals(""))
				  			{assert (statusComments_DownloadedFile.equals("Field Left Permission Type is mandatory during create/update")) : "Status comments";}
				  			
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && statusComments_DownloadedFile.contains("Left Duty GUID"))
				  			{assert (statusComments_DownloadedFile.equals("Left Duty GUID "+dutyMapping_LeftDutyGUID_Excel_DownloadedFile+" is not found in the system")) : "Status comments";}// To be revisited this scenario
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && ((!dutyMapping_LeftPermissionType_Excel_DownloadedFile.equals("RO")||(!dutyMapping_LeftPermissionType_Excel_DownloadedFile.equals("Admin")||(!dutyMapping_LeftPermissionType_Excel_DownloadedFile.equals("Action"))))))
				  			{assert (statusComments_DownloadedFile.equals("Left Permission Type is invalid. Must be one of RO, Admin, Action")) : "Status comments";}

				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && dutyMapping_RightDutyGUID_Excel_DownloadedFile.equals(""))
				  			{assert (statusComments_DownloadedFile.equals("Field Right Duty GUID is mandatory during create/update")) : "Status comments";}
				  			
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && dutyMapping_RightPermissionType_Excel_DownloadedFile.equals(""))
				  			{assert (statusComments_DownloadedFile.equals("Field Right Permission Type is mandatory during create/update")) : "Status comments";}
				  			
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && statusComments_DownloadedFile.contains("Right Duty GUID"))
				  			{assert (statusComments_DownloadedFile.equals("Right Duty GUID "+dutyMapping_RightDutyGUID_Excel_DownloadedFile+" is not found in the system")) : "Status comments";}// To be revisited this scenario
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && ((!dutyMapping_RightPermissionType_Excel_DownloadedFile.equals("RO")||(!dutyMapping_RightPermissionType_Excel_DownloadedFile.equals("Admin")||(!dutyMapping_RightPermissionType_Excel_DownloadedFile.equals("Action"))))))
				  			{assert (statusComments_DownloadedFile.equals("Right Permission Type is invalid. Must be one of RO, Admin, Action")) : "Status comments";}
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && dutyMapping_violationPriority_Excel_DownloadedFile.equals(""))
				  			{assert (statusComments_DownloadedFile.equals("Field Violation Priority is mandatory during create/update")) : "Status comments";}
				  			
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("ADD")) && ((!dutyMapping_violationPriority_Excel_DownloadedFile.equals("1")||(!dutyMapping_violationPriority_Excel_DownloadedFile.equals("2")||(!dutyMapping_violationPriority_Excel_DownloadedFile.equals("3"))||(!dutyMapping_violationPriority_Excel_DownloadedFile.equals("4"))))))
				  			{assert (statusComments_DownloadedFile.equals("Violation Priority is invalid. Must be one of 1, 2, 3, 4")) : "Status comments";}
				  			
				  			
				  			if((action_DownloadedFile.equalsIgnoreCase("UPDATE")||action_DownloadedFile.equalsIgnoreCase("DELETE")) && dutyMapping_sodGuid_Excel_DownloadedFile.contains("Duty Mapping with SOD GUID"))
				  			{assert (statusComments_DownloadedFile.equals("Duty Mapping with SOD GUID "+dutyMapping_sodGuid_Excel_DownloadedFile+" not found during update/delete")) : "Status comments";}// To be revisited this scenario
				  			
				  			
//				  			To be Revisited- DB verification required here
//				  			assert (statusComments_DownloadedFile.equals("Duty Mapping for Left Duty GUID <Left Duty GUID>, Left Permission Type <Left Permission Type>, Right Duty GUID <Right Duty GUID> and Right Permission Type <Right Permission Type> already exists")) : "Status comments";//Verifying from the sheet
				  			
				  			
				  			
				  			
				  			
				  		}
				  		 
				  		 
				  		 
			
		        }
			      
			      }	
			  }
					  
					  
//					  -----------------------------------------------------------------------------------------Profile to Duty Mapping Add- Update- Delete Verifications------------------------------------------------------------------------------
						  if(SodParamter.equals("PDM") && dirContents_sodParameterupload[k].getName().equals("ProfiletoDutyMapping.xlsx"))
							  {  for (int i = 0; i < dirContents.length; i++) {//Download directory loop(1 File)	--i
								  log.info("File Name Downloaded :"+dirContents[i].getName());
				    	  
								  rowCnt_download_resultant = ui.getLastRow(download_resultant_uploaded_file_path,dirContents[i].getName(), "Sheet0");
								  log.info("rowCnt_download_resultant:"+rowCnt_download_resultant);
								  
								  rowCnt_upload_PDM = ui.getLastRow(sodParameteruploadPath,dirContents_sodParameterupload[k].getName(), "Sheet1"); 
								  log.info("rowCnt_upload_PDM:"+rowCnt_upload_PDM);
					  

								  for (int j = 2; j <= rowCnt_download_resultant; j++) {// compare data with respect to the downloaded file: numeric j Value will remain same for both Uploaded and downloaded so rowCnt_upload_duty=rowCnt_download_resultant

									  
									     String action_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Action", j, "String");
										 String action_UploadedFile=ui.getData(sodParameteruploadPath,dirContents_sodParameterupload[k].getName(),"Sheet1","Action", j, "String");
										 String status_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Status", j, "String");
										 String statusComments_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Status comments", j, "String");
										 String PDM_assetGuid_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Asset GUID", j, "String");
										 String PDM_Permission_GUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Permission GUID", j, "String");
										 String PDM_Permission_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Permission", j, "String");
										 String PDM_PermissionType_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Permission Type", j, "String");
										 String PDM_DutyGUID_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty GUID", j, "String");
										 String PDM_DutyName_Excel_DownloadedFile=ui.getData(download_resultant_uploaded_file_path,dirContents[i].getName(),"Sheet0","Duty Name", j, "String");
										
										 
										 
							  
								     log.info("Action from Downloaded File "+ action_DownloadedFile);
								     log.info("Action from Uploaded File - "+ action_UploadedFile);
								     log.info("Status From Downloaded File : - "+status_DownloadedFile);
							  		 log.info("Status comments From Downloaded File : - "+ statusComments_DownloadedFile);	 
							  		 log.info("PDM_assetGuid_Excel_DownloadedFile"+ PDM_assetGuid_Excel_DownloadedFile);
							  		 log.info("PDM_Permission_GUID_Excel_DownloadedFile"+ PDM_Permission_GUID_Excel_DownloadedFile);
							  		 log.info("PDM_Permission_Excel_DownloadedFile"+ PDM_Permission_Excel_DownloadedFile);
							  		log.info("PDM_PermissionType_Excel_DownloadedFile"+ PDM_PermissionType_Excel_DownloadedFile);
							  		log.info("PDM_DutyGUID_Excel_DownloadedFile"+ PDM_DutyGUID_Excel_DownloadedFile);
							  		log.info("PDM_DutyName_Excel_DownloadedFile"+ PDM_DutyName_Excel_DownloadedFile);
							  		

						  
							   
						  		 
//									 ---------------------------------------------------------------------------- DB Verification	- For Profile2DUTYMapping VALID Scenarios----------------------------------------------------------------------------  
						  		
							  		 if (status_DownloadedFile.equals("VALID"))
							  		 {
							  String db_queryProfiletoDutyMapping=query_ProfiletoDutyMapping;
							  db_queryProfiletoDutyMapping=db_queryProfiletoDutyMapping.replaceAll("AssignableGuidValue", PDM_Permission_GUID_Excel_DownloadedFile);
							  db_queryProfiletoDutyMapping=db_queryProfiletoDutyMapping.replaceAll("DutyGuidValue", PDM_DutyGUID_Excel_DownloadedFile);
							  db_queryProfiletoDutyMapping=db_queryProfiletoDutyMapping.replaceAll("DutyTypeValue", PDM_PermissionType_Excel_DownloadedFile);
							  
				
							  ResultSet profileTodutyMapping_Table_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryProfiletoDutyMapping);
							  
							  while (profileTodutyMapping_Table_Result.next())
								{
									log.info("SODSIM Profile to Duty MappingTable while..............");
									
									db_ProfiletoDutyMapping_ASSIGNABLEGUID = profileTodutyMapping_Table_Result.getString("ASSIGNABLEGUID");
									db_ProfiletoDutyMapping_DUTYGUID = profileTodutyMapping_Table_Result.getString("DUTYGUID");
									db_ProfiletoDutyMapping_DUTYTYPE = profileTodutyMapping_Table_Result.getString("DUTYTYPE");																						
									db_ProfiletoDutyMapping_STATUS = profileTodutyMapping_Table_Result.getString("STATUS");		
								
								}
							  
							  String db_queryDuty=query_Duty+ "='"+PDM_DutyGUID_Excel_DownloadedFile+"'";
							  ResultSet duty_Table_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_queryDuty);
							  
							  while (duty_Table_Result.next())
								{
									log.info("SODSIM Duty Table while..............");
									
									db_DutyName = duty_Table_Result.getString("DUTYNAME");		
											
								
								}
							  
							  String db_query_ACR_Asset=query_ACR_Asset;
							  db_query_ACR_Asset=query_ACR_Asset.replaceAll("AccessRightGuidValue", PDM_Permission_GUID_Excel_DownloadedFile);
							  ResultSet query_ACR_Asset_Result = ui.select_query_new(sodsim_host,"SID", sodsim_sid, sodsim_user, sodsim_pw,db_query_ACR_Asset);
							  
							  while (query_ACR_Asset_Result.next())
								{
									log.info("SODSIM ACR and Asset Table while..............");
									
									db_assetguid= query_ACR_Asset_Result.getString("ASSETGUID");
									db_acrname= query_ACR_Asset_Result.getString("ACRNAME");		
											
								
								}
							  

							     log.info("db_ProfiletoDutyMapping_ASSIGNABLEGUID"+ db_ProfiletoDutyMapping_ASSIGNABLEGUID);
							     log.info("db_ProfiletoDutyMapping_DUTYGUID"+ db_ProfiletoDutyMapping_DUTYGUID);
							     log.info("db_ProfiletoDutyMapping_DUTYTYPE"+ db_ProfiletoDutyMapping_DUTYTYPE);
							     log.info("db_ProfiletoDutyMapping_STATUS"+ db_ProfiletoDutyMapping_STATUS);
							     
						  		 			  		
						  		
						  		
						      
							  
							  if(!(action_DownloadedFile).equalsIgnoreCase("DELETE"))
							  { assert (db_ProfiletoDutyMapping_STATUS.equals("ACTIVE")) : "db_ProfiletoDutyMappingStatus";
							  }
							  
							  if((action_DownloadedFile).equalsIgnoreCase("DELETE"))
							  {assert (db_DutyMapping_STATUS.equals("DELETED")) : "db_DutyMappingStatus";
							  }
								
							  Assert.assertTrue(statusComments_DownloadedFile.equals(""));
							  Assert.assertTrue(status_DownloadedFile.equals("VALID"));
							  
							  Assert.assertTrue(action_DownloadedFile.equalsIgnoreCase(action_UploadedFile));				  		
							  Assert.assertTrue(PDM_Permission_GUID_Excel_DownloadedFile.equals(db_ProfiletoDutyMapping_ASSIGNABLEGUID));
							  Assert.assertTrue(PDM_DutyGUID_Excel_DownloadedFile.equals(db_ProfiletoDutyMapping_DUTYGUID));
							  Assert.assertTrue(PDM_PermissionType_Excel_DownloadedFile.equals(db_ProfiletoDutyMapping_DUTYTYPE));
							  Assert.assertTrue(PDM_DutyName_Excel_DownloadedFile.equals(db_DutyName));
							  Assert.assertTrue(PDM_assetGuid_Excel_DownloadedFile.equals(db_assetguid));
							  Assert.assertTrue(PDM_Permission_Excel_DownloadedFile.equals(db_acrname));
								  }
							  		 
//									 ---------------------------------------------------------------------------- Verification	- For Profile2DUTYMapping INVALID Scenarios----------------------------------------------------------------------------		  		 
							  		 
							  		if (status_DownloadedFile.equals("INVALID"))
							  		{
							  			
							  			assert (status_DownloadedFile.equals("INVALID")) : "Status";//Verifying from the sheet
							  			 log.info("Action from Downloaded File "+ action_DownloadedFile);
									     log.info("Action from Uploaded File - "+ action_UploadedFile);
									     log.info("Status From Downloaded File : - "+status_DownloadedFile);
								  		 log.info("Status comments From Downloaded File : - "+ statusComments_DownloadedFile);	 
								  		 log.info("PDM_assetGuid_Excel_DownloadedFile"+ PDM_assetGuid_Excel_DownloadedFile);
								  		 log.info("PDM_Permission_GUID_Excel_DownloadedFile"+ PDM_Permission_GUID_Excel_DownloadedFile);
								  		 log.info("PDM_Permission_Excel_DownloadedFile"+ PDM_Permission_Excel_DownloadedFile);
								  		log.info("PDM_PermissionType_Excel_DownloadedFile"+ PDM_PermissionType_Excel_DownloadedFile);
								  		log.info("PDM_DutyGUID_Excel_DownloadedFile"+ PDM_DutyGUID_Excel_DownloadedFile);
								  		log.info("PDM_DutyName_Excel_DownloadedFile"+ PDM_DutyName_Excel_DownloadedFile);
							  			
							  			if((action_DownloadedFile.equalsIgnoreCase("ADD")||action_DownloadedFile.equalsIgnoreCase("DELETE")) && PDM_Permission_GUID_Excel_DownloadedFile.equals(""))
							  			{assert (statusComments_DownloadedFile.equals("Field Permission GUID_ is mandatory during create/delete")) : "Status comments";}
							  			
							  			if((action_DownloadedFile.equalsIgnoreCase("ADD")||action_DownloadedFile.equalsIgnoreCase("DELETE")) && PDM_PermissionType_Excel_DownloadedFile.equals(""))
							  			{assert (statusComments_DownloadedFile.equals("Field Permission Type is mandatory during create/delete")) : "Status comments";}
							  			
							  			if((action_DownloadedFile.equalsIgnoreCase("ADD")||action_DownloadedFile.equalsIgnoreCase("DELETE")) && PDM_DutyGUID_Excel_DownloadedFile.equals(""))
							  			{assert (statusComments_DownloadedFile.equals("Field Duty GUID is mandatory during create/delete")) : "Status comments";}
							  			
//							  			if((action_DownloadedFile.equals("ADD")||action_DownloadedFile.equals("DELETE")) && PDM_DutyGUID_Excel_DownloadedFile.equals("")) // To be revisited with DB verifications
//							  			{assert (statusComments_DownloadedFile.equals("Permission GUID <Permission GUID> not found in the system")) : "Status comments";}
							  			
							  			/*assert (statusComments_DownloadedFile.equals("Permission Type is invalid. Must be one of RO, Admin, Action")) : "Status comments";
							  			assert (statusComments_DownloadedFile.equals("Duty GUID <Duty GUID> is not found in the system")) : "Status comments";
							  			assert (statusComments_DownloadedFile.equals("Profile to Duty Mapping for Permission GUID <ACR/Role GUID>, Permission Type_<Permission Type>_ and Duty GUID <Duty GUID> not found to delete")) : "Status comments";
							  			assert (statusComments_DownloadedFile.equals("Profile to Duty Mapping for Permission GUID <ACR/Role GUID>, Permission Type <Permission Type> and Duty GUID <Duty GUID> already exists")) : "Status comments";
							  			assert (statusComments_DownloadedFile.equals("Permission Type <Permission Type> for Permission GUID <ACR/Role GUID> is not unique. Permission GUID is already mapped to a different Permission Type")) : "Status comments";
							  			/*
							  			 * 01.09 Add Duty - Verify unsuccessful upload of file when column names are invalid or blank---d,dm,pdm
01.10 Add Duty - Verify unsuccessful upload of file with error message - If file uploaded with same Duty Name
01.15 Add Duty - Verify unsuccessful upload of file with error message - If file uploaded with Duty Guid
Al together error messages-d,dm pdm
Verify the unsuccesfull upload of update file with error message  when duty is mapped to a duty matrix or a profile to duty mapping
verify update of pdm not allowed
01.18 Verify that the Action field is populated for the resultant upload file and not populated for the downloaded dump from database for PDM parameter
01.19 Verify the sort order for download of Duty
01.17 Verify that Guidance PDF is downloaded to rectify the upload errors
							  			 */
							  			
							  		}
							  		 
							  		 
							  		 
							  		 
				
			        }
				      
				      }	
				  }
	}
		
	}

	public static void verify_data_table(WebDriver driver, List<String> Data) throws Exception {
		
		
		WebElement mytable = SegregationofDutiesHomePageObjects.data_table_upload;
		// To locate rows of table.
		List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
		// To calculate no of rows In table.
		int rows_count = rows_table.size();
		int i=0;
		// Loop will execute till the last row of table.

		log.info("Data of :"+i+" "+Data.get(i));
		
		 for (int row = 0; row < rows_count; row++) {
			// To locate columns(cells) of that specific row.
			List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
			// To calculate no of columns (cells). In that specific row.
			int columns_count = Columns_row.size();
			log.info("Number of cells In Row " + row + " are " + columns_count);
			// Loop will execute till the last cell of that specific row.
			for (int column = 0; column < columns_count; column++) {
				// To retrieve text from that specific cell.
                
				String celltext = Columns_row.get(column).getText();
				log.info("celltext"+celltext);
				
				
				if(celltext.equals("Total records in input file"))
				{log.info("Data1"+Data.get(i));
					assertEquals("Total records in input file",celltext);
					String celltext_corresponding = Columns_row.get(column+2).getText();
					log.info("Value of celltext_corresponding 1 " + celltext_corresponding);
					assertEquals(Data.get(i), celltext_corresponding);
					i++;
					continue ;
				}
				
				if(celltext.equals("Total records successfully uploaded"))
				{log.info("Data2"+Data.get(i));
					assertEquals("Total records successfully uploaded",celltext);
					String celltext_corresponding = Columns_row.get(column+2).getText();
					log.info("Value of celltext_corresponding 2 " + celltext_corresponding);
					assertEquals(Data.get(i), celltext_corresponding);
					i++;
					continue;
				}

				if(celltext.equals("Total records processed"))
				{log.info("Data3"+Data.get(i));
					assertEquals("Total records processed",celltext);
					String celltext_corresponding = Columns_row.get(column+2).getText();
					log.info("Value of celltext_corresponding 3 " + celltext_corresponding);
					assertEquals(Data.get(i), celltext_corresponding);
					i++;
					continue;
				}
				
				if(celltext.equals("Total records failed upload"))
				{log.info("Data4"+Data.get(i));
					assertEquals("Total records failed upload",celltext);
					String celltext_corresponding = Columns_row.get(column+2).getText();
					log.info("Value of celltext_corresponding 4 " + celltext_corresponding);
					assertEquals(Data.get(i), celltext_corresponding);
					
					continue;
				}
				
				


			} // end of column loop
		} // end of row loop

	} // End of method
} // End of class

// public static String isLinkBroken(URL url) throws Exception
// {
// String response = "";
// //*[@id="spinner_div"]/div[5]/table/tbody/tr/td/div/div[2]/table/tbody/tr[1]/td[3]
// *[@id="spinner_div"]/div[5]/table/tbody/tr/td/div/div[2]/table/tbody/tr[1]/td[1]
// HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//// URL url= new URL(link);
//// String result=isLinkBroken(url);
//// Thread.sleep(40000);
//// log.info("result"+result);
// }
// try
//
// { connection.connect();
//
// Thread.sleep(40000);
// response = connection.getResponseMessage();
// Thread.sleep(4000);
//
// connection.disconnect();
//
// return response;
//
// }
//
// catch(Exception exp)
//
// { return exp.getMessage();
// }
//
// }
