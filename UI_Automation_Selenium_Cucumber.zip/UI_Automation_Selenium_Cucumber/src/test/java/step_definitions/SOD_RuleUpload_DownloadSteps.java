package step_definitions;

import cucumber.api.PendingException;
import helpers.Browser;
//import helpers.Log;


import helpers.Common_Group;
import helpers.ScreenshotHelper;
import modules.Reusable_Page_Functions;

import java.util.Iterator;
import java.util.Map;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
//import org.mortbay.log.Log;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import pageobjects.Data;
import pageobjects.SegregationofDutiesHomePageObjects;
import pageobjects.TestDatas;


//import pageobjects.demonstarting_yaml;
//import helpers.ConfigUtils;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import freemarker.core.Environment;
//import com.relevantcodes.extentreports.ExtentReports;
//import com.relevantcodes.extentreports.ExtentTest;
//import com.relevantcodes.extentreports.LogStatus;
import java.text.SimpleDateFormat;
import java.util.Date;


import java.io.File;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.snakeyaml.Yaml;
import com.fasterxml.jackson.dataformat.yaml.snakeyaml.constructor.Constructor;
import com.jacob.com.LibraryLoader;

import atu.alm.wrapper.ALMServiceWrapper;
import atu.alm.wrapper.enums.StatusAs;
import atu.alm.wrapper.exceptions.ALMServiceException;

import com.jacob.com.LibraryLoader;
import com.mercury.qualitycenter.otaclient.ClassFactory;
import com.mercury.qualitycenter.otaclient.IAttachment;
import com.mercury.qualitycenter.otaclient.IAttachmentFactory;
import com.mercury.qualitycenter.otaclient.IExtendedStorage;
import com.mercury.qualitycenter.otaclient.IRun;
import com.mercury.qualitycenter.otaclient.IRunFactory;
import com.mercury.qualitycenter.otaclient.ITDConnection;
import com.mercury.qualitycenter.otaclient.ITestSetFactory;
import atu.alm.wrapper.ALMServiceWrapper;
import atu.alm.wrapper.ITestCase;
import atu.alm.wrapper.ITestCaseRun;
import atu.alm.wrapper.ITestSet;
import atu.alm.wrapper.enums.StatusAs;



@SuppressWarnings("unused")
public class SOD_RuleUpload_DownloadSteps {
    public WebDriver driver;
    public String ExpectedText;
    
    /*public static void updateExceptionPath() throws ALMServiceException {
    	System.setProperty("jacob.dll.path", "P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/jacob-1.14.3-x86.dll");
    }*/
//    ****changed paths
/*    C:\Program Files\maven\apache-maven-3.2.5\bin;C:\Program Files\OSS\JDK18031\jre\bin
    C:\Program Files\maven\apache-maven-3.2.5\bin;C:\Program Files (x86)\OSS\JDK18031\jre\bin


    C:\Program Files\OSS\JDK18031
    C:\Program Files (x86)\OSS\JDK18031


    ******changed prefernec
    preferences --> jre-->edit
    
    register the dll in syswow64
    lgherkin issue formatter---you shud have the jars in the refrenced libraries which are in cucumber folder and not mentioned in pom file*/
       
    public void updateResults() throws ALMServiceException {
//    	updateExceptionPath();
    	System.setProperty("jacob.dll.path", "P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/jacob-1.14.3-x86.dll");
    	LibraryLoader.loadJacobLibrary();
    	 ALMServiceWrapper wrapper = new ALMServiceWrapper("HTTP://BW.QUALITYCENTER.IT.UBS.COM/QCBIN/");
    	    wrapper.connect("t610284","Skaurav86#", "INTERNALACCESSMANAGEMENT", "InternalAccessManagement");
    	    wrapper.updateResult("/AS32319 - Internal Access Management Services/32. Release 1.14.2 - cJML/1. SIT/01. Iteration 1 - Cycle 1/REST", "REST", 43711, "[1]Test for ALM Integration With Selenium", StatusAs.PASSED);
    	    wrapper.close();
    	    
    	    ITDConnection itdc = ClassFactory.createTDConnection();

    	    /*itdc.initConnectionEx(url);

    	    itdc.connectProjectEx(domain, project, username, password);
    	 String fname ="C:\\ATP\\output.xlsx";
    	   ITDConnection itdc= ClassFactory.createTDConnection();
    	    itdc.initConnectionEx("http://ALMURL:8080/qcbin");
    	          System.out.println(itdc.connected());
    	          itdc.connectProjectEx("domain_name","Project_name","username","password");
    	         
    	    IRunFactory sRunFactory = (itdc.runFactory()).queryInterface(IRunFactory.class);
    	          IRun sRun = (sRunFactory.item(1)).queryInterface(IRun.class);
    	         
    	          String fileName = new File(fname).getName();
    	    String folderName = new File(fname).getParent();
    	              
    	    try{
    	            IAttachmentFactory attachfac = sRun.attachments().queryInterface(IAttachmentFactory.class);
    	     IAttachment attach = attachfac.addItem(fileName).queryInterface(IAttachment.class);
    	            IExtendedStorage extAttach = attach.attachmentStorage().queryInterface(IExtendedStorage.class);
    	     extAttach.clientPath(folderName); 
    	     extAttach.save(fileName, true);
    	     attach.description("File");
    	     attach.post();
    	     attach.refresh();        
    	    }catch(Exception e) {
    	     System.out.println("QC Exceptione : "+e.getMessage());
    	    }*/
  }
    
    final static Logger log = Logger.getLogger(SOD_RuleUpload_DownloadSteps.class);
    


    @When("^I open the upload download SOD page$")
    public void open_the_upload_download_SOD_page() throws Throwable
    {

    driver =Browser.getBrowser("CHROME");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);		
	driver.get("http://automationtestingutilities.blogspot.com/2013/12/IntegrationWithQCorALMusingALMServiceWrapperPart2.html");
//	driver.get("http://automationpractice.com/index.php");	
	ScreenshotHelper.screenShot_all();
	updateResults();

    	
    }
    

    @And("^I use \"([^\"]*)\" to login$")
    public void use_test_data_from_yaml_tologin(String DataType) throws Throwable
    {

		
//    	PageFactory.initElements(driver, demonstarting_yaml.class);		
//		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		String email=null;
    	String Passwd=null;
    	String Firstname=null;
    	String RollNo=null;

		 ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
		 mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

	        	String path_yaml="P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/src/test/resources/testData/";
	        	TestDatas obj = mapper.readValue(new File(path_yaml+"Testdata.yaml"), TestDatas.class);
	        	
	        	Iterator<Data> iterator = obj.getTestdatas().iterator();	        	
	        	
    	
	    			
	    		
	        	
    
    while(iterator.hasNext()) {
		
		Map<String, String> data = iterator.next().getData();
		
		
		if(DataType.equals("ValidTestData") && data.get("DataType").equals("ValidTestData")) {
			email=data.get("Email");
			Passwd=data.get("pasw");
			System.out.println("Email ID is " +email);
			System.out.println("Passwd is "+Passwd);
				    				
		}
		
		
		if(DataType.equals("RegistrationData") && data.get("DataType").equals("RegistrationData")) {
			
			Firstname=data.get("Fname");
			RollNo=data.get("RollNo");
			System.out.println("Email ID is " +email);
			System.out.println("Passwd is "+Passwd);
			
			System.out.println("First Name is "+Firstname);
			System.out.println("Roll No is "+RollNo);
				    				
		}
    }
    
    
    System.out.println("Outside Email ID is " +email);
	System.out.println("Outside Passwd is "+Passwd);
	System.out.println("Outside First Name is "+Firstname);
	System.out.println("Outside Roll No is "+RollNo);
	
	
	
	 Map<String, Object> data = new HashMap<String, Object>();
	   data.put("name", "Silenthand Olleander");
	   data.put("race", "Human");
	   data.put("traits", new String[] { "ONE_HAND", "ONE_EYE" });

	   Yaml yaml = new Yaml();
	   FileWriter writer = new FileWriter("P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/src/test/resources/testData/TestOutput.yaml");
	   yaml.dump(data, writer);
    }
	    		
	    		/*while(iterator.hasNext()) {
	    			
	    			Map<String, String> data = iterator.next().getData();
	    			if(data.get("DataType").equals("ValidTestData")) {
	    				System.out.println(data.get("Email"));
	    				System.out.println(data.get("pasw"));
	    					    				
	    			}
	    			
	    			if(data.get("DataType").equals("RegistrationData")) {
	    				System.out.println(data.get("Fname"));
	    				System.out.println(data.get("RollNo"));
	    					    				
	    			}
	    			
	    		}*/
	        	

	        		
    	
    
    
     

 
    @When("^I should be able to see the \"([^\"]*)\" text$")
    public void i_should_be_able_to_see_the_text(List<String> ExpectedText) throws Throwable {
    	

        
    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		

		String str= "";	
		
		for(int i=0;i< ExpectedText.size();i++)
		{
			if(i==0){
				str=str.concat(ExpectedText.get(i));
			}
			else{
				str=str.concat(", ").concat(ExpectedText.get(i));
			}
		}

		for(String text: str.split(";")){
			if(! text.contains("/n"))
				
			{log.info("text value...."+text);
			Reusable_Page_Functions.verify_page_text(driver,text);
			}
			else {text=text.replace("/n", System.lineSeparator());
			log.info("text value...."+text);
				Reusable_Page_Functions.verify_page_text(driver,text);
			}
		}
		
		ScreenshotHelper.screenShot_all();
    }

    
    
   
    
    
    @Then("^I should be able to see the page \"([^\"]*)\" elements$")
    public void i_should_be_able_to_see_the_page_elements(List<String> ExpectedWebElement) throws Throwable {
    	

        
    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
//		By Default : List<String> separates elements by (,)
		for(int i=0;i< ExpectedWebElement.size();i++)
		{
			Reusable_Page_Functions.verify_page_elements(driver,ExpectedWebElement.get(i));
	   }
		

		ScreenshotHelper.screenShot_all();
    }
    
    
    @And("^I should be able to view the \"([^\"]*)\" headerLinks$")
    public void i_should_be_able_to_view_the_headerLinks(List<String> ExpectedWebLink) throws Throwable {

    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
		SegregationofDutiesHomePageObjects.external_links.click();	
		ScreenshotHelper.screenShot_all();
		
		for(int i=0;i< ExpectedWebLink.size();i++)
		{
			Reusable_Page_Functions.verify_header_links(driver,ExpectedWebLink.get(i));
	   }

		
    }
    

     
    @And("^I select both the checkboxes$")
    public void  i_select_both_the_checkboxes() throws Throwable {
        
    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
		Reusable_Page_Functions.click_both_checkbox(driver);
		ScreenshotHelper.screenShot_all();
    }
    
    
    
    @And("^I select \"([^\"]*)\" as Parameter from dropdown$")
    public void  i_select_as_Parameter_from_dropdown(String SodParameter) throws Throwable {
        
    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
		Reusable_Page_Functions.select_sod_parameter(driver,SodParameter);
		ScreenshotHelper.screenShot_all();

    }
    
    
    
    @And("^I should be able to verify the downloaded \"([^\"]*)\" data$")
    public void  i_should_be_able_to_verify_the_downloaded_data(String SodParameter) throws Throwable {
        
    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
		Reusable_Page_Functions.verify_downloadedexceldata(driver,SodParameter);
		ScreenshotHelper.screenShot_all();

    }
    
     
    
    
    @Then("^I am able to upload the \"([^\"]*)\" with \"([^\"]*)\" message$")
    
    public void  i_am_able_to_upload_the_sod_Parameter_with_success_message(String SodParamter,String Success_Failure) throws Throwable {
        
    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
		Reusable_Page_Functions.upload_file(driver,SodParamter,Success_Failure);
		ScreenshotHelper.screenShot_all();

    }
    
    
    
    @And("^I should be able to verify \"([^\"]*)\", SOD_Parameter_SystemGenerated_GUID, other_SOD_Attributes ,\"([^\"]*)\" and \"([^\"]*)\" in the excel for the \"([^\"]*)\"$")
    public void  i_should_be_able_to_verify_action_SOD_Parameter_SystemGenerated_GUID_status_statuscomments(String Action, String Status, String Status_comments,String SodParamter) throws Throwable {
        
    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
		Reusable_Page_Functions.verify_resultantUploadedexceldata(driver,Action,Status,Status_comments,SodParamter);
		ScreenshotHelper.screenShot_all();
    }
    
    

    @And("^I am able to see the correct count of \"([^\"]*)\"$")
    public void  i_am_able_see_the_correct_count_of(List<String> Data) throws Throwable {
        
    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
		
		System.out.println("Data.size() : "+Data.size());

			Reusable_Page_Functions.verify_data_table(driver,Data);
			ScreenshotHelper.screenShot_all();
	   
		

    }
    
    
    @And("^I should be able to download the resultant uploaded file$")
    public void  I_should_be_able_to_download_the_resultant_uploaded_file() throws Throwable {
            
        	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
    		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
    		
    		Reusable_Page_Functions.download_the_resultant_uploaded_file();
    		ScreenshotHelper.screenShot_all();
        }
    
    
    
    @Then("^I should be able to download the \"([^\"]*)\" file successfully$")
    public void  I_should_be_able_to_download_the_file_successfully(String SodParamter) throws Throwable {
    	
    	PageFactory.initElements(driver, SegregationofDutiesHomePageObjects.class);		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		
		Reusable_Page_Functions.download_file(driver,SodParamter);
		ScreenshotHelper.screenShot_all();
    }
    
    
}
