package step_definitions;


import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriverException;
import org.testng.annotations.BeforeTest;

import com.cucumber.listener.Reporter;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.AfterStep;
import cucumber.api.java.Before;
//import gherkin.formatter.model.Step;
//import gherkin.ast.Step;
import helpers.Browser;
import helpers.ScreenshotHelper;



public class Hooks extends Browser
{ 

	final static Logger log = Logger.getLogger(Hooks.class);
	static String Timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());


	
	
	
 
 @Before
 public void beforeScenario(Scenario scenario) {
     Reporter.assignAuthor("Author : Selenium Cucumber - Saurav Kumar Ghosh");
 }
// 
 

 @AfterStep
 public void afterStep() throws Throwable {
	 System.out.println("After Something Step Here");
//	 try {
//		ScreenshotHelper.screenShot_all();
//	} catch (Exception e) {		
//		e.printStackTrace();
//	}
	 
	 
	 

 }
 

 
 @After
public void screenShot(Scenario scenario) throws Throwable {
	 
try {
if (scenario.isFailed()) {
		if(driver != null)
		{ScreenshotHelper.screenShot_Failed();}	
	}
else
{	
		if(driver != null)
		{ScreenshotHelper.screenShot_all();}

	}
} 
catch (WebDriverException somePlatformsDontSupportScreenshots) {
	System.err.println(somePlatformsDontSupportScreenshots.getMessage());
} 

finally {
                if(driver != null)
                	driver.close();
   }
}
}


 



 










     
 
    
 






