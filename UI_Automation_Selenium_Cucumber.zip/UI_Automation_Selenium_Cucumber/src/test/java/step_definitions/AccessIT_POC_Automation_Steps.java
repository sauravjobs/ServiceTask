package step_definitions;  

import cucumber.api.PendingException;
import helpers.Browser;

import helpers.Common_Group;
import helpers.ScreenshotHelper;
import modules.Accessit_ReusableFunctions;
import modules.Reusable_Page_Functions;

import java.util.Iterator;
import java.util.Map;

import java.io.File;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
//import org.mortbay.log.Log;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import pageobjects.AccessITPageObjects;
import pageobjects.Data;
import pageobjects.SegregationofDutiesHomePageObjects;
import pageobjects.TestDatas;


//import pageobjects.demonstarting_yaml;
//import helpers.ConfigUtils;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import freemarker.core.Environment;
//import com.relevantcodes.extentreports.ExtentReports;
//import com.relevantcodes.extentreports.ExtentTest;
//import com.relevantcodes.extentreports.LogStatus;
import java.text.SimpleDateFormat;
import java.util.Date;


import java.io.File;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.snakeyaml.Yaml;
import com.fasterxml.jackson.dataformat.yaml.snakeyaml.constructor.Constructor;


@SuppressWarnings("unused")
public class AccessIT_POC_Automation_Steps {
    public WebDriver driver;
    public String ExpectedText;    
 

    final static Logger log = Logger.getLogger(AccessIT_POC_Automation_Steps.class);
    
    
    
    @When("^I setup \"([^\"]*)\" for a \"([^\"]*)\" in database$")
    public void i_setup_data_for_JMLType_in_database(String Data,String JMLTYpe) throws Throwable
    {		
		Accessit_ReusableFunctions.prepare_data(driver,Data,JMLTYpe);
    }
    
    
    @When("^I find \"([^\"]*)\" in the \"([^\"]*)\" using the \"([^\"]*)\"$")
    public void i_find_an_entry_inthe_tableorView(String ExpectedResult,String Databasetable_view, String Query) throws Throwable
    {
    	Accessit_ReusableFunctions.verify_data_in_tableview(driver,ExpectedResult,Databasetable_view,Query);
    }
    
    
    
    @When("^I Login to IIQ as \"([^\"]*)\"$")
    public void i_login_to_IIQ(String User) throws Throwable
    {
    	
    	if(driver != null)
    	{Accessit_ReusableFunctions.login_to_IIQ(driver,User);
    	}
    	
    	else
    	{driver =Browser.getBrowser("CHROME");
    	driver.manage().deleteAllCookies();
        driver.manage().window().maximize();        
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
//    	driver.get("https://svlaoling2.gon.zuerich.ubs.ch/ait/login.jsf");
      driver.get("https://svrossi2a.gon.zuerich.ubs.ch/ait/login.jsf");     	
//    	https://svtotti2a.gon.zuerich.ubs.ch/ait/login.jsf
    	
    	
    		
    	PageFactory.initElements(driver, AccessITPageObjects.class);
    	ScreenshotHelper.screenShot_all();
    	
    	if(driver.getPageSource().contains("ISSO CH"))
		{	Thread.sleep(5000);
			AccessITPageObjects.username_ubs.sendKeys("ghoshsak");
			Thread.sleep(2000);
			AccessITPageObjects.password_ubs.sendKeys("Skaurav86#");
			Thread.sleep(2000);
			AccessITPageObjects.login_ubs.click();
		}
    	
    	Accessit_ReusableFunctions.login_to_IIQ(driver,User);
    	ScreenshotHelper.screenShot_all();
    	}
    }

    
 	  
    @When("^I run the \"([^\"]*)\" task to initiate a \"([^\"]*)\" process$")    
    public void i_run_thetask_to_initiate_the_JMLProcess(String schedulerTaskname,String JMLTYpe) throws Throwable
    {
    	PageFactory.initElements(driver, AccessITPageObjects.class);	
    	
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		Accessit_ReusableFunctions.runScheduler(driver,schedulerTaskname,JMLTYpe); 
		ScreenshotHelper.screenShot_all();
	
    }
    
    
  
    
    @And("^I verify the presence of certificate for the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_copy_certificate(String JMLTYpe,String User) throws Throwable
    {
    	PageFactory.initElements(driver, AccessITPageObjects.class);	
    	
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		Accessit_ReusableFunctions.verifyCertificate(driver,JMLTYpe,User); 
		ScreenshotHelper.screenShot_all();
    }
    
    
    @And("^I logout from the IIQ$")
    public void i_logout_from_iiq() throws Throwable
    {
    	PageFactory.initElements(driver, AccessITPageObjects.class);	
    	
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		AccessITPageObjects.userMenu.click();
		AccessITPageObjects.logout.click();
		ScreenshotHelper.screenShot_all();
    }
    
    
    @And("^I change the password of the \"([^\"]*)\"$")
    public void i_change_password(String User) throws Throwable
    {
    	PageFactory.initElements(driver, AccessITPageObjects.class);	
    	
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		Accessit_ReusableFunctions.changePassword(driver,User);
		ScreenshotHelper.screenShot_all();
    }
    
    
    @Then("^All the \"([^\"]*)\" reviews should be \"([^\"]*)\" by the \"([^\"]*)\"$")
    public void i_approve_reviews(String JMLTYpe, String Action, String User) throws Throwable
    {
    	PageFactory.initElements(driver, AccessITPageObjects.class);	
    	
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
		Accessit_ReusableFunctions.approveRevokeReviews(driver,JMLTYpe,Action,User);
		ScreenshotHelper.screenShot_all();
    }

       
}
