package pageobjects;
import java.util.List;

public class TestDatas {
List<Data> testdatas;

public List<Data> getTestdatas() {
	return testdatas;
}

public void setTestdatas(List<Data> testdatas) {
	this.testdatas = testdatas;
}

@Override
public String toString() {
	return "TestDatas [testdatas=" + testdatas + "]";
}


}