package pageobjects;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;




public class SegregationofDutiesHomePageObjects  {
	
	@FindBy(how=How.XPATH, using="//span[@class='menutext']")
	public static WebElement Segregation_of_Duties_text1;
	
	@FindBy(how=How.XPATH, using="//*[@id='spinner_div']/table/tbody/tr/td")
	public static WebElement Segregation_of_Duties_text2;
	
	@FindBy(how=How.XPATH, using="//*[contains(text()[1],'Ensure')]")
	public static WebElement Segregation_of_Duties_text3;
	
	@FindBy(how=How.XPATH, using="//*[@id='filedownlaod_div']/table/tbody/tr[1]/td")
	public static WebElement Segregation_of_Duties_text4;

	@FindBy(how=How.XPATH, using="//*[@id='spinner_div']/div[4]/div/div/div[2]")
	public static WebElement error_message_invalidFileFormat;
	
	@FindBy(how=How.XPATH, using="//button[@type='submit']")
	public static WebElement upload_button;
	
	@FindBy(how=How.XPATH, using="//button[@type='button'][@class='uwr-button uwr-button-submit']")
	public static WebElement download_button;

	@FindBy(how=How.ID, using="file_upload")
	public static WebElement file_upload;
	
	@FindBy(how=How.XPATH, using="//span[@class='uwr-dropdown-selected-value']")
	public static WebElement dropDown_with_Elements;
	
	@FindBy(how=How.ID, using="filter_asset_button")
	public static WebElement filterAssetButtons;
		
	@FindBy(how=How.ID, using="filter_role_button")
	public static WebElement filterRoleButtons;
			
	@FindBy(how=How.ID, using="assetCheckbox")
	public static WebElement assetCheckbox;
	
	@FindBy(how=How.ID, using="filter_asset_button")
	public static WebElement assetFilter;
	
	@FindBy(how=How.NAME, using="selectCheckAPA148663")
	public static WebElement selectFirstItem;
	
	@FindBy(how = How.XPATH, using = "//*[@class='submitfunctionbutton_large']")
	public static WebElement applySelection;
	
	
	@FindBy(how=How.ID, using="roleCheckbox")
	public static WebElement roleCheckbox;

	@FindBy(how=How.XPATH, using="//*[contains(text(),'Help and Guides')]")
	public static WebElement Help_and_Guides;
	
	@FindBy(how = How.XPATH, using = "//*[@class='dropbtn  topbar-name']")
	public static WebElement external_links;
	
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Access IT')]")
	public static WebElement accessIT_link;

	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'ARP')]")
	public static WebElement arp_link;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'BBS')]")
	public static WebElement bbs_link;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'MAC')]")
	public static WebElement mac_link;
	
	@FindBy(how=How.XPATH, using="//*[contains(text(),'result file here')]")
	public static WebElement download_the_resultant_uploaded_file_link;
		
	@FindBy(how=How.XPATH, using="//*[contains(text(),'Access Management')]")
	public static WebElement home_Access_Management;

//	@FindBy(how=How.XPATH, using="//*[contains(text(),'here')]")
	@FindBy(how=How.XPATH, using="//*[@id='fileuplaod_div']/table/tbody/tr[1]/td[3]/a")
	public static WebElement here;
	
	@FindBy(how=How.XPATH, using="//div[@class='panel-body']/span/a[contains(text(),'Download')]")
	public static WebElement download_the_SODfile_here;

	@FindBy(how=How.XPATH, using="//*[contains(text(),'Total records in input file')]")
	public static WebElement Total_records_in_input_file;
	
	@FindBy(how=How.XPATH, using="//*[contains(text(),'Total records successfully uploaded')]")
	public static WebElement Total_records_successfully_uploaded;
	
	@FindBy(how=How.XPATH, using="//*[contains(text(),'Total records processed')]")
	public static WebElement Total_records_processed;
	
	@FindBy(how=How.XPATH, using="//*[contains(text(),'Total records failed upload')]")
	public static WebElement Total_records_failed_upload;
	
	@FindBy(how=How.XPATH, using="//*[contains(text(),'Save the result file and compare with input file for any errors listed')]")
	public static WebElement Save_the_result_file;
	
	@FindBy(how=How.XPATH, using="//*[contains(text(),'Download the result file here')]")
	public static WebElement Download_the_result_file;

	@FindBy(how=How.XPATH, using="//*[contains(text()[1],'before')]")
	public static WebElement pdm_selection_text1;
	
	@FindBy(how=How.XPATH, using="//*[contains(text()[2],'listed')]")
	public static WebElement pdm_selection_text2;
	
	@FindBy(how=How.XPATH, using="//*[contains(text()[3],'assets or a subset')]")
	public static WebElement pdm_selection_text3;
	
	@FindBy(how=How.XPATH, using="//*[contains(text()[5],'roles or a subset')]")
	public static WebElement pdm_selection_text5;
	
	@FindBy(how=How.XPATH, using="//*[contains(text(),'Records successfully processed')]")
	public static WebElement successfull_message;
	
	@FindBy(how=How.XPATH, using="//*[@class='uwr-dropdown-item'and text()='Profile to Duty Mapping (PDM)']")
	public static WebElement dropdown_selection_pdm;

	@FindBy(how=How.XPATH, using="//*[@class='uwr-dropdown-item'and text()='Duty Mapping (Duty Matrix)']")
	public static WebElement dropdown_Duty_Mapping;
	
	@FindBy(how = How.XPATH, using = "//*[@class='uwr-dropdown-item' and text()='Duty']")
	public static WebElement dropdown_Duty;
	
	@FindBy(how = How.XPATH, using = "//*[@class='uwr-dropdown-container']")
	public static WebElement dropdown;

	@FindBy(how=How.XPATH, using="//table[@class='table borderless']")
	public static WebElement data_table_upload;

}



