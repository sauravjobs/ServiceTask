package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AccessITPageObjects {


	@FindBy(how=How.ID, using="identifierId")
	public static WebElement username;
		
	@FindBy(how=How.ID, using="loginForm:password")
	public static WebElement password;
	
	@FindBy(how=How.ID, using="loginForm:loginButton")
	public static WebElement login;
	
	@FindBy(how=How.ID, using="inputusername")
	public static WebElement username_ubs;
	
	@FindBy(how=How.ID, using="inputpassword")
	public static WebElement password_ubs;
	
	@FindBy(how=How.ID, using="login")
	public static WebElement login_ubs;
	
	@FindBy(how=How.ID, using="tasksSearchField-inputEl")
	public static WebElement tasksSearchField;
	
	@FindBy(how = How.XPATH, using = "//table[@class='x-grid-table x-grid-table-resizer']")
	public static WebElement data_table_Certifications;
	
	@FindBy(how = How.XPATH, using = "//div[@id='workItemsManageGridState-body']")
	public static WebElement data_table_searchCertifications;	
	
	@FindBy(how = How.XPATH, using = "//*[@class='x-grid-group-body  ' and @id='gridview-1026-bd-Generic']")
	public static WebElement searchList_scheduler;
	
	@FindBy(how = How.XPATH, using = "//*[@class='x-grid-cell-inner ' and text()='Perform Maintenance']")
	public static WebElement searchList_scheduler_Perform_Maintenance;
	
	@FindBy(how = How.XPATH, using = "//*[@class='x-grid-cell-inner ' and text()='ubsSNOW011 Request Processor']")
	public static WebElement searchList_scheduler_ubsSNOW011;
	
	@FindBy(how = How.XPATH, using = "//*[@class='x-grid-cell-inner ' and text()='ubsMAIL103 Send Deprovisioning Emails']")
	public static WebElement searchList_scheduler_ubsmail103;	
	
	@FindBy(how = How.XPATH, using = "//*[@class='x-grid-cell-inner ' and text()='ubsSNOW011 Request Processor']")
	public static WebElement searchList_scheduler_ubsmail003;	
	
	@FindBy(how = How.XPATH, using = "//*[@class='x-grid-cell-inner ' and text()='ubsID000 Refresh Identity Cube']")
	public static WebElement searchList_scheduler_Refresh_Identity_Cube;
	
	@FindBy(how = How.XPATH, using = "//*[@id='editForm:filter_str']")
	public static WebElement scheduler_input;
		
	@FindBy(how = How.XPATH, using = "//*[@id='editForm:validateBeforeExecuteButton']")
	public static WebElement savenExecute_scheduler;
	
	@FindBy(how = How.XPATH, using = "//*[@id='button-1013-btnInnerEl']")
	public static WebElement ok_button_forScheduler;	
	
	@FindBy(how = How.XPATH, using = "//*[@class='x-tab-inner' and @id='tab-1094-btnInnerEl']")
	public static WebElement task_result_tab;	
	
	@FindBy(how=How.ID, using="resultsSearchField-inputEl")
	public static WebElement tasksSearchField_taskresults;
	
	@FindBy(how=How.XPATH, using="//*[@class='x-grid-cell-inner ' and text()='ubsMES013 UBS JML Delta Aggregator']")
	public static WebElement taskresult_firstrecord_ubsMES013_UBS_JML_Delta_Aggregator;
	
	@FindBy(how=How.XPATH, using="//*[@class='x-grid-cell-inner ' and text()='ubsENAML001 Certification creation']")
	public static WebElement taskresult_firstrecord_ubsENAML001_Certification_creation;
	
	@FindBy(how=How.XPATH, using="//*[@id='gridview-1072']/table/tbody/tr[2]")
	public static WebElement taskresult_firstrecord;
	
	@FindBy(how=How.XPATH, using="//*[@class='rBorder']")
	public static WebElement success_message_forScheudler;

	@FindBy(how=How.ID, using="ext-gen1235")
	public static WebElement searchglass;
	
	@FindBy(how=How.XPATH, using="//*[contains(text()[2],'Setup')]")
	public static WebElement Setup_menu;
	
	@FindBy(how=How.XPATH, using="//*[contains(text()[2],'Identities')]")
	public static WebElement identities_menu;
		
	@FindBy(how=How.XPATH, using="//a[contains(@href,'/ait/monitor/tasks/viewTasks.jsf?resetTab=true')]")	
	public static WebElement task_item;
	
	@FindBy(how=How.XPATH, using="//a[contains(@href,'/ait/define/identity/identities.jsf')]")	
	public static WebElement identitywarehouse_item;	
	
	@FindBy(how=How.XPATH, using="//a[contains(@href,'/ait/monitor/scheduleCertifications/viewAndEditCertifications.jsf?resetTab=true')]")	
	public static WebElement certificate_item;
	
	@FindBy(how = How.XPATH, using = "//*[@id='searchfield-1022-inputEl']")
	public static WebElement search_certificate;
	
	@FindBy(how = How.XPATH, using = "//*[@id='ext-gen1240']")
	public static WebElement search_certificate_glass;
	
	@FindBy(how = How.XPATH, using = "//*[@class='x-grid-cell-inner ']")
	public static WebElement search_certificate_result;
		
	@FindBy(how = How.XPATH, using = "//i[@role='presentation' and @class='fa fa-sign-out m-r-xs']")
	public static WebElement logout;
	
	@FindBy(how = How.XPATH, using = "//*[@id='userMenu']")
	public static WebElement userMenu;
	
	@FindBy(how = How.XPATH, using = "//*[@id='searchfield-1035-inputEl']")
	public static WebElement searchbox_identity;
	
	@FindBy(how = How.XPATH, using = "//*[@id='ext-gen1128']")
	public static WebElement searchglass_identity;
	
	@FindBy(how = How.XPATH, using = "//span[@class='font10' and text()='Change Password']")
	public static WebElement changepassowrdLink;
	
	@FindBy(how = How.XPATH, using = "//*[@id='editForm:identityPassword']")
	public static WebElement passwordChange;	
	
	@FindBy(how = How.XPATH, using = "//*[@id='editForm:confirmPassword']")
	public static WebElement confirmpasswordChange;
	
	@FindBy(how = How.XPATH, using = "//*[@id='editForm:saveButton']")
	public static WebElement saveChangedPaswd;
	
	@FindBy(how = How.XPATH, using = "//a[@class='dropdown-toggle' and @tabindex='0']")
	public static WebElement myWork;
	
	@FindBy(how=How.XPATH, using="//a[contains(@href,'/ait/manage/certification/certifications.jsf')]")	
	public static WebElement myAccess_reviews_item;
	
	@FindBy(how=How.XPATH, using="//a[contains(@href,'/ait/manage/workItems/workItems.jsf?reset=true')]")
	public static WebElement workitems_item;
	
	@FindBy(how = How.XPATH, using = "//*[@id='manageSearchField-inputEl']")
	public static WebElement textBox_workItem;
		
	@FindBy(how = How.XPATH, using = "//*[@id='ext-gen1272']")
	public static WebElement workItem_searchglass;
	
	@FindBy(how = How.XPATH, using = "//span/sp-checkbox/button")
	public static WebElement checkAll_checkbox;
	
	@FindBy(how = How.XPATH, using = "//*[@ng-click='dataTableCtrl.spCheckboxMultiselect.getSelectionModel().selectAll()']")
	public static WebElement select_everything;
	
	@FindBy(how = How.XPATH, using = "//*[@class='btn btn-white btn-sm icon-btn dropdown-toggle ng-binding']")
	public static WebElement bulk_decisions;
	
	@FindBy(how = How.XPATH, using = "//*[@id='bulkDecisionSelector']/span/ul/li[1]/a")
	public static WebElement bulk_decisions_approve;
	
	@FindBy(how = How.XPATH, using = "//*[@id='bulkDecisionSelector']/span/ul/li[2]/a")
	public static WebElement bulk_decisions_revoke;
	
	@FindBy(how = How.XPATH, using = "//span[@ng-if='saveBtnCtrl.isEnabled()']")
	public static WebElement save_all_decisions;
	
	@FindBy(how = How.XPATH, using = "//*[@id='certSignOffBtn']")
	public static WebElement sign_offAll_decsions;
	
	@FindBy(how = How.XPATH, using = "//button[@ng-repeat='button in buttons' and text()='Finish']")
	public static WebElement finish_signOff;
	

	
}
