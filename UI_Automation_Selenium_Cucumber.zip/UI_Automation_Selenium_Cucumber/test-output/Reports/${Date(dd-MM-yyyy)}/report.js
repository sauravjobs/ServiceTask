$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/src/test/resources/features/AccessIT_POC_Automation_TestCases.feature");
formatter.feature({
  "line": 1,
  "name": "Access IT POC Automation Test Cases for Database and Web site(UI)",
  "description": "",
  "id": "access-it-poc-automation-test-cases-for-database-and-web-site(ui)",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Verify the enaml review creation from Mover review for an infrastructure user having AUU, ARP and RIA access rights.",
  "description": "",
  "id": "access-it-poc-automation-test-cases-for-database-and-web-site(ui);verify-the-enaml-review-creation-from-mover-review-for-an-infrastructure-user-having-auu,-arp-and-ria-access-rights.",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@Test"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "I setup \"\u003cdata\u003e\" for a \"MOVER\" in database",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I find \"NewData_Updated_and_Status_NotProcessed\" in the \"MES_EMPLOYEEJML_view\" using the \"\u003cQueries\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "I Login to IIQ as \"Admin\"",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I run the \"ubsMES013_UBS_JML_Delta_Aggregator\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I verify the presence of certificate for the \"MOVER\" as \"Admin\"",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "I find \"Mover_CC_Function_change\" in the \"MES_EMPLOYEEJMLHISTORY_TBL\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "I find \"Status_as_Deleted\" in the \"MES_EmployeeJML_Tbl_status\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "I find \"Owner_ofThe_Certificate\" in the \"SPT_WORK_ITEM_RO\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "I change the password of the \"LM\"",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "I logout from the IIQ",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "I Login to IIQ as \"LM\"",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "All the \"MOVER\" reviews should be \"Approved\" by the \"LM\"",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "I logout from the IIQ",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "I Login to IIQ as \"Admin\"",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "I run the \"ubsENAML001_Certification_creation\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "I find \"db_certificateName\" in the \"SPT_Certification_RO\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "I find \"db_owner_oftheCertifcate_newAccessMover\" in the \"SPT_WORK_ITEM_RO\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "I change the password of the \"Certificate_Owner\"",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "I logout from the IIQ",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "I Login to IIQ as \"Certificate_Owner\"",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "I verify the presence of certificate for the \"MOVER\" as \"Certificate_Owner\"",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "All the \"MOVER\" reviews should be \"Revoked\" by the \"Certificate_Owner\"",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I logout from the IIQ",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "I Login to IIQ as \"Admin\"",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "I run the \"Perform_Maintenance\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "I verify the presence of certificate for the \"MOVER\" as \"Admin\"",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "I run the \"ubsid000_Refresh_Identity_Cube\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "I find \"EXTENDED4_asNull_and_Entitlement_Removed\" in the \"spt_identity_entitlement\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "I find \"Correct_status_Modifieddate_displayed\" in the \"PTR_MEMBER_AUU\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "I run the \"ubssnow011\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "I find \"REQUESTID_and_REQUESTITEMID\" in the \"snow_request_tbl\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "I find \"acrtype_acrdomainid_acrbusinessunit\" in the \"LAAP_ACCESSRIGHT_TBL\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 37,
  "name": "I find \"email_address\" in the \"LAAP_MAIL_MAPPING_TBL\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "I find \"requeststatus_as_Pending\" in the \"email_request_tbl\" using the \"\u003cQueries\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "I run the \"ubsmail103\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 40,
  "name": "I find \"status_as_queued\" in the \"email_request_tbl\" using the \"\u003cQueries\u003e",
  "keyword": "And "
});
formatter.examples({
  "line": 42,
  "name": "",
  "description": "",
  "id": "access-it-poc-automation-test-cases-for-database-and-web-site(ui);verify-the-enaml-review-creation-from-mover-review-for-an-infrastructure-user-having-auu,-arp-and-ria-access-rights.;",
  "rows": [
    {
      "cells": [
        "data",
        "Queries"
      ],
      "line": 43,
      "id": "access-it-poc-automation-test-cases-for-database-and-web-site(ui);verify-the-enaml-review-creation-from-mover-review-for-an-infrastructure-user-having-auu,-arp-and-ria-access-rights.;;1"
    },
    {
      "cells": [
        "MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION",
        "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS"
      ],
      "line": 44,
      "id": "access-it-poc-automation-test-cases-for-database-and-web-site(ui);verify-the-enaml-review-creation-from-mover-review-for-an-infrastructure-user-having-auu,-arp-and-ria-access-rights.;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 6381400,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "Verify the enaml review creation from Mover review for an infrastructure user having AUU, ARP and RIA access rights.",
  "description": "",
  "id": "access-it-poc-automation-test-cases-for-database-and-web-site(ui);verify-the-enaml-review-creation-from-mover-review-for-an-infrastructure-user-having-auu,-arp-and-ria-access-rights.;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@Test"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "I setup \"MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION\" for a \"MOVER\" in database",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I find \"NewData_Updated_and_Status_NotProcessed\" in the \"MES_EMPLOYEEJML_view\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "I Login to IIQ as \"Admin\"",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I run the \"ubsMES013_UBS_JML_Delta_Aggregator\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I verify the presence of certificate for the \"MOVER\" as \"Admin\"",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "I find \"Mover_CC_Function_change\" in the \"MES_EMPLOYEEJMLHISTORY_TBL\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "I find \"Status_as_Deleted\" in the \"MES_EmployeeJML_Tbl_status\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "I find \"Owner_ofThe_Certificate\" in the \"SPT_WORK_ITEM_RO\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "I change the password of the \"LM\"",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "I logout from the IIQ",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "I Login to IIQ as \"LM\"",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "All the \"MOVER\" reviews should be \"Approved\" by the \"LM\"",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "I logout from the IIQ",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "I Login to IIQ as \"Admin\"",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "I run the \"ubsENAML001_Certification_creation\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "I find \"db_certificateName\" in the \"SPT_Certification_RO\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "I find \"db_owner_oftheCertifcate_newAccessMover\" in the \"SPT_WORK_ITEM_RO\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "I change the password of the \"Certificate_Owner\"",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "I logout from the IIQ",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "I Login to IIQ as \"Certificate_Owner\"",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "I verify the presence of certificate for the \"MOVER\" as \"Certificate_Owner\"",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "All the \"MOVER\" reviews should be \"Revoked\" by the \"Certificate_Owner\"",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I logout from the IIQ",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "I Login to IIQ as \"Admin\"",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "I run the \"Perform_Maintenance\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "I verify the presence of certificate for the \"MOVER\" as \"Admin\"",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "I run the \"ubsid000_Refresh_Identity_Cube\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "I find \"EXTENDED4_asNull_and_Entitlement_Removed\" in the \"spt_identity_entitlement\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "I find \"Correct_status_Modifieddate_displayed\" in the \"PTR_MEMBER_AUU\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "I run the \"ubssnow011\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "I find \"REQUESTID_and_REQUESTITEMID\" in the \"snow_request_tbl\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "I find \"acrtype_acrdomainid_acrbusinessunit\" in the \"LAAP_ACCESSRIGHT_TBL\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 37,
  "name": "I find \"email_address\" in the \"LAAP_MAIL_MAPPING_TBL\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "I find \"requeststatus_as_Pending\" in the \"email_request_tbl\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "I run the \"ubsmail103\" task to initiate a \"MOVER\" process",
  "keyword": "And "
});
formatter.step({
  "line": 40,
  "name": "I find \"status_as_queued\" in the \"email_request_tbl\" using the \"VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "MOVER_DATA_BY_CHANGING_UBSCOSTCENTRE_UBSFUNCTION",
      "offset": 9
    },
    {
      "val": "MOVER",
      "offset": 66
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_setup_data_for_JMLType_in_database(String,String)"
});
formatter.result({
  "duration": 44607287400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "NewData_Updated_and_Status_NotProcessed",
      "offset": 8
    },
    {
      "val": "MES_EMPLOYEEJML_view",
      "offset": 57
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 90
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "duration": 1974437800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 19
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_login_to_IIQ(String)"
});
formatter.result({
  "duration": 19488498200,
  "error_message": "org.openqa.selenium.SessionNotCreatedException: session not created: Chrome version must be between 70 and 73\n  (Driver info: chromedriver\u003d2.45.615291 (ec3682e3c9061c10f26ea9e5cdcf3c53f3f74387),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 12.89 seconds\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027SI2D-AM0203074\u0027, ip: \u002710.87.198.109\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_31\u0027\nDriver info: driver.version: ChromeDriver\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:408)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$new$0(JsonWireProtocolResponse.java:53)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse$$Lambda$133/761197720.apply(Unknown Source)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$getResponseFunction$2(JsonWireProtocolResponse.java:91)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse$$Lambda$135/49619396.apply(Unknown Source)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.lambda$createSession$0(ProtocolHandshake.java:123)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake$$Lambda$142/1794489296.apply(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline$3$1.accept(ReferencePipeline.java:193)\r\n\tat java.util.Spliterators$ArraySpliterator.tryAdvance(Spliterators.java:958)\r\n\tat java.util.stream.ReferencePipeline.forEachWithCancel(ReferencePipeline.java:126)\r\n\tat java.util.stream.AbstractPipeline.copyIntoWithCancel(AbstractPipeline.java:529)\r\n\tat java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:516)\r\n\tat java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:502)\r\n\tat java.util.stream.FindOps$FindOp.evaluateSequential(FindOps.java:152)\r\n\tat java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)\r\n\tat java.util.stream.ReferencePipeline.findFirst(ReferencePipeline.java:464)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:126)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:73)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:142)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:600)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:219)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.\u003cinit\u003e(RemoteWebDriver.java:142)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:181)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:168)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:157)\r\n\tat helpers.Browser.getBrowser(Browser.java:58)\r\n\tat step_definitions.AccessIT_POC_Automation_Steps.i_login_to_IIQ(AccessIT_POC_Automation_Steps.java:95)\r\n\tat ✽.When I Login to IIQ as \"Admin\"(P:/Saurav/Java_Automation/final workspace/UI_Automation_Selenium_Cucumber/src/test/resources/features/AccessIT_POC_Automation_TestCases.feature:7)\r\n",
  "status": "failed"
});
formatter.match({
  "arguments": [
    {
      "val": "ubsMES013_UBS_JML_Delta_Aggregator",
      "offset": 11
    },
    {
      "val": "MOVER",
      "offset": 67
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_run_thetask_to_initiate_the_JMLProcess(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "MOVER",
      "offset": 46
    },
    {
      "val": "Admin",
      "offset": 57
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_copy_certificate(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Mover_CC_Function_change",
      "offset": 8
    },
    {
      "val": "MES_EMPLOYEEJMLHISTORY_TBL",
      "offset": 42
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 81
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Status_as_Deleted",
      "offset": 8
    },
    {
      "val": "MES_EmployeeJML_Tbl_status",
      "offset": 35
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 74
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Owner_ofThe_Certificate",
      "offset": 8
    },
    {
      "val": "SPT_WORK_ITEM_RO",
      "offset": 41
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 70
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "LM",
      "offset": 30
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_change_password(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "AccessIT_POC_Automation_Steps.i_logout_from_iiq()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "LM",
      "offset": 19
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_login_to_IIQ(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "MOVER",
      "offset": 9
    },
    {
      "val": "Approved",
      "offset": 35
    },
    {
      "val": "LM",
      "offset": 53
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_approve_reviews(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "AccessIT_POC_Automation_Steps.i_logout_from_iiq()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 19
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_login_to_IIQ(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "ubsENAML001_Certification_creation",
      "offset": 11
    },
    {
      "val": "MOVER",
      "offset": 67
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_run_thetask_to_initiate_the_JMLProcess(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "db_certificateName",
      "offset": 8
    },
    {
      "val": "SPT_Certification_RO",
      "offset": 36
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 69
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "db_owner_oftheCertifcate_newAccessMover",
      "offset": 8
    },
    {
      "val": "SPT_WORK_ITEM_RO",
      "offset": 57
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 86
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Certificate_Owner",
      "offset": 30
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_change_password(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "AccessIT_POC_Automation_Steps.i_logout_from_iiq()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Certificate_Owner",
      "offset": 19
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_login_to_IIQ(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "MOVER",
      "offset": 46
    },
    {
      "val": "Certificate_Owner",
      "offset": 57
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_copy_certificate(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "MOVER",
      "offset": 9
    },
    {
      "val": "Revoked",
      "offset": 35
    },
    {
      "val": "Certificate_Owner",
      "offset": 52
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_approve_reviews(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "AccessIT_POC_Automation_Steps.i_logout_from_iiq()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 19
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_login_to_IIQ(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Perform_Maintenance",
      "offset": 11
    },
    {
      "val": "MOVER",
      "offset": 52
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_run_thetask_to_initiate_the_JMLProcess(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "MOVER",
      "offset": 46
    },
    {
      "val": "Admin",
      "offset": 57
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_copy_certificate(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "ubsid000_Refresh_Identity_Cube",
      "offset": 11
    },
    {
      "val": "MOVER",
      "offset": 63
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_run_thetask_to_initiate_the_JMLProcess(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "EXTENDED4_asNull_and_Entitlement_Removed",
      "offset": 8
    },
    {
      "val": "spt_identity_entitlement",
      "offset": 58
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 95
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Correct_status_Modifieddate_displayed",
      "offset": 8
    },
    {
      "val": "PTR_MEMBER_AUU",
      "offset": 55
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 82
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "ubssnow011",
      "offset": 11
    },
    {
      "val": "MOVER",
      "offset": 43
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_run_thetask_to_initiate_the_JMLProcess(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "REQUESTID_and_REQUESTITEMID",
      "offset": 8
    },
    {
      "val": "snow_request_tbl",
      "offset": 45
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 74
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "acrtype_acrdomainid_acrbusinessunit",
      "offset": 8
    },
    {
      "val": "LAAP_ACCESSRIGHT_TBL",
      "offset": 53
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 86
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "email_address",
      "offset": 8
    },
    {
      "val": "LAAP_MAIL_MAPPING_TBL",
      "offset": 31
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 65
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "requeststatus_as_Pending",
      "offset": 8
    },
    {
      "val": "email_request_tbl",
      "offset": 42
    },
    {
      "val": "VERIFICATION_QUERIES_FOR_DIFFERENT_TABLES_VIEWS",
      "offset": 72
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_find_an_entry_inthe_tableorView(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "ubsmail103",
      "offset": 11
    },
    {
      "val": "MOVER",
      "offset": 43
    }
  ],
  "location": "AccessIT_POC_Automation_Steps.i_run_thetask_to_initiate_the_JMLProcess(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.after({
  "duration": 174500,
  "status": "passed"
});
});